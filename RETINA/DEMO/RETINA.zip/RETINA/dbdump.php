
      <?php
      require "Generics.php";
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT RETINA\n");
      fwrite($dumpfile, dumprel("persoonsgegevensType[Persoonsgegeven*PersoonsgegevensType]","SELECT DISTINCT `Persoonsgegeven`, `persoonsgegevensType` FROM `Persoonsgegeven` WHERE `Persoonsgegeven` IS NOT NULL AND `persoonsgegevensType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("persoonsgegevensWaarde[Persoonsgegeven*PersoonsgegevensWaarde]","SELECT DISTINCT `Persoonsgegeven`, `persoonsgegevensWaarde` FROM `Persoonsgegeven` WHERE `Persoonsgegeven` IS NOT NULL AND `persoonsgegevensWaarde` IS NOT NULL"));
      fwrite($dumpfile, dumprel("betrokkene[Persoonsgegeven*NatuurlijkPersoon]","SELECT DISTINCT `Persoonsgegeven`, `betrokkene` FROM `Persoonsgegeven` WHERE `Persoonsgegeven` IS NOT NULL AND `betrokkene` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verzamelDoel[Persoonsgegeven*Doel]","SELECT DISTINCT `Persoonsgegeven`, `Doel` FROM `verzamelDoel` WHERE `Persoonsgegeven` IS NOT NULL AND `Doel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingNaam[Verwerking*Naam]","SELECT DISTINCT `Verwerking`, `verwerkingNaam` FROM `Verwerking` WHERE `Verwerking` IS NOT NULL AND `verwerkingNaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingOmschrijving[Verwerking*Omschrijving]","SELECT DISTINCT `Verwerking`, `verwerkingOmschrijving` FROM `Verwerking` WHERE `Verwerking` IS NOT NULL AND `verwerkingOmschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingsVerantwoordelijke[Verwerking*Partij]","SELECT DISTINCT `Verwerking`, `Partij` FROM `verwerkingsVerantwoordelijke` WHERE `Verwerking` IS NOT NULL AND `Partij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isDeelverwerkingVan[Verwerking]","SELECT DISTINCT `sVerwerking`, `tVerwerking` FROM `isDeelverwerkingVan` WHERE `sVerwerking` IS NOT NULL AND `tVerwerking` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingBewerker[Verwerking*Partij]","SELECT DISTINCT `Verwerking`, `Partij` FROM `verwerkingBewerker` WHERE `Verwerking` IS NOT NULL AND `Partij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingsDoel[Verwerking*Doel]","SELECT DISTINCT `Verwerking`, `Doel` FROM `verwerkingsDoel` WHERE `Verwerking` IS NOT NULL AND `Doel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingBetrokkenenCategorie[Verwerking*BetrokkeneCategorie]","SELECT DISTINCT `Verwerking`, `BetrokkeneCategorie` FROM `verwerkingBetrokkenenCategorie` WHERE `Verwerking` IS NOT NULL AND `BetrokkeneCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingGegevensCategorie[Verwerking*GegevensCategorie]","SELECT DISTINCT `Verwerking`, `GegevensCategorie` FROM `verwerkingGegevensCategorie` WHERE `Verwerking` IS NOT NULL AND `GegevensCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingOntvangerCategorie[Verwerking*OntvangerCategorie]","SELECT DISTINCT `Verwerking`, `OntvangerCategorie` FROM `verwerkingOntvangerCategorie` WHERE `Verwerking` IS NOT NULL AND `OntvangerCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingOntvanger[Verwerking*Partij]","SELECT DISTINCT `Verwerking`, `Partij` FROM `verwerkingOntvanger` WHERE `Verwerking` IS NOT NULL AND `Partij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingGegevensDoorgiftenBuitenEU[Verwerking*DoorgifteBuitenEU]","SELECT DISTINCT `Verwerking`, `DoorgifteBuitenEU` FROM `verwerkingGegevensDoorgiftenBuitenEU` WHERE `Verwerking` IS NOT NULL AND `DoorgifteBuitenEU` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingSpecificatieSamenvatting[Verwerking*SpecificatieSamenvatting]","SELECT DISTINCT `Verwerking`, `verwerkingSpecificatieSamenvatting` FROM `Verwerking` WHERE `Verwerking` IS NOT NULL AND `verwerkingSpecificatieSamenvatting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingBewaartermijn[Verwerking*Bewaartermijn]","SELECT DISTINCT `Verwerking`, `verwerkingBewaartermijn` FROM `Verwerking` WHERE `Verwerking` IS NOT NULL AND `verwerkingBewaartermijn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doelID[Doel*DoelID]","SELECT DISTINCT `Doel`, `doelID` FROM `Doel` WHERE `Doel` IS NOT NULL AND `doelID` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gerechtvaardigdDoor[Doel*Partij]","SELECT DISTINCT `Doel`, `gerechtvaardigdDoor` FROM `Doel` WHERE `Doel` IS NOT NULL AND `gerechtvaardigdDoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doelOmschrijving[Doel*Omschrijving]","SELECT DISTINCT `Doel`, `doelOmschrijving` FROM `Doel` WHERE `Doel` IS NOT NULL AND `doelOmschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doelWettelijkeGrondslag[Doel*WettelijkeGrondslag]","SELECT DISTINCT `Doel`, `doelWettelijkeGrondslag` FROM `Doel` WHERE `Doel` IS NOT NULL AND `doelWettelijkeGrondslag` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isSubdoelVan[Doel]","SELECT DISTINCT `sDoel`, `tDoel` FROM `isSubdoelVan` WHERE `sDoel` IS NOT NULL AND `tDoel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doelGegevensType[Doel*PersoonsgegevensType]","SELECT DISTINCT `Doel`, `PersoonsgegevensType` FROM `doelGegevensType` WHERE `Doel` IS NOT NULL AND `PersoonsgegevensType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verenigbaarMet[Doel]","SELECT DISTINCT `sDoel`, `tDoel` FROM `verenigbaarMet` WHERE `sDoel` IS NOT NULL AND `tDoel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("partijNaam[Partij*PartijNaam]","SELECT DISTINCT `Partij`, `partijNaam` FROM `Partij` WHERE `Partij` IS NOT NULL AND `partijNaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("partijAdres[Partij*Adres]","SELECT DISTINCT `Partij`, `Adres` FROM `partijAdres` WHERE `Partij` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("berichtSoortGegevensType[BerichtSoort*PersoonsgegevensType]","SELECT DISTINCT `BerichtSoort`, `PersoonsgegevensType` FROM `berichtSoortGegevensType` WHERE `BerichtSoort` IS NOT NULL AND `PersoonsgegevensType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("definetimeVerzamelendeService[PersoonsgegevensType*Service]","SELECT DISTINCT `PersoonsgegevensType`, `Service` FROM `definetimeVerzamelendeService` WHERE `PersoonsgegevensType` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("definetimeVerwerkendeService[PersoonsgegevensType*Service]","SELECT DISTINCT `PersoonsgegevensType`, `Service` FROM `definetimeVerwerkendeService` WHERE `PersoonsgegevensType` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("serviceGegevensCategorie[Service*GegevensCategorie]","SELECT DISTINCT `Service`, `GegevensCategorie` FROM `serviceGegevensCategorie` WHERE `Service` IS NOT NULL AND `GegevensCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("serviceOntvangerCategorie[Service*ServiceCategorie]","SELECT DISTINCT `Service`, `ServiceCategorie` FROM `serviceOntvangerCategorie` WHERE `Service` IS NOT NULL AND `ServiceCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("serviceOntvanger[Service]","SELECT DISTINCT `sService`, `tService` FROM `serviceOntvanger` WHERE `sService` IS NOT NULL AND `tService` IS NOT NULL"));
      fwrite($dumpfile, dumprel("versturendeService[BerichtSoort*Service]","SELECT DISTINCT `BerichtSoort`, `Service` FROM `versturendeService` WHERE `BerichtSoort` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ontvangendeService[BerichtSoort*Service]","SELECT DISTINCT `BerichtSoort`, `Service` FROM `ontvangendeService` WHERE `BerichtSoort` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("typeOf[SvcInstantie*Service]","SELECT DISTINCT `SvcInstantie`, `typeOf` FROM `SvcInstantie` WHERE `SvcInstantie` IS NOT NULL AND `typeOf` IS NOT NULL"));
      fwrite($dumpfile, dumprel("typeOf[Bericht*BerichtSoort]","SELECT DISTINCT `Bericht`, `typeOf` FROM `Bericht` WHERE `Bericht` IS NOT NULL AND `typeOf` IS NOT NULL"));
      fwrite($dumpfile, dumprel("typeOf[RuntimeDoel*Doel]","SELECT DISTINCT `RuntimeDoel`, `typeOf` FROM `RuntimeDoel1` WHERE `RuntimeDoel` IS NOT NULL AND `typeOf` IS NOT NULL"));
      fwrite($dumpfile, dumprel("runtimeVerzamelendeService[Persoonsgegeven*Service]","SELECT DISTINCT `Persoonsgegeven`, `runtimeVerzamelendeService` FROM `Persoonsgegeven` WHERE `Persoonsgegeven` IS NOT NULL AND `runtimeVerzamelendeService` IS NOT NULL"));
      fwrite($dumpfile, dumprel("runtimeVerwerkendeService[Persoonsgegeven*Service]","SELECT DISTINCT `Persoonsgegeven`, `Service` FROM `runtimeVerwerkendeService` WHERE `Persoonsgegeven` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("runtimeDoel[SvcInstantie*RuntimeDoel]","SELECT DISTINCT `SvcInstantie`, `RuntimeDoel` FROM `runtimeDoel2` WHERE `SvcInstantie` IS NOT NULL AND `RuntimeDoel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verstuurdNaar[Bericht*SvcInstantie]","SELECT DISTINCT `Bericht`, `verstuurdNaar` FROM `Bericht` WHERE `Bericht` IS NOT NULL AND `verstuurdNaar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verstuurdDoor[Bericht*SvcInstantie]","SELECT DISTINCT `Bericht`, `verstuurdDoor` FROM `Bericht` WHERE `Bericht` IS NOT NULL AND `verstuurdDoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gegevenInBericht[Persoonsgegeven*Bericht]","SELECT DISTINCT `Persoonsgegeven`, `Bericht` FROM `gegevenInBericht` WHERE `Persoonsgegeven` IS NOT NULL AND `Bericht` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer($quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\"",$str); }
      ?>