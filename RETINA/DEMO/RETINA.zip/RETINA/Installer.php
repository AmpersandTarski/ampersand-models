<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass elsewhere
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('RETINA')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `RETINA` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('RETINA');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'RETINA'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Session timeout table
    if($columns = mysql_query("SHOW COLUMNS FROM `__SessionTimeout__`")){
        mysql_query("DROP TABLE `__SessionTimeout__`");
    }
    mysql_query("CREATE TABLE `__SessionTimeout__`
                         ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                         , `lastAccess` BIGINT NOT NULL
                         ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
    }
    mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                         ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 49
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `Verwerking`")){
        mysql_query("DROP TABLE `Verwerking`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Doel`")){
        mysql_query("DROP TABLE `Doel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Persoonsgegeven`")){
        mysql_query("DROP TABLE `Persoonsgegeven`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Bericht`")){
        mysql_query("DROP TABLE `Bericht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `RuntimeDoel1`")){
        mysql_query("DROP TABLE `RuntimeDoel1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `runtimeDoel2`")){
        mysql_query("DROP TABLE `runtimeDoel2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `SvcInstantie`")){
        mysql_query("DROP TABLE `SvcInstantie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Partij`")){
        mysql_query("DROP TABLE `Partij`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `NatuurlijkPersoon`")){
        mysql_query("DROP TABLE `NatuurlijkPersoon`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ServiceCategorie`")){
        mysql_query("DROP TABLE `ServiceCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `BerichtSoort`")){
        mysql_query("DROP TABLE `BerichtSoort`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Adres`")){
        mysql_query("DROP TABLE `Adres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `PartijNaam`")){
        mysql_query("DROP TABLE `PartijNaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `WettelijkeGrondslag`")){
        mysql_query("DROP TABLE `WettelijkeGrondslag`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `DoelID`")){
        mysql_query("DROP TABLE `DoelID`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Bewaartermijn`")){
        mysql_query("DROP TABLE `Bewaartermijn`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `SpecificatieSamenvatting`")){
        mysql_query("DROP TABLE `SpecificatieSamenvatting`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `DoorgifteBuitenEU`")){
        mysql_query("DROP TABLE `DoorgifteBuitenEU`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `OntvangerCategorie`")){
        mysql_query("DROP TABLE `OntvangerCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `GegevensCategorie`")){
        mysql_query("DROP TABLE `GegevensCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `BetrokkeneCategorie`")){
        mysql_query("DROP TABLE `BetrokkeneCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Omschrijving`")){
        mysql_query("DROP TABLE `Omschrijving`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Naam`")){
        mysql_query("DROP TABLE `Naam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `PersoonsgegevensWaarde`")){
        mysql_query("DROP TABLE `PersoonsgegevensWaarde`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `PersoonsgegevensType`")){
        mysql_query("DROP TABLE `PersoonsgegevensType`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verzamelDoel`")){
        mysql_query("DROP TABLE `verzamelDoel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verwerkingsVerantwoordelijke`")){
        mysql_query("DROP TABLE `verwerkingsVerantwoordelijke`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `isDeelverwerkingVan`")){
        mysql_query("DROP TABLE `isDeelverwerkingVan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verwerkingBewerker`")){
        mysql_query("DROP TABLE `verwerkingBewerker`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verwerkingsDoel`")){
        mysql_query("DROP TABLE `verwerkingsDoel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verwerkingBetrokkenenCategorie`")){
        mysql_query("DROP TABLE `verwerkingBetrokkenenCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verwerkingGegevensCategorie`")){
        mysql_query("DROP TABLE `verwerkingGegevensCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verwerkingOntvangerCategorie`")){
        mysql_query("DROP TABLE `verwerkingOntvangerCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verwerkingOntvanger`")){
        mysql_query("DROP TABLE `verwerkingOntvanger`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verwerkingGegevensDoorgiftenBuitenEU`")){
        mysql_query("DROP TABLE `verwerkingGegevensDoorgiftenBuitenEU`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `isSubdoelVan`")){
        mysql_query("DROP TABLE `isSubdoelVan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `doelGegevensType`")){
        mysql_query("DROP TABLE `doelGegevensType`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verenigbaarMet`")){
        mysql_query("DROP TABLE `verenigbaarMet`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `partijAdres`")){
        mysql_query("DROP TABLE `partijAdres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `berichtSoortGegevensType`")){
        mysql_query("DROP TABLE `berichtSoortGegevensType`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `definetimeVerzamelendeService`")){
        mysql_query("DROP TABLE `definetimeVerzamelendeService`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `definetimeVerwerkendeService`")){
        mysql_query("DROP TABLE `definetimeVerwerkendeService`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `serviceGegevensCategorie`")){
        mysql_query("DROP TABLE `serviceGegevensCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `serviceOntvangerCategorie`")){
        mysql_query("DROP TABLE `serviceOntvangerCategorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `serviceOntvanger`")){
        mysql_query("DROP TABLE `serviceOntvanger`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `versturendeService`")){
        mysql_query("DROP TABLE `versturendeService`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ontvangendeService`")){
        mysql_query("DROP TABLE `ontvangendeService`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `runtimeVerwerkendeService`")){
        mysql_query("DROP TABLE `runtimeVerwerkendeService`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gegevenInBericht`")){
        mysql_query("DROP TABLE `gegevenInBericht`");
      }
    }
    /*******************************************\
    * Plug Verwerking                           *
    *                                           *
    * fields:                                   *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]      *
    * Service~  [INJ,SUR,UNI]                   *
    * verwerkingNaam  [UNI,TOT]                 *
    * verwerkingOmschrijving  [UNI]             *
    * verwerkingSpecificatieSamenvatting  [UNI] *
    * verwerkingBewaartermijn  [UNI]            *
    \*******************************************/
    mysql_query("CREATE TABLE `Verwerking`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `Service` VARCHAR(255) DEFAULT NULL
                     , `verwerkingNaam` VARCHAR(255) DEFAULT NULL
                     , `verwerkingOmschrijving` VARCHAR(255) DEFAULT NULL
                     , `verwerkingSpecificatieSamenvatting` VARCHAR(255) DEFAULT NULL
                     , `verwerkingBewaartermijn` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Verwerking` (`Verwerking` ,`Service` ,`verwerkingNaam` ,`verwerkingOmschrijving` ,`verwerkingSpecificatieSamenvatting` ,`verwerkingBewaartermijn` )
                VALUES ('Vw_AMS', NULL, 'AMS', 'Het detecteren van de locatie van gorilla\'s en het publiceren ervan op bezoekerszuilen', 'Door middel van cameras wordt gedetecteerd waar zich apen bevinden. Op beeldschermen rond het apenverblijf wordt vervolgens getoond waar zich apen bevinden. Als zich ergens een voor de bezoekers interessante situatie voordoet, wordt dit erbij vermeld. Ook worden de videobeelden gebruikt om vroegtijdig situaties te signaleren waarin apen mogelijk gewelddadig gedrag gaan vertonen.', '1 jaar')
                      , ('Svc_AMStore', 'Svc_AMStore', 'AMStore Service', 'Het opslaan van alle data die gerelateerd is aan AMS', 'Door middel van verschillende camera\'s die zijn gericht op het gorilla eiland van de Apenheul wordt beeldmateriaal (zowel lage als hoge resolutie) opgenomen en opgeslagen.', '1 maand')
                      , ('Svc_Camera', 'Svc_Camera', 'Camera Service', 'Het op hoge resolutie opnemen van beelden van het gorilla eiland en deze in de AMS repository doen opslaan', 'Door middel van verschillende camera\'s die zijn gericht op het gorilla eiland van de Apenheul wordt beeldmateriaal (zowel lage als hoge resolutie) opgenomen en opgeslagen.', '1 maand')
                      , ('Svc_Annotatie', 'Svc_Annotatie', 'Annotatie Service', 'Het annoteren van beeldmateriaal met identifiers van apen en andere kenmerken', 'Aan het beschikbare laag- en hoogresolute beeldmateriaal worden kenmerken gekoppeld (annoteren), zoals identifiers aan de hand waarvan apen kunnen worden geidentificeerd, ten behoeve van verdere verwerking.', '1 maand')
                      , ('Svc_Anonimisatie', 'Svc_Anonimisatie', 'Anonimisatie Service', 'Het anonimiseren van HI-RES naar LO-RES beeldmateriaal en het anonimiseren van de erbij horende annotaties', 'Aan het beschikbare laag- en hoogresolute beeldmateriaal worden kenmerken gekoppeld (annoteren), zoals identifiers aan de hand waarvan apen kunnen worden geidentificeerd, ten behoeve van verdere verwerking.', '1 maand')
                      , ('Svc_Bezoekerskaart', 'Svc_Bezoekerskaart', 'Bezoekerskaart Service', 'Het tonen, op een kaart, van de locatie van apen', 'Door middel van de annotaties van beeldmateriaal kan worden vastgesteld welke aap zich op welke locatie op de kaart van het gorilla eiland bevindt. Per aap wordt dit op de bezoekerszuilen weergegeven.', '1 minuut')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Doel                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * doelID  [UNI,TOT]                    *
    * gerechtvaardigdDoor  [UNI,TOT,SUR]   *
    * doelOmschrijving  [UNI,TOT,SUR]      *
    * doelWettelijkeGrondslag  [UNI]       *
    \**************************************/
    mysql_query("CREATE TABLE `Doel`
                     ( `Doel` VARCHAR(255) DEFAULT NULL
                     , `doelID` VARCHAR(255) DEFAULT NULL
                     , `gerechtvaardigdDoor` VARCHAR(255) DEFAULT NULL
                     , `doelOmschrijving` VARCHAR(255) DEFAULT NULL
                     , `doelWettelijkeGrondslag` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Doel` (`Doel` ,`doelID` ,`gerechtvaardigdDoor` ,`doelOmschrijving` ,`doelWettelijkeGrondslag` )
                VALUES ('Doel_1', 'Bezoekers naar apen leiden', 'Partij_0', 'Bezoekers naar apen leiden', NULL)
                      , ('Doel_1a', 'Opslaan van al dan niet geannoteerde video\'s betreffende het gorilla eiland', 'Partij_0', 'Opslaan van al dan niet geannoteerde video\'s betreffende het gorilla eiland', NULL)
                      , ('Doel_1b', 'Hoogresoluut beeldmateriaal verzamelen', 'Partij_0', 'Verzamelen van hoogresoluut beeldmateriaal binnen het gorilla eiland.', NULL)
                      , ('Doel_1c', 'Annoteren van de hoogresoluut beeldmateriaal van het gorilla eiland.', 'Partij_0', 'Annoteren van de hoogresoluut beeldmateriaal van het gorilla eiland.', NULL)
                      , ('Doel_1d', 'Converteren en anonimiseren van beelden en annotaties.', 'Partij_0', 'Converteren van hoogresoluut naar laagresoluut beeldmateriaal en het anonimiseren van de bijbehorende annotaties.', NULL)
                      , ('Doel_1e', 'Tonen van de locaties van apen op de bezoekerszuilen.', 'Partij_0', 'Tonen van de locaties van apen op de bezoekerszuilen.', NULL)
                      , ('Doel_2', 'Gedrag van apen monitoren', 'Partij_0', 'Gedrag van apen monitoren', NULL)
                      , ('Doel_x1', 'Toegangsverlening tot bedrijfsterrein voor werknemers en bezoekers', 'Partij_TNO-T', 'Het automatisch toegang tot het bedrijfsterrein verschaffen van per auto reizende werknemers alsmede geregistreerde bezoekers van KPN Valley BV door middel van automatische kentekenherkenning op het voertuig.', NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /***************************************\
    * Plug Persoonsgegeven                  *
    *                                       *
    * fields:                               *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]  *
    * persoonsgegevensType  [UNI,TOT]       *
    * persoonsgegevensWaarde  [UNI,TOT]     *
    * betrokkene  [UNI,TOT]                 *
    * runtimeVerzamelendeService  [UNI,TOT] *
    \***************************************/
    mysql_query("CREATE TABLE `Persoonsgegeven`
                     ( `Persoonsgegeven` VARCHAR(255) DEFAULT NULL
                     , `persoonsgegevensType` VARCHAR(255) DEFAULT NULL
                     , `persoonsgegevensWaarde` VARCHAR(255) DEFAULT NULL
                     , `betrokkene` VARCHAR(255) DEFAULT NULL
                     , `runtimeVerzamelendeService` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Bericht                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * typeOf  [UNI,TOT]                    *
    * verstuurdNaar  [UNI,TOT]             *
    * verstuurdDoor  [UNI,TOT]             *
    \**************************************/
    mysql_query("CREATE TABLE `Bericht`
                     ( `Bericht` VARCHAR(255) DEFAULT NULL
                     , `typeOf` VARCHAR(255) DEFAULT NULL
                     , `verstuurdNaar` VARCHAR(255) DEFAULT NULL
                     , `verstuurdDoor` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug RuntimeDoel1                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * typeOf  [UNI,TOT]                    *
    \**************************************/
    mysql_query("CREATE TABLE `RuntimeDoel1`
                     ( `RuntimeDoel` VARCHAR(255) DEFAULT NULL
                     , `typeOf` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************\
    * Plug runtimeDoel2                  *
    *                                    *
    * fields:                            *
    * I/\runtimeDoel;runtimeDoel~  [ASY] *
    * runtimeDoel  []                    *
    \************************************/
    mysql_query("CREATE TABLE `runtimeDoel2`
                     ( `SvcInstantie` VARCHAR(255) DEFAULT NULL
                     , `RuntimeDoel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug SvcInstantie                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * typeOf  [UNI,TOT]                    *
    \**************************************/
    mysql_query("CREATE TABLE `SvcInstantie`
                     ( `SvcInstantie` VARCHAR(255) DEFAULT NULL
                     , `typeOf` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Partij                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * partijNaam  [UNI,TOT]                *
    \**************************************/
    mysql_query("CREATE TABLE `Partij`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     , `partijNaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Partij` (`Partij` ,`partijNaam` )
                VALUES ('Partij_0', 'Apenheul')
                      , ('Partij_1', 'Apen Bewakingsdiensten B.V.')
                      , ('Partij_TNO-T', 'TNO Telecom')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug NatuurlijkPersoon               *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * Betrokkene~  [INJ,SUR,UNI]           *
    \**************************************/
    mysql_query("CREATE TABLE `NatuurlijkPersoon`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Betrokkene` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug ServiceCategorie                *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `ServiceCategorie`
                     ( `ServiceCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `ServiceCategorie` (`ServiceCategorie` )
                VALUES ('ServiceCategorie')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug BerichtSoort                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `BerichtSoort`
                     ( `BerichtSoort` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `BerichtSoort` (`BerichtSoort` )
                VALUES ('BS_HiResVideo')
                      , ('BS_Annotaties')
                      , ('BS_AapLocatie')
                      , ('BS_AnonVideo')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Adres                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Adres`
                     ( `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Adres` (`Adres` )
                VALUES ('J.C. Wilslaan 21, 7313 HK Apeldoorn')
                      , ('Orlyplein 85, 1043 DS Amsterdam')
                      , ('Brassersplein 2, 2612 CT Delft')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug PartijNaam                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `PartijNaam`
                     ( `PartijNaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `PartijNaam` (`PartijNaam` )
                VALUES ('Apenheul')
                      , ('Apen Bewakingsdiensten B.V.')
                      , ('TNO Telecom')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug WettelijkeGrondslag             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `WettelijkeGrondslag`
                     ( `WettelijkeGrondslag` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug DoelID                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `DoelID`
                     ( `DoelID` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `DoelID` (`DoelID` )
                VALUES ('Bezoekers naar apen leiden')
                      , ('Opslaan van al dan niet geannoteerde video\'s betreffende het gorilla eiland')
                      , ('Hoogresoluut beeldmateriaal verzamelen')
                      , ('Annoteren van de hoogresoluut beeldmateriaal van het gorilla eiland.')
                      , ('Converteren en anonimiseren van beelden en annotaties.')
                      , ('Tonen van de locaties van apen op de bezoekerszuilen.')
                      , ('Gedrag van apen monitoren')
                      , ('Toegangsverlening tot bedrijfsterrein voor werknemers en bezoekers')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Bewaartermijn                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Bewaartermijn`
                     ( `Bewaartermijn` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Bewaartermijn` (`Bewaartermijn` )
                VALUES ('1 jaar')
                      , ('1 maand')
                      , ('1 minuut')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug SpecificatieSamenvatting        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `SpecificatieSamenvatting`
                     ( `SpecificatieSamenvatting` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `SpecificatieSamenvatting` (`SpecificatieSamenvatting` )
                VALUES ('Door middel van cameras wordt gedetecteerd waar zich apen bevinden. Op beeldschermen rond het apenverblijf wordt vervolgens getoond waar zich apen bevinden. Als zich ergens een voor de bezoekers interessante situatie voordoet, wordt dit erbij vermeld. Ook worden de videobeelden gebruikt om vroegtijdig situaties te signaleren waarin apen mogelijk gewelddadig gedrag gaan vertonen.')
                      , ('Door middel van verschillende camera\'s die zijn gericht op het gorilla eiland van de Apenheul wordt beeldmateriaal (zowel lage als hoge resolutie) opgenomen en opgeslagen.')
                      , ('Aan het beschikbare laag- en hoogresolute beeldmateriaal worden kenmerken gekoppeld (annoteren), zoals identifiers aan de hand waarvan apen kunnen worden geidentificeerd, ten behoeve van verdere verwerking.')
                      , ('Door middel van de annotaties van beeldmateriaal kan worden vastgesteld welke aap zich op welke locatie op de kaart van het gorilla eiland bevindt. Per aap wordt dit op de bezoekerszuilen weergegeven.')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug DoorgifteBuitenEU               *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `DoorgifteBuitenEU`
                     ( `DoorgifteBuitenEU` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug OntvangerCategorie              *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `OntvangerCategorie`
                     ( `OntvangerCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `OntvangerCategorie` (`OntvangerCategorie` )
                VALUES ('Bezoekers')
                      , ('Annotatie Service')
                      , ('Bezoekerskaart Service')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug GegevensCategorie               *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `GegevensCategorie`
                     ( `GegevensCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `GegevensCategorie` (`GegevensCategorie` )
                VALUES ('Fysieke kenmerken')
                      , ('GegevensCategorie')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug BetrokkeneCategorie             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `BetrokkeneCategorie`
                     ( `BetrokkeneCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `BetrokkeneCategorie` (`BetrokkeneCategorie` )
                VALUES ('Apen')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Omschrijving                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Omschrijving`
                     ( `Omschrijving` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Omschrijving` (`Omschrijving` )
                VALUES ('Het detecteren van de locatie van gorilla\'s en het publiceren ervan op bezoekerszuilen')
                      , ('Het opslaan van alle data die gerelateerd is aan AMS')
                      , ('Het op hoge resolutie opnemen van beelden van het gorilla eiland en deze in de AMS repository doen opslaan')
                      , ('Het annoteren van beeldmateriaal met identifiers van apen en andere kenmerken')
                      , ('Het anonimiseren van HI-RES naar LO-RES beeldmateriaal en het anonimiseren van de erbij horende annotaties')
                      , ('Het tonen, op een kaart, van de locatie van apen')
                      , ('Bezoekers naar apen leiden')
                      , ('Opslaan van al dan niet geannoteerde video\'s betreffende het gorilla eiland')
                      , ('Verzamelen van hoogresoluut beeldmateriaal binnen het gorilla eiland.')
                      , ('Annoteren van de hoogresoluut beeldmateriaal van het gorilla eiland.')
                      , ('Converteren van hoogresoluut naar laagresoluut beeldmateriaal en het anonimiseren van de bijbehorende annotaties.')
                      , ('Tonen van de locaties van apen op de bezoekerszuilen.')
                      , ('Gedrag van apen monitoren')
                      , ('Het automatisch toegang tot het bedrijfsterrein verschaffen van per auto reizende werknemers alsmede geregistreerde bezoekers van KPN Valley BV door middel van automatische kentekenherkenning op het voertuig.')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Naam                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Naam`
                     ( `Naam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Naam` (`Naam` )
                VALUES ('AMS')
                      , ('AMStore Service')
                      , ('Camera Service')
                      , ('Annotatie Service')
                      , ('Anonimisatie Service')
                      , ('Bezoekerskaart Service')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug PersoonsgegevensWaarde          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `PersoonsgegevensWaarde`
                     ( `PersoonsgegevensWaarde` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug PersoonsgegevensType            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `PersoonsgegevensType`
                     ( `PersoonsgegevensType` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `PersoonsgegevensType` (`PersoonsgegevensType` )
                VALUES ('HiResVideo')
                      , ('Aap Identifier')
                      , ('Aap Locatie')
                      , ('Aap Gezicht')
                      , ('LoResVideo')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug verzamelDoel                    *
    *                                      *
    * fields:                              *
    * I/\verzamelDoel;verzamelDoel~  [ASY] *
    * verzamelDoel  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `verzamelDoel`
                     ( `Persoonsgegeven` VARCHAR(255) DEFAULT NULL
                     , `Doel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************************************\
    * Plug verwerkingsVerantwoordelijke                                    *
    *                                                                      *
    * fields:                                                              *
    * I/\verwerkingsVerantwoordelijke;verwerkingsVerantwoordelijke~  [ASY] *
    * verwerkingsVerantwoordelijke  []                                     *
    \**********************************************************************/
    mysql_query("CREATE TABLE `verwerkingsVerantwoordelijke`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `Partij` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `verwerkingsVerantwoordelijke` (`Verwerking` ,`Partij` )
                VALUES ('Vw_AMS', 'Partij_0')
                      , ('Svc_AMStore', 'Partij_0')
                      , ('Svc_Camera', 'Partij_0')
                      , ('Svc_Annotatie', 'Partij_0')
                      , ('Svc_Anonimisatie', 'Partij_0')
                      , ('Svc_Bezoekerskaart', 'Partij_0')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug isDeelverwerkingVan                           *
    *                                                    *
    * fields:                                            *
    * I/\isDeelverwerkingVan;isDeelverwerkingVan~  [ASY] *
    * isDeelverwerkingVan  [ASY]                         *
    \****************************************************/
    mysql_query("CREATE TABLE `isDeelverwerkingVan`
                     ( `sVerwerking` VARCHAR(255) DEFAULT NULL
                     , `tVerwerking` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `isDeelverwerkingVan` (`sVerwerking` ,`tVerwerking` )
                VALUES ('Svc_AMStore', 'Vw_AMS')
                      , ('Svc_Camera', 'Vw_AMS')
                      , ('Svc_Annotatie', 'Vw_AMS')
                      , ('Svc_Anonimisatie', 'Vw_AMS')
                      , ('Svc_Bezoekerskaart', 'Vw_AMS')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug verwerkingBewerker                          *
    *                                                  *
    * fields:                                          *
    * I/\verwerkingBewerker;verwerkingBewerker~  [ASY] *
    * verwerkingBewerker  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `verwerkingBewerker`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `Partij` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug verwerkingsDoel                 *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * verwerkingsDoel  [TOT,SUR]           *
    \**************************************/
    mysql_query("CREATE TABLE `verwerkingsDoel`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `Doel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `verwerkingsDoel` (`Verwerking` ,`Doel` )
                VALUES ('Vw_AMS', 'Doel_1')
                      , ('Vw_AMS', 'Doel_2')
                      , ('Svc_AMStore', 'Doel_1a')
                      , ('Svc_Camera', 'Doel_1b')
                      , ('Svc_Annotatie', 'Doel_1c')
                      , ('Svc_Anonimisatie', 'Doel_1d')
                      , ('Svc_Bezoekerskaart', 'Doel_1e')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************************************\
    * Plug verwerkingBetrokkenenCategorie                                      *
    *                                                                          *
    * fields:                                                                  *
    * I/\verwerkingBetrokkenenCategorie;verwerkingBetrokkenenCategorie~  [ASY] *
    * verwerkingBetrokkenenCategorie  []                                       *
    \**************************************************************************/
    mysql_query("CREATE TABLE `verwerkingBetrokkenenCategorie`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `BetrokkeneCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `verwerkingBetrokkenenCategorie` (`Verwerking` ,`BetrokkeneCategorie` )
                VALUES ('Vw_AMS', 'Apen')
                      , ('Svc_AMStore', 'Apen')
                      , ('Svc_Camera', 'Apen')
                      , ('Svc_Annotatie', 'Apen')
                      , ('Svc_Anonimisatie', 'Apen')
                      , ('Svc_Bezoekerskaart', 'Apen')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************************************\
    * Plug verwerkingGegevensCategorie                                   *
    *                                                                    *
    * fields:                                                            *
    * I/\verwerkingGegevensCategorie;verwerkingGegevensCategorie~  [ASY] *
    * verwerkingGegevensCategorie  []                                    *
    \********************************************************************/
    mysql_query("CREATE TABLE `verwerkingGegevensCategorie`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `GegevensCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `verwerkingGegevensCategorie` (`Verwerking` ,`GegevensCategorie` )
                VALUES ('Vw_AMS', 'Fysieke kenmerken')
                      , ('Svc_AMStore', 'Fysieke kenmerken')
                      , ('Svc_Camera', 'Fysieke kenmerken')
                      , ('Svc_Annotatie', 'Fysieke kenmerken')
                      , ('Svc_Anonimisatie', 'Fysieke kenmerken')
                      , ('Svc_Bezoekerskaart', 'Fysieke kenmerken')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************************************\
    * Plug verwerkingOntvangerCategorie                                    *
    *                                                                      *
    * fields:                                                              *
    * I/\verwerkingOntvangerCategorie;verwerkingOntvangerCategorie~  [ASY] *
    * verwerkingOntvangerCategorie  []                                     *
    \**********************************************************************/
    mysql_query("CREATE TABLE `verwerkingOntvangerCategorie`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `OntvangerCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `verwerkingOntvangerCategorie` (`Verwerking` ,`OntvangerCategorie` )
                VALUES ('Vw_AMS', 'Bezoekers')
                      , ('Svc_AMStore', 'Bezoekers')
                      , ('Svc_Camera', 'Annotatie Service')
                      , ('Svc_Annotatie', 'Bezoekerskaart Service')
                      , ('Svc_Anonimisatie', 'Bezoekerskaart Service')
                      , ('Svc_Bezoekerskaart', 'Bezoekers')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug verwerkingOntvanger                           *
    *                                                    *
    * fields:                                            *
    * I/\verwerkingOntvanger;verwerkingOntvanger~  [ASY] *
    * verwerkingOntvanger  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `verwerkingOntvanger`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `Partij` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `verwerkingOntvanger` (`Verwerking` ,`Partij` )
                VALUES ('Vw_AMS', 'Partij_1')
                      , ('Svc_AMStore', 'Partij_1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************************************************\
    * Plug verwerkingGegevensDoorgiftenBuitenEU                                            *
    *                                                                                      *
    * fields:                                                                              *
    * I/\verwerkingGegevensDoorgiftenBuitenEU;verwerkingGegevensDoorgiftenBuitenEU~  [ASY] *
    * verwerkingGegevensDoorgiftenBuitenEU  []                                             *
    \**************************************************************************************/
    mysql_query("CREATE TABLE `verwerkingGegevensDoorgiftenBuitenEU`
                     ( `Verwerking` VARCHAR(255) DEFAULT NULL
                     , `DoorgifteBuitenEU` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug isSubdoelVan                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * isSubdoelVan  [ASY,TOT,SUR]          *
    \**************************************/
    mysql_query("CREATE TABLE `isSubdoelVan`
                     ( `sDoel` VARCHAR(255) DEFAULT NULL
                     , `tDoel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `isSubdoelVan` (`sDoel` ,`tDoel` )
                VALUES ('Doel_1a', 'Doel_1')
                      , ('Doel_1b', 'Doel_1')
                      , ('Doel_1c', 'Doel_1')
                      , ('Doel_1d', 'Doel_1')
                      , ('Doel_1e', 'Doel_1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************\
    * Plug doelGegevensType                        *
    *                                              *
    * fields:                                      *
    * I/\doelGegevensType;doelGegevensType~  [ASY] *
    * doelGegevensType  []                         *
    \**********************************************/
    mysql_query("CREATE TABLE `doelGegevensType`
                     ( `Doel` VARCHAR(255) DEFAULT NULL
                     , `PersoonsgegevensType` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug verenigbaarMet                      *
    *                                          *
    * fields:                                  *
    * I/\verenigbaarMet;verenigbaarMet~  [ASY] *
    * verenigbaarMet  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `verenigbaarMet`
                     ( `sDoel` VARCHAR(255) DEFAULT NULL
                     , `tDoel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************\
    * Plug partijAdres                   *
    *                                    *
    * fields:                            *
    * I/\partijAdres;partijAdres~  [ASY] *
    * partijAdres  []                    *
    \************************************/
    mysql_query("CREATE TABLE `partijAdres`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     , `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `partijAdres` (`Partij` ,`Adres` )
                VALUES ('Partij_0', 'J.C. Wilslaan 21, 7313 HK Apeldoorn')
                      , ('Partij_1', 'Orlyplein 85, 1043 DS Amsterdam')
                      , ('Partij_TNO-T', 'Brassersplein 2, 2612 CT Delft')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************************\
    * Plug berichtSoortGegevensType                                *
    *                                                              *
    * fields:                                                      *
    * I/\berichtSoortGegevensType;berichtSoortGegevensType~  [ASY] *
    * berichtSoortGegevensType  []                                 *
    \**************************************************************/
    mysql_query("CREATE TABLE `berichtSoortGegevensType`
                     ( `BerichtSoort` VARCHAR(255) DEFAULT NULL
                     , `PersoonsgegevensType` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `berichtSoortGegevensType` (`BerichtSoort` ,`PersoonsgegevensType` )
                VALUES ('BS_HiResVideo', 'HiResVideo')
                      , ('BS_Annotaties', 'HiResVideo')
                      , ('BS_Annotaties', 'Aap Identifier')
                      , ('BS_Annotaties', 'Aap Locatie')
                      , ('BS_Annotaties', 'Aap Gezicht')
                      , ('BS_AapLocatie', 'Aap Locatie')
                      , ('BS_AnonVideo', 'LoResVideo')
                      , ('BS_AnonVideo', 'Aap Locatie')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************************************************\
    * Plug definetimeVerzamelendeService                                     *
    *                                                                        *
    * fields:                                                                *
    * I/\definetimeVerzamelendeService;definetimeVerzamelendeService~  [ASY] *
    * definetimeVerzamelendeService  []                                      *
    \************************************************************************/
    mysql_query("CREATE TABLE `definetimeVerzamelendeService`
                     ( `PersoonsgegevensType` VARCHAR(255) DEFAULT NULL
                     , `Service` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `definetimeVerzamelendeService` (`PersoonsgegevensType` ,`Service` )
                VALUES ('HiResVideo', 'Svc_Camera')
                      , ('Aap Identifier', 'Svc_Annotatie')
                      , ('Aap Locatie', 'Svc_Annotatie')
                      , ('Aap Gezicht', 'Svc_Annotatie')
                      , ('LoResVideo', 'Svc_Anonimisatie')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************************************\
    * Plug definetimeVerwerkendeService                                    *
    *                                                                      *
    * fields:                                                              *
    * I/\definetimeVerwerkendeService;definetimeVerwerkendeService~  [ASY] *
    * definetimeVerwerkendeService  []                                     *
    \**********************************************************************/
    mysql_query("CREATE TABLE `definetimeVerwerkendeService`
                     ( `PersoonsgegevensType` VARCHAR(255) DEFAULT NULL
                     , `Service` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `definetimeVerwerkendeService` (`PersoonsgegevensType` ,`Service` )
                VALUES ('HiResVideo', 'Svc_Camera')
                      , ('HiResVideo', 'Svc_AMStore')
                      , ('Aap Identifier', 'Svc_AMStore')
                      , ('Aap Locatie', 'Svc_AMStore')
                      , ('Aap Gezicht', 'Svc_AMStore')
                      , ('LoResVideo', 'Svc_AMStore')
                      , ('Aap Identifier', 'Svc_Annotatie')
                      , ('Aap Locatie', 'Svc_Annotatie')
                      , ('Aap Gezicht', 'Svc_Annotatie')
                      , ('HiResVideo', 'Svc_Annotatie')
                      , ('LoResVideo', 'Svc_Anonimisatie')
                      , ('Aap Identifier', 'Svc_Anonimisatie')
                      , ('Aap Locatie', 'Svc_Anonimisatie')
                      , ('Aap Gezicht', 'Svc_Anonimisatie')
                      , ('HiResVideo', 'Svc_Anonimisatie')
                      , ('Aap Locatie', 'Svc_Bezoekerskaart')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************************\
    * Plug serviceGegevensCategorie                                *
    *                                                              *
    * fields:                                                      *
    * I/\serviceGegevensCategorie;serviceGegevensCategorie~  [ASY] *
    * serviceGegevensCategorie  []                                 *
    \**************************************************************/
    mysql_query("CREATE TABLE `serviceGegevensCategorie`
                     ( `Service` VARCHAR(255) DEFAULT NULL
                     , `GegevensCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `serviceGegevensCategorie` (`Service` ,`GegevensCategorie` )
                VALUES ('Svc_Bezoekerskaart', 'GegevensCategorie')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************************\
    * Plug serviceOntvangerCategorie                                 *
    *                                                                *
    * fields:                                                        *
    * I/\serviceOntvangerCategorie;serviceOntvangerCategorie~  [ASY] *
    * serviceOntvangerCategorie  []                                  *
    \****************************************************************/
    mysql_query("CREATE TABLE `serviceOntvangerCategorie`
                     ( `Service` VARCHAR(255) DEFAULT NULL
                     , `ServiceCategorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `serviceOntvangerCategorie` (`Service` ,`ServiceCategorie` )
                VALUES ('Svc_Bezoekerskaart', 'ServiceCategorie')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************\
    * Plug serviceOntvanger                        *
    *                                              *
    * fields:                                      *
    * I/\serviceOntvanger;serviceOntvanger~  [ASY] *
    * serviceOntvanger  []                         *
    \**********************************************/
    mysql_query("CREATE TABLE `serviceOntvanger`
                     ( `sService` VARCHAR(255) DEFAULT NULL
                     , `tService` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `serviceOntvanger` (`sService` ,`tService` )
                VALUES ('Svc_Camera', 'Svc_AMStore')
                      , ('Svc_Annotatie', 'Svc_AMStore')
                      , ('Svc_Anonimisatie', 'Svc_AMStore')
                      , ('Svc_Bezoekerskaart', 'Svc_AMStore')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug versturendeService                          *
    *                                                  *
    * fields:                                          *
    * I/\versturendeService;versturendeService~  [ASY] *
    * versturendeService  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `versturendeService`
                     ( `BerichtSoort` VARCHAR(255) DEFAULT NULL
                     , `Service` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `versturendeService` (`BerichtSoort` ,`Service` )
                VALUES ('BS_HiResVideo', 'Svc_Camera')
                      , ('BS_HiResVideo', 'Svc_AMStore')
                      , ('BS_Annotaties', 'Svc_Annotatie')
                      , ('BS_AapLocatie', 'Svc_AMStore')
                      , ('BS_AnonVideo', 'Svc_Anonimisatie')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug ontvangendeService                          *
    *                                                  *
    * fields:                                          *
    * I/\ontvangendeService;ontvangendeService~  [ASY] *
    * ontvangendeService  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `ontvangendeService`
                     ( `BerichtSoort` VARCHAR(255) DEFAULT NULL
                     , `Service` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `ontvangendeService` (`BerichtSoort` ,`Service` )
                VALUES ('BS_HiResVideo', 'Svc_AMStore')
                      , ('BS_HiResVideo', 'Svc_Annotatie')
                      , ('BS_HiResVideo', 'Svc_Anonimisatie')
                      , ('BS_Annotaties', 'Svc_AMStore')
                      , ('BS_AapLocatie', 'Svc_Bezoekerskaart')
                      , ('BS_AnonVideo', 'Svc_AMStore')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************************\
    * Plug runtimeVerwerkendeService                                 *
    *                                                                *
    * fields:                                                        *
    * I/\runtimeVerwerkendeService;runtimeVerwerkendeService~  [ASY] *
    * runtimeVerwerkendeService  []                                  *
    \****************************************************************/
    mysql_query("CREATE TABLE `runtimeVerwerkendeService`
                     ( `Persoonsgegeven` VARCHAR(255) DEFAULT NULL
                     , `Service` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************\
    * Plug gegevenInBericht                        *
    *                                              *
    * fields:                                      *
    * I/\gegevenInBericht;gegevenInBericht~  [ASY] *
    * gegevenInBericht  []                         *
    \**********************************************/
    mysql_query("CREATE TABLE `gegevenInBericht`
                     ( `Persoonsgegeven` VARCHAR(255) DEFAULT NULL
                     , `Bericht` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo '<div id="ResetSuccess"/>The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "Generics.php";
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT RETINA\n");
      fwrite($dumpfile, dumprel("persoonsgegevensType[Persoonsgegeven*PersoonsgegevensType]","SELECT DISTINCT `Persoonsgegeven`, `persoonsgegevensType` FROM `Persoonsgegeven` WHERE `Persoonsgegeven` IS NOT NULL AND `persoonsgegevensType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("persoonsgegevensWaarde[Persoonsgegeven*PersoonsgegevensWaarde]","SELECT DISTINCT `Persoonsgegeven`, `persoonsgegevensWaarde` FROM `Persoonsgegeven` WHERE `Persoonsgegeven` IS NOT NULL AND `persoonsgegevensWaarde` IS NOT NULL"));
      fwrite($dumpfile, dumprel("betrokkene[Persoonsgegeven*NatuurlijkPersoon]","SELECT DISTINCT `Persoonsgegeven`, `betrokkene` FROM `Persoonsgegeven` WHERE `Persoonsgegeven` IS NOT NULL AND `betrokkene` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verzamelDoel[Persoonsgegeven*Doel]","SELECT DISTINCT `Persoonsgegeven`, `Doel` FROM `verzamelDoel` WHERE `Persoonsgegeven` IS NOT NULL AND `Doel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingNaam[Verwerking*Naam]","SELECT DISTINCT `Verwerking`, `verwerkingNaam` FROM `Verwerking` WHERE `Verwerking` IS NOT NULL AND `verwerkingNaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingOmschrijving[Verwerking*Omschrijving]","SELECT DISTINCT `Verwerking`, `verwerkingOmschrijving` FROM `Verwerking` WHERE `Verwerking` IS NOT NULL AND `verwerkingOmschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingsVerantwoordelijke[Verwerking*Partij]","SELECT DISTINCT `Verwerking`, `Partij` FROM `verwerkingsVerantwoordelijke` WHERE `Verwerking` IS NOT NULL AND `Partij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isDeelverwerkingVan[Verwerking]","SELECT DISTINCT `sVerwerking`, `tVerwerking` FROM `isDeelverwerkingVan` WHERE `sVerwerking` IS NOT NULL AND `tVerwerking` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingBewerker[Verwerking*Partij]","SELECT DISTINCT `Verwerking`, `Partij` FROM `verwerkingBewerker` WHERE `Verwerking` IS NOT NULL AND `Partij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingsDoel[Verwerking*Doel]","SELECT DISTINCT `Verwerking`, `Doel` FROM `verwerkingsDoel` WHERE `Verwerking` IS NOT NULL AND `Doel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingBetrokkenenCategorie[Verwerking*BetrokkeneCategorie]","SELECT DISTINCT `Verwerking`, `BetrokkeneCategorie` FROM `verwerkingBetrokkenenCategorie` WHERE `Verwerking` IS NOT NULL AND `BetrokkeneCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingGegevensCategorie[Verwerking*GegevensCategorie]","SELECT DISTINCT `Verwerking`, `GegevensCategorie` FROM `verwerkingGegevensCategorie` WHERE `Verwerking` IS NOT NULL AND `GegevensCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingOntvangerCategorie[Verwerking*OntvangerCategorie]","SELECT DISTINCT `Verwerking`, `OntvangerCategorie` FROM `verwerkingOntvangerCategorie` WHERE `Verwerking` IS NOT NULL AND `OntvangerCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingOntvanger[Verwerking*Partij]","SELECT DISTINCT `Verwerking`, `Partij` FROM `verwerkingOntvanger` WHERE `Verwerking` IS NOT NULL AND `Partij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingGegevensDoorgiftenBuitenEU[Verwerking*DoorgifteBuitenEU]","SELECT DISTINCT `Verwerking`, `DoorgifteBuitenEU` FROM `verwerkingGegevensDoorgiftenBuitenEU` WHERE `Verwerking` IS NOT NULL AND `DoorgifteBuitenEU` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingSpecificatieSamenvatting[Verwerking*SpecificatieSamenvatting]","SELECT DISTINCT `Verwerking`, `verwerkingSpecificatieSamenvatting` FROM `Verwerking` WHERE `Verwerking` IS NOT NULL AND `verwerkingSpecificatieSamenvatting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verwerkingBewaartermijn[Verwerking*Bewaartermijn]","SELECT DISTINCT `Verwerking`, `verwerkingBewaartermijn` FROM `Verwerking` WHERE `Verwerking` IS NOT NULL AND `verwerkingBewaartermijn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doelID[Doel*DoelID]","SELECT DISTINCT `Doel`, `doelID` FROM `Doel` WHERE `Doel` IS NOT NULL AND `doelID` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gerechtvaardigdDoor[Doel*Partij]","SELECT DISTINCT `Doel`, `gerechtvaardigdDoor` FROM `Doel` WHERE `Doel` IS NOT NULL AND `gerechtvaardigdDoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doelOmschrijving[Doel*Omschrijving]","SELECT DISTINCT `Doel`, `doelOmschrijving` FROM `Doel` WHERE `Doel` IS NOT NULL AND `doelOmschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doelWettelijkeGrondslag[Doel*WettelijkeGrondslag]","SELECT DISTINCT `Doel`, `doelWettelijkeGrondslag` FROM `Doel` WHERE `Doel` IS NOT NULL AND `doelWettelijkeGrondslag` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isSubdoelVan[Doel]","SELECT DISTINCT `sDoel`, `tDoel` FROM `isSubdoelVan` WHERE `sDoel` IS NOT NULL AND `tDoel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doelGegevensType[Doel*PersoonsgegevensType]","SELECT DISTINCT `Doel`, `PersoonsgegevensType` FROM `doelGegevensType` WHERE `Doel` IS NOT NULL AND `PersoonsgegevensType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verenigbaarMet[Doel]","SELECT DISTINCT `sDoel`, `tDoel` FROM `verenigbaarMet` WHERE `sDoel` IS NOT NULL AND `tDoel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("partijNaam[Partij*PartijNaam]","SELECT DISTINCT `Partij`, `partijNaam` FROM `Partij` WHERE `Partij` IS NOT NULL AND `partijNaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("partijAdres[Partij*Adres]","SELECT DISTINCT `Partij`, `Adres` FROM `partijAdres` WHERE `Partij` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("berichtSoortGegevensType[BerichtSoort*PersoonsgegevensType]","SELECT DISTINCT `BerichtSoort`, `PersoonsgegevensType` FROM `berichtSoortGegevensType` WHERE `BerichtSoort` IS NOT NULL AND `PersoonsgegevensType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("definetimeVerzamelendeService[PersoonsgegevensType*Service]","SELECT DISTINCT `PersoonsgegevensType`, `Service` FROM `definetimeVerzamelendeService` WHERE `PersoonsgegevensType` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("definetimeVerwerkendeService[PersoonsgegevensType*Service]","SELECT DISTINCT `PersoonsgegevensType`, `Service` FROM `definetimeVerwerkendeService` WHERE `PersoonsgegevensType` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("serviceGegevensCategorie[Service*GegevensCategorie]","SELECT DISTINCT `Service`, `GegevensCategorie` FROM `serviceGegevensCategorie` WHERE `Service` IS NOT NULL AND `GegevensCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("serviceOntvangerCategorie[Service*ServiceCategorie]","SELECT DISTINCT `Service`, `ServiceCategorie` FROM `serviceOntvangerCategorie` WHERE `Service` IS NOT NULL AND `ServiceCategorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("serviceOntvanger[Service]","SELECT DISTINCT `sService`, `tService` FROM `serviceOntvanger` WHERE `sService` IS NOT NULL AND `tService` IS NOT NULL"));
      fwrite($dumpfile, dumprel("versturendeService[BerichtSoort*Service]","SELECT DISTINCT `BerichtSoort`, `Service` FROM `versturendeService` WHERE `BerichtSoort` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ontvangendeService[BerichtSoort*Service]","SELECT DISTINCT `BerichtSoort`, `Service` FROM `ontvangendeService` WHERE `BerichtSoort` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("typeOf[SvcInstantie*Service]","SELECT DISTINCT `SvcInstantie`, `typeOf` FROM `SvcInstantie` WHERE `SvcInstantie` IS NOT NULL AND `typeOf` IS NOT NULL"));
      fwrite($dumpfile, dumprel("typeOf[Bericht*BerichtSoort]","SELECT DISTINCT `Bericht`, `typeOf` FROM `Bericht` WHERE `Bericht` IS NOT NULL AND `typeOf` IS NOT NULL"));
      fwrite($dumpfile, dumprel("typeOf[RuntimeDoel*Doel]","SELECT DISTINCT `RuntimeDoel`, `typeOf` FROM `RuntimeDoel1` WHERE `RuntimeDoel` IS NOT NULL AND `typeOf` IS NOT NULL"));
      fwrite($dumpfile, dumprel("runtimeVerzamelendeService[Persoonsgegeven*Service]","SELECT DISTINCT `Persoonsgegeven`, `runtimeVerzamelendeService` FROM `Persoonsgegeven` WHERE `Persoonsgegeven` IS NOT NULL AND `runtimeVerzamelendeService` IS NOT NULL"));
      fwrite($dumpfile, dumprel("runtimeVerwerkendeService[Persoonsgegeven*Service]","SELECT DISTINCT `Persoonsgegeven`, `Service` FROM `runtimeVerwerkendeService` WHERE `Persoonsgegeven` IS NOT NULL AND `Service` IS NOT NULL"));
      fwrite($dumpfile, dumprel("runtimeDoel[SvcInstantie*RuntimeDoel]","SELECT DISTINCT `SvcInstantie`, `RuntimeDoel` FROM `runtimeDoel2` WHERE `SvcInstantie` IS NOT NULL AND `RuntimeDoel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verstuurdNaar[Bericht*SvcInstantie]","SELECT DISTINCT `Bericht`, `verstuurdNaar` FROM `Bericht` WHERE `Bericht` IS NOT NULL AND `verstuurdNaar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verstuurdDoor[Bericht*SvcInstantie]","SELECT DISTINCT `Bericht`, `verstuurdDoor` FROM `Bericht` WHERE `Bericht` IS NOT NULL AND `verstuurdDoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gegevenInBericht[Persoonsgegeven*Bericht]","SELECT DISTINCT `Persoonsgegeven`, `Bericht` FROM `gegevenInBericht` WHERE `Persoonsgegeven` IS NOT NULL AND `Bericht` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer($quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
