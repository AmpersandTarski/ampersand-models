<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass elsewhere
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('DEMO_VOG')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `DEMO_VOG` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('DEMO_VOG');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'DEMO_VOG'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Session timeout table
    if($columns = mysql_query("SHOW COLUMNS FROM `__SessionTimeout__`")){
        mysql_query("DROP TABLE `__SessionTimeout__`");
    }
    mysql_query("CREATE TABLE `__SessionTimeout__`
                         ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                         , `lastAccess` BIGINT NOT NULL
                         ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
    }
    mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                         ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 94
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `VOGAanvraag`")){
        mysql_query("DROP TABLE `VOGAanvraag`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `BurgerServiceNummer`")){
        mysql_query("DROP TABLE `BurgerServiceNummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `VOGAanvraagOrganisatieTemplate`")){
        mysql_query("DROP TABLE `VOGAanvraagOrganisatieTemplate`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `GBAVerwijzing`")){
        mysql_query("DROP TABLE `GBAVerwijzing`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `GemeentelijkeVOGZaak`")){
        mysql_query("DROP TABLE `GemeentelijkeVOGZaak`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Identificatiemiddel`")){
        mysql_query("DROP TABLE `Identificatiemiddel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Organisatie`")){
        mysql_query("DROP TABLE `Organisatie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `SESSION`")){
        mysql_query("DROP TABLE `SESSION`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Beslissing1`")){
        mysql_query("DROP TABLE `Beslissing1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `beslissing2`")){
        mysql_query("DROP TABLE `beslissing2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `beslissing3`")){
        mysql_query("DROP TABLE `beslissing3`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaak`")){
        mysql_query("DROP TABLE `Zaak`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Tekst`")){
        mysql_query("DROP TABLE `Tekst`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Artikel`")){
        mysql_query("DROP TABLE `Artikel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Feit1`")){
        mysql_query("DROP TABLE `Feit1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `feit2`")){
        mysql_query("DROP TABLE `feit2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Document`")){
        mysql_query("DROP TABLE `Document`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Strafblad1`")){
        mysql_query("DROP TABLE `Strafblad1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `strafblad2`")){
        mysql_query("DROP TABLE `strafblad2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Schriftelijke uitspraak`")){
        mysql_query("DROP TABLE `Schriftelijke uitspraak`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaakid`")){
        mysql_query("DROP TABLE `Zaakid`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Dagvaarding`")){
        mysql_query("DROP TABLE `Dagvaarding`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Berichtje`")){
        mysql_query("DROP TABLE `Berichtje`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Handtekening`")){
        mysql_query("DROP TABLE `Handtekening`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `IdentificatiemiddelID`")){
        mysql_query("DROP TABLE `IdentificatiemiddelID`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `KVKNummer`")){
        mysql_query("DROP TABLE `KVKNummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `OrganisatieVorm`")){
        mysql_query("DROP TABLE `OrganisatieVorm`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `VestigingsAdres`")){
        mysql_query("DROP TABLE `VestigingsAdres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `OrganisatieNaam`")){
        mysql_query("DROP TABLE `OrganisatieNaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Adres`")){
        mysql_query("DROP TABLE `Adres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Postcode`")){
        mysql_query("DROP TABLE `Postcode`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ToevoegingBijHuisnummer`")){
        mysql_query("DROP TABLE `ToevoegingBijHuisnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `LetterBijHuisnummer`")){
        mysql_query("DROP TABLE `LetterBijHuisnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `AanduidingBijHuisnummer`")){
        mysql_query("DROP TABLE `AanduidingBijHuisnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Huisnummer`")){
        mysql_query("DROP TABLE `Huisnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gemeentedeel`")){
        mysql_query("DROP TABLE `Gemeentedeel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Straatnaam`")){
        mysql_query("DROP TABLE `Straatnaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gemeente`")){
        mysql_query("DROP TABLE `Gemeente`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Nationaliteit`")){
        mysql_query("DROP TABLE `Nationaliteit`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Geslacht`")){
        mysql_query("DROP TABLE `Geslacht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gebiedsdeel`")){
        mysql_query("DROP TABLE `Gebiedsdeel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Land`")){
        mysql_query("DROP TABLE `Land`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `TitelPredikaat`")){
        mysql_query("DROP TABLE `TitelPredikaat`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Voorletters`")){
        mysql_query("DROP TABLE `Voorletters`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Voornamen`")){
        mysql_query("DROP TABLE `Voornamen`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Geslachtsnaam`")){
        mysql_query("DROP TABLE `Geslachtsnaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Displaynaam`")){
        mysql_query("DROP TABLE `Displaynaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Toelichting`")){
        mysql_query("DROP TABLE `Toelichting`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `AlgemeenScreeningsProfiel1`")){
        mysql_query("DROP TABLE `AlgemeenScreeningsProfiel1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `algemeenScreeningsProfiel2`")){
        mysql_query("DROP TABLE `algemeenScreeningsProfiel2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `SpecifiekScreeningsProfiel`")){
        mysql_query("DROP TABLE `SpecifiekScreeningsProfiel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `OverigOmschrijving`")){
        mysql_query("DROP TABLE `OverigOmschrijving`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Taakomschrijving`")){
        mysql_query("DROP TABLE `Taakomschrijving`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Functie`")){
        mysql_query("DROP TABLE `Functie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `OrgVOGTemplateID`")){
        mysql_query("DROP TABLE `OrgVOGTemplateID`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Motivatie`")){
        mysql_query("DROP TABLE `Motivatie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `COVOGZaakNummer`")){
        mysql_query("DROP TABLE `COVOGZaakNummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `COVOGOmAdviesGevraagdToelichting`")){
        mysql_query("DROP TABLE `COVOGOmAdviesGevraagdToelichting`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `PersisterenInDeAanvraagToelichting`")){
        mysql_query("DROP TABLE `PersisterenInDeAanvraagToelichting`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `BijzonderhedenGeconstateerdToelichting`")){
        mysql_query("DROP TABLE `BijzonderhedenGeconstateerdToelichting`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `GemeenteAanvraagnummer`")){
        mysql_query("DROP TABLE `GemeenteAanvraagnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `PasswordHandtekening`")){
        mysql_query("DROP TABLE `PasswordHandtekening`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `DigitaleHandtekening`")){
        mysql_query("DROP TABLE `DigitaleHandtekening`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Datum`")){
        mysql_query("DROP TABLE `Datum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Plaats`")){
        mysql_query("DROP TABLE `Plaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `EmailAddress`")){
        mysql_query("DROP TABLE `EmailAddress`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Telefoonnummer`")){
        mysql_query("DROP TABLE `Telefoonnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Password`")){
        mysql_query("DROP TABLE `Password`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Userid`")){
        mysql_query("DROP TABLE `Userid`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `JaNee`")){
        mysql_query("DROP TABLE `JaNee`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `IdentificatiemiddelNummer`")){
        mysql_query("DROP TABLE `IdentificatiemiddelNummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `IdentificatiemiddelSoort`")){
        mysql_query("DROP TABLE `IdentificatiemiddelSoort`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `covogOntvankelijkheidMotivatie`")){
        mysql_query("DROP TABLE `covogOntvankelijkheidMotivatie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaNationaliteit`")){
        mysql_query("DROP TABLE `gbaNationaliteit`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaVestigingsDatum`")){
        mysql_query("DROP TABLE `gbaVestigingsDatum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaStraatnaam`")){
        mysql_query("DROP TABLE `gbaStraatnaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaHuisnummer`")){
        mysql_query("DROP TABLE `gbaHuisnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaverwGeboortedatum`")){
        mysql_query("DROP TABLE `gbaverwGeboortedatum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaverwGeboorteplaats`")){
        mysql_query("DROP TABLE `gbaverwGeboorteplaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaverwGeboorteland`")){
        mysql_query("DROP TABLE `gbaverwGeboorteland`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaverwBSNDatum`")){
        mysql_query("DROP TABLE `gbaverwBSNDatum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `woonplaats`")){
        mysql_query("DROP TABLE `woonplaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `hrEigenaar`")){
        mysql_query("DROP TABLE `hrEigenaar`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `hrMedewerker`")){
        mysql_query("DROP TABLE `hrMedewerker`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `idmEmailAddress`")){
        mysql_query("DROP TABLE `idmEmailAddress`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `loginMet`")){
        mysql_query("DROP TABLE `loginMet`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ontvanger`")){
        mysql_query("DROP TABLE `ontvanger`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `aanhangig`")){
        mysql_query("DROP TABLE `aanhangig`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `vonnis`")){
        mysql_query("DROP TABLE `vonnis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `hoortbij`")){
        mysql_query("DROP TABLE `hoortbij`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `wijsdatum`")){
        mysql_query("DROP TABLE `wijsdatum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `artikelvoorschrift`")){
        mysql_query("DROP TABLE `artikelvoorschrift`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `omschrijvingartikel`")){
        mysql_query("DROP TABLE `omschrijvingartikel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `datumdelict`")){
        mysql_query("DROP TABLE `datumdelict`");
      }
    }
    /****************************************************************\
    * Plug VOGAanvraag                                               *
    *                                                                *
    * fields:                                                        *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                           *
    * vogAanvragerIDMSoort  [UNI]                                    *
    * vogAanvragerIDMNummer  [UNI]                                   *
    * vogAanvragerIDVastgesteld  [UNI]                               *
    * vogAanvragerUserid  [UNI]                                      *
    * vogAanvragerPassword  [UNI]                                    *
    * aanvragerTelefoonnummer  [UNI]                                 *
    * aanvragerEmailAddress  [UNI]                                   *
    * aanvragerOndertekeningPlaats  [UNI]                            *
    * aanvragerOndertekeningDatum  [UNI]                             *
    * aanvragerDigitaleHandtekening  [UNI]                           *
    * aanvragerPasswordHandtekening  [UNI]                           *
    * zijnDeLegesBetaald  [UNI]                                      *
    * vogAanvraagOrganisatieTemplate  [UNI]                          *
    * covogZaakNummer  [UNI]                                         *
    * isVOGWettelijkVerplicht  [UNI]                                 *
    * isAanvraagVereistDoorBuitenlandseWet  [UNI]                    *
    * isAanvraagNoodzakelijkOmRisicoVoorSamenlevingTeBeperken  [UNI] *
    * isErEenAanwijsbareBelanghebbendeDerde  [UNI]                   *
    * zijnDeTeBeschermenBelangenVanPriveAard  [UNI]                  *
    * isAanvraagOntvankelijk  [UNI]                                  *
    * vogAfgifteBesluit  [UNI]                                       *
    \****************************************************************/
    mysql_query("CREATE TABLE `VOGAanvraag`
                     ( `VOGAanvraag` VARCHAR(255) DEFAULT NULL
                     , `vogAanvragerIDMSoort` VARCHAR(255) DEFAULT NULL
                     , `vogAanvragerIDMNummer` VARCHAR(255) DEFAULT NULL
                     , `vogAanvragerIDVastgesteld` VARCHAR(255) DEFAULT NULL
                     , `vogAanvragerUserid` VARCHAR(255) DEFAULT NULL
                     , `vogAanvragerPassword` VARCHAR(255) DEFAULT NULL
                     , `aanvragerTelefoonnummer` VARCHAR(255) DEFAULT NULL
                     , `aanvragerEmailAddress` VARCHAR(255) DEFAULT NULL
                     , `aanvragerOndertekeningPlaats` VARCHAR(255) DEFAULT NULL
                     , `aanvragerOndertekeningDatum` VARCHAR(255) DEFAULT NULL
                     , `aanvragerDigitaleHandtekening` VARCHAR(255) DEFAULT NULL
                     , `aanvragerPasswordHandtekening` VARCHAR(255) DEFAULT NULL
                     , `zijnDeLegesBetaald` VARCHAR(255) DEFAULT NULL
                     , `vogAanvraagOrganisatieTemplate` VARCHAR(255) DEFAULT NULL
                     , `covogZaakNummer` VARCHAR(255) DEFAULT NULL
                     , `isVOGWettelijkVerplicht` VARCHAR(255) DEFAULT NULL
                     , `isAanvraagVereistDoorBuitenlandseWet` VARCHAR(255) DEFAULT NULL
                     , `isAanvraagNoodzakelijkOmRisicoVoorSamenlevingTeBeperken` VARCHAR(255) DEFAULT NULL
                     , `isErEenAanwijsbareBelanghebbendeDerde` VARCHAR(255) DEFAULT NULL
                     , `zijnDeTeBeschermenBelangenVanPriveAard` VARCHAR(255) DEFAULT NULL
                     , `isAanvraagOntvankelijk` VARCHAR(255) DEFAULT NULL
                     , `vogAfgifteBesluit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `VOGAanvraag` (`VOGAanvraag` ,`vogAanvragerIDMSoort` ,`vogAanvragerIDMNummer` ,`vogAanvragerIDVastgesteld` ,`vogAanvragerUserid` ,`vogAanvragerPassword` ,`aanvragerTelefoonnummer` ,`aanvragerEmailAddress` ,`aanvragerOndertekeningPlaats` ,`aanvragerOndertekeningDatum` ,`aanvragerDigitaleHandtekening` ,`aanvragerPasswordHandtekening` ,`zijnDeLegesBetaald` ,`vogAanvraagOrganisatieTemplate` ,`covogZaakNummer` ,`isVOGWettelijkVerplicht` ,`isAanvraagVereistDoorBuitenlandseWet` ,`isAanvraagNoodzakelijkOmRisicoVoorSamenlevingTeBeperken` ,`isErEenAanwijsbareBelanghebbendeDerde` ,`zijnDeTeBeschermenBelangenVanPriveAard` ,`isAanvraagOntvankelijk` ,`vogAfgifteBesluit` )
                VALUES ('VOGAanvraag_1330688459_533194', NULL, NULL, NULL, 'kljansen', '*****', '0612345678', 'kljansen@gmail.com', 'Peize', '03-03-2012', 'kljansen', '********', 'Ja', 'VOGAT_3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug BurgerServiceNummer               *
    *                                        *
    * fields:                                *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]   *
    * gbaBSN~  [UNI,INJ,SUR]                 *
    * strafrechtsketennummer~  [UNI,INJ,SUR] *
    * gbaDisplayNaam  [UNI]                  *
    * gbaGeslachtsnaam  [UNI]                *
    * gbaVoornamen  [UNI]                    *
    * gbaVoorletters  [UNI]                  *
    * gbaTitelPredikaat  [UNI]               *
    * gbaGeboortedatum  [UNI]                *
    * gbaGeboorteplaats  [UNI]               *
    * gbaGeboorteland  [UNI]                 *
    * gbaGeboorteGebiedsdeel  [UNI]          *
    * gbaGeslacht  [UNI]                     *
    * gbaGemeenteVanInschrijving  [UNI]      *
    * gbaGemeentedeel  [UNI]                 *
    * gbaAanduidingBijHuisnummer  [UNI]      *
    * gbaLetterBijHuisnummer  [UNI]          *
    * gbaToevoegingBijHuisnummer  [UNI]      *
    * gbaPostcode  [UNI]                     *
    * gbaDatumVestigingAdres  [UNI]          *
    * gbaBSNDatum  [UNI]                     *
    \****************************************/
    mysql_query("CREATE TABLE `BurgerServiceNummer`
                     ( `BurgerServiceNummer` VARCHAR(255) DEFAULT NULL
                     , `gbaBSN` VARCHAR(255) DEFAULT NULL
                     , `strafrechtsketennummer` VARCHAR(255) DEFAULT NULL
                     , `gbaDisplayNaam` VARCHAR(255) DEFAULT NULL
                     , `gbaGeslachtsnaam` VARCHAR(255) DEFAULT NULL
                     , `gbaVoornamen` VARCHAR(255) DEFAULT NULL
                     , `gbaVoorletters` VARCHAR(255) DEFAULT NULL
                     , `gbaTitelPredikaat` VARCHAR(255) DEFAULT NULL
                     , `gbaGeboortedatum` VARCHAR(255) DEFAULT NULL
                     , `gbaGeboorteplaats` VARCHAR(255) DEFAULT NULL
                     , `gbaGeboorteland` VARCHAR(255) DEFAULT NULL
                     , `gbaGeboorteGebiedsdeel` VARCHAR(255) DEFAULT NULL
                     , `gbaGeslacht` VARCHAR(255) DEFAULT NULL
                     , `gbaGemeenteVanInschrijving` VARCHAR(255) DEFAULT NULL
                     , `gbaGemeentedeel` VARCHAR(255) DEFAULT NULL
                     , `gbaAanduidingBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     , `gbaLetterBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     , `gbaToevoegingBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     , `gbaPostcode` VARCHAR(255) DEFAULT NULL
                     , `gbaDatumVestigingAdres` VARCHAR(255) DEFAULT NULL
                     , `gbaBSNDatum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `BurgerServiceNummer` (`BurgerServiceNummer` ,`gbaBSN` ,`strafrechtsketennummer` ,`gbaDisplayNaam` ,`gbaGeslachtsnaam` ,`gbaVoornamen` ,`gbaVoorletters` ,`gbaTitelPredikaat` ,`gbaGeboortedatum` ,`gbaGeboorteplaats` ,`gbaGeboorteland` ,`gbaGeboorteGebiedsdeel` ,`gbaGeslacht` ,`gbaGemeenteVanInschrijving` ,`gbaGemeentedeel` ,`gbaAanduidingBijHuisnummer` ,`gbaLetterBijHuisnummer` ,`gbaToevoegingBijHuisnummer` ,`gbaPostcode` ,`gbaDatumVestigingAdres` ,`gbaBSNDatum` )
                VALUES ('123456782', 'NatPers_1', NULL, 'Dhr. K.L. Jansen', 'Jansen', 'Klaas Leendert', 'K.L.', NULL, '03-05-1957', 'Peize', 'Nederland', NULL, 'Man', 'Noordenveld', 'Peize', NULL, NULL, NULL, '9301LZ', '05-03-2001', '01-01-1980')
                      , ('111222333', 'NatPers_2', '5159791', 'Dhr. A.M. van der Putten', 'van der Putten', 'Adelbert Maria', 'A.M.', NULL, '05-11-1986', 'Veere', 'Nederland', NULL, 'Man', 'Veere', NULL, NULL, NULL, NULL, '3022AX', '05-11-1986', '05-11-1986')
                      , ('345908756', 'NatPers_3', NULL, 'G.E. van der Weer', 'Weer', 'Gerrit Eduard', 'G.E.', NULL, '02-03-1959', 'Hilversum', 'Nederland', NULL, 'Man', 'Utrecht', 'Zuilen', NULL, NULL, NULL, '5678UT', '11-11-1991', '02-03-1959')
                      , ('345908757', 'NatPers_4', NULL, 'Mevr. Drs. A.C. Meester', 'Meester', 'Annie Clara', 'A.C.', 'Drs.', '02-03-1959', 'Hilversum', 'Nederland', NULL, 'Vrouw', 'Groningen', NULL, NULL, NULL, NULL, '9876GN', '11-11-1991', '02-03-1959')
                      , ('336078273', 'NatPers_5', NULL, 'Dhr. X. de Menner', 'Menner', 'Xaverius', 'X.', NULL, '12-07-1979', 'Zutphen', 'Nederland', NULL, 'Man', 'Amsterdam', NULL, NULL, NULL, NULL, '1023AD', '11-11-1991', '12-07-1979')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /*****************************************************\
    * Plug VOGAanvraagOrganisatieTemplate                 *
    *                                                     *
    * fields:                                             *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                *
    * orgVOGTemplateID  [UNI,TOT]                         *
    * organisatieUserid  [UNI]                            *
    * organisatiePassword  [UNI]                          *
    * organisatieDigitaleHandtekening  [UNI]              *
    * organisatiePasswordHandtekening  [UNI]              *
    * orgOrganisatie  [UNI,TOT]                           *
    * orgTelefoonnummer  [UNI]                            *
    * werkrelatie  [UNI]                                  *
    * functie  [UNI]                                      *
    * taakomschrijving  [UNI]                             *
    * overig  [UNI]                                       *
    * overigOmschrijving  [UNI]                           *
    * specifiekScreeningsProfielRelevant  [UNI]           *
    * specifiekScreeningsProfiel  [UNI]                   *
    * orgErZijnBijzondereOmstandigheden  [UNI]            *
    * orgErZijnBijzondereOmstandighedenToelichting  [UNI] *
    * orgOndertekeningPlaats  [UNI]                       *
    * orgOndertekeningDatum  [UNI]                        *
    \*****************************************************/
    mysql_query("CREATE TABLE `VOGAanvraagOrganisatieTemplate`
                     ( `VOGAanvraagOrganisatieTemplate` VARCHAR(255) DEFAULT NULL
                     , `orgVOGTemplateID` VARCHAR(255) DEFAULT NULL
                     , `organisatieUserid` VARCHAR(255) DEFAULT NULL
                     , `organisatiePassword` VARCHAR(255) DEFAULT NULL
                     , `organisatieDigitaleHandtekening` VARCHAR(255) DEFAULT NULL
                     , `organisatiePasswordHandtekening` VARCHAR(255) DEFAULT NULL
                     , `orgOrganisatie` VARCHAR(255) DEFAULT NULL
                     , `orgTelefoonnummer` VARCHAR(255) DEFAULT NULL
                     , `werkrelatie` VARCHAR(255) DEFAULT NULL
                     , `functie` VARCHAR(255) DEFAULT NULL
                     , `taakomschrijving` VARCHAR(255) DEFAULT NULL
                     , `overig` VARCHAR(255) DEFAULT NULL
                     , `overigOmschrijving` VARCHAR(255) DEFAULT NULL
                     , `specifiekScreeningsProfielRelevant` VARCHAR(255) DEFAULT NULL
                     , `specifiekScreeningsProfiel` VARCHAR(255) DEFAULT NULL
                     , `orgErZijnBijzondereOmstandigheden` VARCHAR(255) DEFAULT NULL
                     , `orgErZijnBijzondereOmstandighedenToelichting` VARCHAR(255) DEFAULT NULL
                     , `orgOndertekeningPlaats` VARCHAR(255) DEFAULT NULL
                     , `orgOndertekeningDatum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `VOGAanvraagOrganisatieTemplate` (`VOGAanvraagOrganisatieTemplate` ,`orgVOGTemplateID` ,`organisatieUserid` ,`organisatiePassword` ,`organisatieDigitaleHandtekening` ,`organisatiePasswordHandtekening` ,`orgOrganisatie` ,`orgTelefoonnummer` ,`werkrelatie` ,`functie` ,`taakomschrijving` ,`overig` ,`overigOmschrijving` ,`specifiekScreeningsProfielRelevant` ,`specifiekScreeningsProfiel` ,`orgErZijnBijzondereOmstandigheden` ,`orgErZijnBijzondereOmstandighedenToelichting` ,`orgOndertekeningPlaats` ,`orgOndertekeningDatum` )
                VALUES ('VOGAT_1', 'Financieel medewerker', 'acmeester@acme.com', '*****', 'acmeester@acme.com', '********', 'NHR_1', '0240723456', 'Ja', 'Financieel medewerker', 'zie bijlage', 'Nee', NULL, 'Ja', '95 Financiële dienstverlening', 'Nee', NULL, 'Apenhoven', '20-02-2002')
                      , ('VOGAT_2', 'Lidmaatschap', 'gevdweer', '*****', 'gevdweer', '********', 'NHR_2', '0101234567', 'Nee', NULL, NULL, 'Ja', 'Lidmaatschap schietvereniging', 'Ja', '85 Lidmaatschap schietvereniging', 'Nee', NULL, 'Amsterdam', '20-02-2002')
                      , ('VOGAT_3', 'Chauffeurskaart', 'xdemenner', '*****', 'xdemenner', '********', 'NHR_3', '010234523', 'Nee', NULL, NULL, 'Ja', 'Chauffeurskaart', 'Ja', '65 Taxibranche; chauffeurskaart', 'Nee', NULL, 'Amsterdam', '30-03-2006')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /***************************************\
    * Plug GBAVerwijzing                    *
    *                                       *
    * fields:                               *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]  *
    * gbaverwGeslachtsnaam  [UNI]           *
    * gbaverwVoornamen  [UNI]               *
    * gbaverwVoorletters  [UNI]             *
    * gbaverwTitelPredikaat  [UNI]          *
    * gbaverwGeboorteGebiedsdeel  [UNI]     *
    * gbaverwBSN  [UNI,TOT]                 *
    * gbaverwGemeenteVanInschrijving  [UNI] *
    * gbaverwVestigingsDatum  [UNI]         *
    * gbaverwStraatnaam  [UNI]              *
    * gbaverwHuisnummer  [UNI]              *
    * gbaverwAanduidingBijHuisnummer  [UNI] *
    * gbaverwLetterBijHuisnummer  [UNI]     *
    * gbaverwToevoegingBijHuisnummer  [UNI] *
    * gbaverwPostcode  [UNI]                *
    \***************************************/
    mysql_query("CREATE TABLE `GBAVerwijzing`
                     ( `GBAVerwijzing` VARCHAR(255) DEFAULT NULL
                     , `gbaverwGeslachtsnaam` VARCHAR(255) DEFAULT NULL
                     , `gbaverwVoornamen` VARCHAR(255) DEFAULT NULL
                     , `gbaverwVoorletters` VARCHAR(255) DEFAULT NULL
                     , `gbaverwTitelPredikaat` VARCHAR(255) DEFAULT NULL
                     , `gbaverwGeboorteGebiedsdeel` VARCHAR(255) DEFAULT NULL
                     , `gbaverwBSN` VARCHAR(255) DEFAULT NULL
                     , `gbaverwGemeenteVanInschrijving` VARCHAR(255) DEFAULT NULL
                     , `gbaverwVestigingsDatum` VARCHAR(255) DEFAULT NULL
                     , `gbaverwStraatnaam` VARCHAR(255) DEFAULT NULL
                     , `gbaverwHuisnummer` VARCHAR(255) DEFAULT NULL
                     , `gbaverwAanduidingBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     , `gbaverwLetterBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     , `gbaverwToevoegingBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     , `gbaverwPostcode` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /***********************************************\
    * Plug GemeentelijkeVOGZaak                     *
    *                                               *
    * fields:                                       *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]          *
    * gemeenteAanvraagnummer  [UNI,TOT]             *
    * gemAmbtenaarUserid  [UNI]                     *
    * gemAmbtenaarPassword  [UNI]                   *
    * gemLegesBetaald  [UNI,TOT,SUR]                *
    * gemVOGAanvraag  [INJ,UNI]                     *
    * bijzonderhedenGeconstateerd  [UNI]            *
    * bijzonderhedenGeconstateerdToelichting  [UNI] *
    * persisterenInDeAanvraag  [UNI]                *
    * persisterenInDeAanvraagToelichting  [UNI]     *
    * covogOmAdviesGevraagd  [UNI]                  *
    * covogOmAdviesGevraagdToelichting  [UNI]       *
    * gemOndertekeningDatum  [UNI]                  *
    * gemAmbtenaarDigitaleHandtekening  [UNI]       *
    * gemAmbtenaarPasswordHandtekening  [UNI]       *
    \***********************************************/
    mysql_query("CREATE TABLE `GemeentelijkeVOGZaak`
                     ( `GemeentelijkeVOGZaak` VARCHAR(255) DEFAULT NULL
                     , `gemeenteAanvraagnummer` VARCHAR(255) DEFAULT NULL
                     , `gemAmbtenaarUserid` VARCHAR(255) DEFAULT NULL
                     , `gemAmbtenaarPassword` VARCHAR(255) DEFAULT NULL
                     , `gemLegesBetaald` VARCHAR(255) DEFAULT NULL
                     , `gemVOGAanvraag` VARCHAR(255) DEFAULT NULL
                     , `bijzonderhedenGeconstateerd` VARCHAR(255) DEFAULT NULL
                     , `bijzonderhedenGeconstateerdToelichting` VARCHAR(255) DEFAULT NULL
                     , `persisterenInDeAanvraag` VARCHAR(255) DEFAULT NULL
                     , `persisterenInDeAanvraagToelichting` VARCHAR(255) DEFAULT NULL
                     , `covogOmAdviesGevraagd` VARCHAR(255) DEFAULT NULL
                     , `covogOmAdviesGevraagdToelichting` VARCHAR(255) DEFAULT NULL
                     , `gemOndertekeningDatum` VARCHAR(255) DEFAULT NULL
                     , `gemAmbtenaarDigitaleHandtekening` VARCHAR(255) DEFAULT NULL
                     , `gemAmbtenaarPasswordHandtekening` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Identificatiemiddel             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * idmDisplayName  [UNI,TOT]            *
    * idmSoort  [UNI,TOT]                  *
    * idmNummer  [UNI,TOT]                 *
    * idmUserid  [UNI]                     *
    * idmPassword  [UNI]                   *
    * idmDisplayHandtekening  [UNI]        *
    * idmDigitaleHandtekening  [UNI]       *
    * idmPasswordHandtekening  [UNI]       *
    * idmHouder  [UNI]                     *
    * idmOrganisatie  [UNI]                *
    * idmGemeente  [UNI]                   *
    * idmGemeentePlaats  [UNI]             *
    \**************************************/
    mysql_query("CREATE TABLE `Identificatiemiddel`
                     ( `Identificatiemiddel` VARCHAR(255) DEFAULT NULL
                     , `idmDisplayName` VARCHAR(255) DEFAULT NULL
                     , `idmSoort` VARCHAR(255) DEFAULT NULL
                     , `idmNummer` VARCHAR(255) DEFAULT NULL
                     , `idmUserid` VARCHAR(255) DEFAULT NULL
                     , `idmPassword` VARCHAR(255) DEFAULT NULL
                     , `idmDisplayHandtekening` VARCHAR(255) DEFAULT NULL
                     , `idmDigitaleHandtekening` VARCHAR(255) DEFAULT NULL
                     , `idmPasswordHandtekening` VARCHAR(255) DEFAULT NULL
                     , `idmHouder` VARCHAR(255) DEFAULT NULL
                     , `idmOrganisatie` VARCHAR(255) DEFAULT NULL
                     , `idmGemeente` VARCHAR(255) DEFAULT NULL
                     , `idmGemeentePlaats` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Identificatiemiddel` (`Identificatiemiddel` ,`idmDisplayName` ,`idmSoort` ,`idmNummer` ,`idmUserid` ,`idmPassword` ,`idmDisplayHandtekening` ,`idmDigitaleHandtekening` ,`idmPasswordHandtekening` ,`idmHouder` ,`idmOrganisatie` ,`idmGemeente` ,`idmGemeentePlaats` )
                VALUES ('DigiD_1', 'Dhr. K.L. Jansen', 'DigiD', '0123456789', 'kljansen', '*****', 'K.L. Jansen', 'kljansen', '********', '123456782', NULL, NULL, NULL)
                      , ('Rijbewijs_RDW678214', 'Dhr. K.L. Jansen', 'Rijbewijs', 'RDW678214', NULL, NULL, NULL, NULL, NULL, '123456782', NULL, NULL, NULL)
                      , ('GemID_1', 'R. Oden (Noordenveld)', 'GemeenteID', 'GID_Noordenveld_001', 'roden', '*****', 'R. Oden, gemeente Noordenveld', 'roden', '********', NULL, NULL, 'Noordenveld', 'Roden')
                      , ('EHvB_1', 'Mevr. Drs. A.C. Meester', 'EHvB', '87654321', 'acmeester@acme.com', '*****', 'A.C. Meester (ACME B.V.)', 'acmeester@acme.com', '********', '345908757', 'NHR_1', NULL, NULL)
                      , ('EHvB_2', 'Dhr. G.E. van der Weer', 'EHvB', '11471281', 'gevdweer', '*****', 'G.E. v.d. Weer (KNSA)', 'gevdweer', '********', '345908756', 'NHR_2', NULL, NULL)
                      , ('EHvB_3', 'Dhr. X. de Menner', 'EHvB', '16256731', 'xdemenner', '*****', 'X. de Menner (Taxi Taxi)', 'xdemenner', '********', '336078273', 'NHR_3', NULL, NULL)
                      , ('Rijkspas_423789', 'Mevr. C.O. v. Ogtrop', 'Rijkspas', 'RP423789', 'covogtrop', '*****', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('GemID_2', 'P.J. (Paula) de Vries', 'GemeenteID', 'GID_Amsterdam_4711', 'pjdevries', '*****', 'P.J. de Vries, ambtenaar', 'pjdevries', '********', NULL, NULL, 'Amsterdam', 'Amsterdam ZuidOost')
                      , ('P_453027177', 'Dhr. A.M. v.d. Putten', 'Paspoort', 'P453027177', NULL, NULL, NULL, NULL, NULL, '111222333', NULL, NULL, NULL)
                      , ('DigiD_2', 'Dhr. A.M. v.d. Putten', 'DigiD', '1123456789', 'amvdputten', '*****', 'A.M. v.d. Putten', 'amvdputten', '********', '111222333', NULL, NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Organisatie                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * hrOrganisatieNaam  [UNI,TOT]         *
    * hrVestigingsAdres  [UNI,TOT]         *
    * hrOrganisatieVorm  [UNI,TOT]         *
    * hrKVKNummer  [UNI,TOT]               *
    \**************************************/
    mysql_query("CREATE TABLE `Organisatie`
                     ( `Organisatie` VARCHAR(255) DEFAULT NULL
                     , `hrOrganisatieNaam` VARCHAR(255) DEFAULT NULL
                     , `hrVestigingsAdres` VARCHAR(255) DEFAULT NULL
                     , `hrOrganisatieVorm` VARCHAR(255) DEFAULT NULL
                     , `hrKVKNummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Organisatie` (`Organisatie` ,`hrOrganisatieNaam` ,`hrVestigingsAdres` ,`hrOrganisatieVorm` ,`hrKVKNummer` )
                VALUES ('NHR_1', 'Acme B.V.', 'Appelstraat 3, 9876XX Hoogelaend', 'B.V.', '12345678')
                      , ('NHR_2', 'Koninklijke Nederlandse Schietvereniging Amsterdam', 'Schietbaan 1, 1234AA Amsterdam', 'Vereniging', '87654321')
                      , ('NHR_3', 'Taxi Taxi', 'Vervoersweg 3, 1234ZZ Amsterdam', 'B.V.', '38765432')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug SESSION                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * sessionUserid  [UNI]                 *
    * sessionPassword  [UNI]               *
    \**************************************/
    mysql_query("CREATE TABLE `SESSION`
                     ( `SESSION` VARCHAR(255) DEFAULT NULL
                     , `sessionUserid` VARCHAR(255) DEFAULT NULL
                     , `sessionPassword` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Beslissing1                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Beslissing1`
                     ( `Beslissing` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Beslissing1` (`Beslissing` )
                VALUES ('08/02324 Rechtbank Leeuwarden')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug beslissing2                 *
    *                                  *
    * fields:                          *
    * I/\beslissing;beslissing~  [ASY] *
    * beslissing  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `beslissing2`
                     ( `Zaak` VARCHAR(255) DEFAULT NULL
                     , `Beslissing` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `beslissing2` (`Zaak` ,`Beslissing` )
                VALUES ('276452/KG 06-1398', '08/02324 Rechtbank Leeuwarden')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug beslissing3                 *
    *                                  *
    * fields:                          *
    * I/\beslissing;beslissing~  [ASY] *
    * beslissing  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `beslissing3`
                     ( `Schriftelijke uitspraak` VARCHAR(255) DEFAULT NULL
                     , `Beslissing` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `beslissing3` (`Schriftelijke uitspraak` ,`Beslissing` )
                VALUES ('SchrUitspraak-4', '08/02324 Rechtbank Leeuwarden')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaak                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Zaak`
                     ( `Zaak` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaak` (`Zaak` )
                VALUES ('276452/KG 06-1398')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Tekst                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Tekst`
                     ( `Tekst` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Tekst` (`Tekst` )
                VALUES ('Zware mishandeling met voorbedachte rade')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Artikel                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Artikel`
                     ( `Artikel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Artikel` (`Artikel` )
                VALUES ('Art. 303 Sr')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Feit1                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Feit1`
                     ( `Feit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Feit1` (`Feit` )
                VALUES ('Feit-12')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************\
    * Plug feit2           *
    *                      *
    * fields:              *
    * I/\feit;feit~  [ASY] *
    * feit  []             *
    \**********************/
    mysql_query("CREATE TABLE `feit2`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Feit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `feit2` (`Dagvaarding` ,`Feit` )
                VALUES ('Dag12345', 'Feit-12')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Document                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Document`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Document` (`Document` )
                VALUES ('Doc-123')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Strafblad1                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Strafblad1`
                     ( `Strafblad` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Strafblad1` (`Strafblad` )
                VALUES ('SB-12345')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug strafblad2                *
    *                                *
    * fields:                        *
    * I/\strafblad;strafblad~  [ASY] *
    * strafblad  []                  *
    \********************************/
    mysql_query("CREATE TABLE `strafblad2`
                     ( `Strafblad` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `strafblad2` (`Strafblad` ,`Document` )
                VALUES ('SB-12345', 'Doc-123')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Schriftelijke uitspraak         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Schriftelijke uitspraak`
                     ( `Schriftelijke uitspraak` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Schriftelijke uitspraak` (`Schriftelijke uitspraak` )
                VALUES ('SchrUitspraak-4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaakid                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Zaakid`
                     ( `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaakid` (`Zaakid` )
                VALUES ('276452/KG 06-1398')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Dagvaarding                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Dagvaarding`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Dagvaarding` (`Dagvaarding` )
                VALUES ('Dag12345')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Berichtje                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Berichtje`
                     ( `Berichtje` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Berichtje` (`Berichtje` )
                VALUES ('GemeenteID')
                      , ('EHvB')
                      , ('DigiD')
                      , ('Rijkspas')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Handtekening                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Handtekening`
                     ( `Handtekening` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Handtekening` (`Handtekening` )
                VALUES ('K.L. Jansen')
                      , ('R. Oden, gemeente Noordenveld')
                      , ('A.C. Meester (ACME B.V.)')
                      , ('G.E. v.d. Weer (KNSA)')
                      , ('X. de Menner (Taxi Taxi)')
                      , ('P.J. de Vries, ambtenaar')
                      , ('A.M. v.d. Putten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug IdentificatiemiddelID           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `IdentificatiemiddelID`
                     ( `IdentificatiemiddelID` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `IdentificatiemiddelID` (`IdentificatiemiddelID` )
                VALUES ('Dhr. K.L. Jansen')
                      , ('R. Oden (Noordenveld)')
                      , ('Mevr. Drs. A.C. Meester')
                      , ('Dhr. G.E. van der Weer')
                      , ('Dhr. X. de Menner')
                      , ('Mevr. C.O. v. Ogtrop')
                      , ('P.J. (Paula) de Vries')
                      , ('Dhr. A.M. v.d. Putten')
                      , ('U moet inloggen met uw GemeenteID')
                      , ('U moet inloggen met E-Herkenning')
                      , ('U moet inloggen met uw DigiD')
                      , ('U moet inloggen met uw Rijkspas')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug KVKNummer                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `KVKNummer`
                     ( `KVKNummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `KVKNummer` (`KVKNummer` )
                VALUES ('12345678')
                      , ('87654321')
                      , ('38765432')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug OrganisatieVorm                 *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `OrganisatieVorm`
                     ( `OrganisatieVorm` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `OrganisatieVorm` (`OrganisatieVorm` )
                VALUES ('B.V.')
                      , ('Vereniging')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug VestigingsAdres                 *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `VestigingsAdres`
                     ( `VestigingsAdres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `VestigingsAdres` (`VestigingsAdres` )
                VALUES ('Appelstraat 3, 9876XX Hoogelaend')
                      , ('Schietbaan 1, 1234AA Amsterdam')
                      , ('Vervoersweg 3, 1234ZZ Amsterdam')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug OrganisatieNaam                 *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `OrganisatieNaam`
                     ( `OrganisatieNaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `OrganisatieNaam` (`OrganisatieNaam` )
                VALUES ('Acme B.V.')
                      , ('Koninklijke Nederlandse Schietvereniging Amsterdam')
                      , ('Taxi Taxi')
                      , ('Raad voor Rechtsbijstand')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Adres                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Adres`
                     ( `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Postcode                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Postcode`
                     ( `Postcode` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Postcode` (`Postcode` )
                VALUES ('9301LZ')
                      , ('3022AX')
                      , ('5678UT')
                      , ('9876GN')
                      , ('1023AD')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug ToevoegingBijHuisnummer         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `ToevoegingBijHuisnummer`
                     ( `ToevoegingBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug LetterBijHuisnummer             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `LetterBijHuisnummer`
                     ( `LetterBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug AanduidingBijHuisnummer         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `AanduidingBijHuisnummer`
                     ( `AanduidingBijHuisnummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Huisnummer                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Huisnummer`
                     ( `Huisnummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Huisnummer` (`Huisnummer` )
                VALUES ('3')
                      , ('2')
                      , ('1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gemeentedeel                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Gemeentedeel`
                     ( `Gemeentedeel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gemeentedeel` (`Gemeentedeel` )
                VALUES ('Peize')
                      , ('Zuilen')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Straatnaam                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Straatnaam`
                     ( `Straatnaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Straatnaam` (`Straatnaam` )
                VALUES ('Eikenlaan')
                      , ('Vissersplein')
                      , ('Voltastraat')
                      , ('Herestraat')
                      , ('Zeedijk')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gemeente                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Gemeente`
                     ( `Gemeente` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gemeente` (`Gemeente` )
                VALUES ('Noordenveld')
                      , ('Veere')
                      , ('Utrecht')
                      , ('Groningen')
                      , ('Amsterdam')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Nationaliteit                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Nationaliteit`
                     ( `Nationaliteit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Nationaliteit` (`Nationaliteit` )
                VALUES ('Nederlandse')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Geslacht                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Geslacht`
                     ( `Geslacht` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Geslacht` (`Geslacht` )
                VALUES ('Man')
                      , ('Vrouw')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gebiedsdeel                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Gebiedsdeel`
                     ( `Gebiedsdeel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Land                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Land`
                     ( `Land` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Land` (`Land` )
                VALUES ('Nederland')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug TitelPredikaat                  *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `TitelPredikaat`
                     ( `TitelPredikaat` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `TitelPredikaat` (`TitelPredikaat` )
                VALUES ('Drs.')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Voorletters                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Voorletters`
                     ( `Voorletters` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Voorletters` (`Voorletters` )
                VALUES ('K.L.')
                      , ('A.M.')
                      , ('G.E.')
                      , ('A.C.')
                      , ('X.')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Voornamen                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Voornamen`
                     ( `Voornamen` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Voornamen` (`Voornamen` )
                VALUES ('Klaas Leendert')
                      , ('Adelbert Maria')
                      , ('Gerrit Eduard')
                      , ('Annie Clara')
                      , ('Xaverius')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Geslachtsnaam                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Geslachtsnaam`
                     ( `Geslachtsnaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Geslachtsnaam` (`Geslachtsnaam` )
                VALUES ('Jansen')
                      , ('van der Putten')
                      , ('Weer')
                      , ('Meester')
                      , ('Menner')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Displaynaam                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Displaynaam`
                     ( `Displaynaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Displaynaam` (`Displaynaam` )
                VALUES ('Dhr. K.L. Jansen')
                      , ('Dhr. A.M. van der Putten')
                      , ('G.E. van der Weer')
                      , ('Mevr. Drs. A.C. Meester')
                      , ('Dhr. X. de Menner')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Toelichting                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Toelichting`
                     ( `Toelichting` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug AlgemeenScreeningsProfiel1      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `AlgemeenScreeningsProfiel1`
                     ( `AlgemeenScreeningsProfiel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `AlgemeenScreeningsProfiel1` (`AlgemeenScreeningsProfiel` )
                VALUES ('85 Belast zijn met de zorg voor (hulpbehoevende) personen, zoals ouderen en gehandicapten')
                      , ('84 Belast zijn met de zorg voor minderjarigen')
                      , ('71 Personen die vanuit hun functie mensen en/of een organisatie (of een deel daarvan) aansturen')
                      , ('63 (Rijdend) vervoer waarbij personen worden vervoerd')
                      , ('62 (Rijdend) vervoer waarbij goederen, producten, post en pakketten worden getransporteerd en/of bezorgd, anders dan het intern transport binnen een bedrijf')
                      , ('61 Het onderhouden/ombouwen/bedienen van (productie)machines en/of apparaten, voertuigen en/of luchtvaartuigen')
                      , ('53 Beslissen over offertes (het voeren van onderhandelingen en het afsluiten van contracten) en het doen van aanbestedingen')
                      , ('43 Het verlenen van diensten in de persoonlijke leefomgeving')
                      , ('41 Het verlenen van diensten (advies, beveiliging, schoonmaak, catering, onderhoud, etc)')
                      , ('38 Het voorhanden hebben van stoffen, objecten en voorwerpen e.d., die bij oneigenlijk of onjuist gebruik een risico vormen voor mens (en dier)')
                      , ('37 Het beschikken over goederen')
                      , ('36 Het bewaken van productieprocessen')
                      , ('22 Budgetbevoegdheid hebben')
                      , ('21 Met contante en/of girale gelden en/of (digitale) waardepapieren omgaan')
                      , ('13 Kennis dragen van veiligheidssystemen, controlemechanismen en verificatieprocessen')
                      , ('12 Met gevoelige/vertrouwelijke informatie omgaan')
                      , ('11 Bevoegdheid hebben tot het raadplegen en/of bewerken van systemen')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************************\
    * Plug algemeenScreeningsProfiel2                                *
    *                                                                *
    * fields:                                                        *
    * I/\algemeenScreeningsProfiel;algemeenScreeningsProfiel~  [ASY] *
    * algemeenScreeningsProfiel  []                                  *
    \****************************************************************/
    mysql_query("CREATE TABLE `algemeenScreeningsProfiel2`
                     ( `VOGAanvraagOrganisatieTemplate` VARCHAR(255) DEFAULT NULL
                     , `AlgemeenScreeningsProfiel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug SpecifiekScreeningsProfiel      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `SpecifiekScreeningsProfiel`
                     ( `SpecifiekScreeningsProfiel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `SpecifiekScreeningsProfiel` (`SpecifiekScreeningsProfiel` )
                VALUES ('95 Financiële dienstverlening')
                      , ('85 Lidmaatschap schietvereniging')
                      , ('65 Taxibranche; chauffeurskaart')
                      , ('80 Beëdigd tolken/vertalers')
                      , ('75 (Gezins)voogd bij voogdijinstellingen, reclasseringswerker, raadsonderzoeker en maatschappelijk werker')
                      , ('70 Taxibranche; ondernemersvergunning')
                      , ('60 Onderwijs')
                      , ('55 Juridische dienstverlening')
                      , ('50 Exploitatievergunning')
                      , ('45 Gezondheidszorg en welzijn van mens en dier')
                      , ('40 Vakantiegezinnen en adoptie')
                      , ('25 (Buitengewoon) opsporingsambtenaar')
                      , ('06 Visum en emigratie')
                      , ('01 Politieke ambtsdragers')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug OverigOmschrijving              *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `OverigOmschrijving`
                     ( `OverigOmschrijving` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `OverigOmschrijving` (`OverigOmschrijving` )
                VALUES ('Lidmaatschap schietvereniging')
                      , ('Chauffeurskaart')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Taakomschrijving                *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Taakomschrijving`
                     ( `Taakomschrijving` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Taakomschrijving` (`Taakomschrijving` )
                VALUES ('zie bijlage')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Functie                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Functie`
                     ( `Functie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Functie` (`Functie` )
                VALUES ('Financieel medewerker')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug OrgVOGTemplateID                *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `OrgVOGTemplateID`
                     ( `OrgVOGTemplateID` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `OrgVOGTemplateID` (`OrgVOGTemplateID` )
                VALUES ('Financieel medewerker')
                      , ('Lidmaatschap')
                      , ('Chauffeurskaart')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Motivatie                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Motivatie`
                     ( `Motivatie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug COVOGZaakNummer                 *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `COVOGZaakNummer`
                     ( `COVOGZaakNummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /***************************************\
    * Plug COVOGOmAdviesGevraagdToelichting *
    *                                       *
    * fields:                               *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]  *
    \***************************************/
    mysql_query("CREATE TABLE `COVOGOmAdviesGevraagdToelichting`
                     ( `COVOGOmAdviesGevraagdToelichting` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /*****************************************\
    * Plug PersisterenInDeAanvraagToelichting *
    *                                         *
    * fields:                                 *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]    *
    \*****************************************/
    mysql_query("CREATE TABLE `PersisterenInDeAanvraagToelichting`
                     ( `PersisterenInDeAanvraagToelichting` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /*********************************************\
    * Plug BijzonderhedenGeconstateerdToelichting *
    *                                             *
    * fields:                                     *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]        *
    \*********************************************/
    mysql_query("CREATE TABLE `BijzonderhedenGeconstateerdToelichting`
                     ( `BijzonderhedenGeconstateerdToelichting` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug GemeenteAanvraagnummer          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `GemeenteAanvraagnummer`
                     ( `GemeenteAanvraagnummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug PasswordHandtekening            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `PasswordHandtekening`
                     ( `PasswordHandtekening` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `PasswordHandtekening` (`PasswordHandtekening` )
                VALUES ('********')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug DigitaleHandtekening            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `DigitaleHandtekening`
                     ( `DigitaleHandtekening` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `DigitaleHandtekening` (`DigitaleHandtekening` )
                VALUES ('kljansen')
                      , ('acmeester@acme.com')
                      , ('gevdweer')
                      , ('xdemenner')
                      , ('roden')
                      , ('pjdevries')
                      , ('amvdputten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Datum                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Datum`
                     ( `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Datum` (`Datum` )
                VALUES ('03-03-2012')
                      , ('20-02-2002')
                      , ('30-03-2006')
                      , ('03-05-1957')
                      , ('05-11-1986')
                      , ('02-03-1959')
                      , ('12-07-1979')
                      , ('05-03-2001')
                      , ('11-11-1991')
                      , ('01-01-1980')
                      , ('14-03-2008')
                      , ('03-12-2007')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Plaats                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Plaats`
                     ( `Plaats` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Plaats` (`Plaats` )
                VALUES ('Peize')
                      , ('Apenhoven')
                      , ('Amsterdam')
                      , ('Veere')
                      , ('Hilversum')
                      , ('Zutphen')
                      , ('Roden')
                      , ('Amsterdam ZuidOost')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug EmailAddress                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `EmailAddress`
                     ( `EmailAddress` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `EmailAddress` (`EmailAddress` )
                VALUES ('kljansen@gmail.com')
                      , ('amvdputten@gmail.com')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Telefoonnummer                  *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Telefoonnummer`
                     ( `Telefoonnummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Telefoonnummer` (`Telefoonnummer` )
                VALUES ('0612345678')
                      , ('0240723456')
                      , ('0101234567')
                      , ('010234523')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Password                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Password`
                     ( `Password` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Password` (`Password` )
                VALUES ('*****')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Userid                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Userid`
                     ( `Userid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Userid` (`Userid` )
                VALUES ('kljansen')
                      , ('acmeester@acme.com')
                      , ('gevdweer')
                      , ('xdemenner')
                      , ('roden')
                      , ('covogtrop')
                      , ('pjdevries')
                      , ('amvdputten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug JaNee                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `JaNee`
                     ( `JaNee` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `JaNee` (`JaNee` )
                VALUES ('Ja')
                      , ('Nee')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug IdentificatiemiddelNummer       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `IdentificatiemiddelNummer`
                     ( `IdentificatiemiddelNummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `IdentificatiemiddelNummer` (`IdentificatiemiddelNummer` )
                VALUES ('0123456789')
                      , ('RDW678214')
                      , ('GID_Noordenveld_001')
                      , ('87654321')
                      , ('11471281')
                      , ('16256731')
                      , ('RP423789')
                      , ('GID_Amsterdam_4711')
                      , ('P453027177')
                      , ('1123456789')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug IdentificatiemiddelSoort        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `IdentificatiemiddelSoort`
                     ( `IdentificatiemiddelSoort` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `IdentificatiemiddelSoort` (`IdentificatiemiddelSoort` )
                VALUES ('DigiD')
                      , ('Rijbewijs')
                      , ('GemeenteID')
                      , ('EHvB')
                      , ('Rijkspas')
                      , ('Paspoort')
                      , ('ID-kaart')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************************************\
    * Plug covogOntvankelijkheidMotivatie                                      *
    *                                                                          *
    * fields:                                                                  *
    * I/\covogOntvankelijkheidMotivatie;covogOntvankelijkheidMotivatie~  [ASY] *
    * covogOntvankelijkheidMotivatie  []                                       *
    \**************************************************************************/
    mysql_query("CREATE TABLE `covogOntvankelijkheidMotivatie`
                     ( `VOGAanvraag` VARCHAR(255) DEFAULT NULL
                     , `Motivatie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************\
    * Plug gbaNationaliteit                        *
    *                                              *
    * fields:                                      *
    * I/\gbaNationaliteit;gbaNationaliteit~  [ASY] *
    * gbaNationaliteit  []                         *
    \**********************************************/
    mysql_query("CREATE TABLE `gbaNationaliteit`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Nationaliteit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gbaNationaliteit` (`NatuurlijkPersoon` ,`Nationaliteit` )
                VALUES ('NatPers_1', 'Nederlandse')
                      , ('NatPers_2', 'Nederlandse')
                      , ('NatPers_3', 'Nederlandse')
                      , ('NatPers_4', 'Nederlandse')
                      , ('NatPers_5', 'Nederlandse')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug gbaVestigingsDatum                          *
    *                                                  *
    * fields:                                          *
    * I/\gbaVestigingsDatum;gbaVestigingsDatum~  [ASY] *
    * gbaVestigingsDatum  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `gbaVestigingsDatum`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gbaVestigingsDatum` (`NatuurlijkPersoon` ,`Datum` )
                VALUES ('NatPers_1', '05-03-2001')
                      , ('NatPers_2', '05-11-1986')
                      , ('NatPers_3', '11-11-1991')
                      , ('NatPers_4', '11-11-1991')
                      , ('NatPers_5', '11-11-1991')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug gbaStraatnaam                     *
    *                                        *
    * fields:                                *
    * I/\gbaStraatnaam;gbaStraatnaam~  [ASY] *
    * gbaStraatnaam  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `gbaStraatnaam`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Straatnaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gbaStraatnaam` (`NatuurlijkPersoon` ,`Straatnaam` )
                VALUES ('NatPers_1', 'Eikenlaan')
                      , ('NatPers_2', 'Vissersplein')
                      , ('NatPers_3', 'Voltastraat')
                      , ('NatPers_4', 'Herestraat')
                      , ('NatPers_5', 'Zeedijk')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug gbaHuisnummer                     *
    *                                        *
    * fields:                                *
    * I/\gbaHuisnummer;gbaHuisnummer~  [ASY] *
    * gbaHuisnummer  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `gbaHuisnummer`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Huisnummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gbaHuisnummer` (`NatuurlijkPersoon` ,`Huisnummer` )
                VALUES ('NatPers_1', '3')
                      , ('NatPers_2', '2')
                      , ('NatPers_3', '1')
                      , ('NatPers_4', '3')
                      , ('NatPers_5', '3')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************************\
    * Plug gbaverwGeboortedatum                            *
    *                                                      *
    * fields:                                              *
    * I/\gbaverwGeboortedatum;gbaverwGeboortedatum~  [ASY] *
    * gbaverwGeboortedatum  []                             *
    \******************************************************/
    mysql_query("CREATE TABLE `gbaverwGeboortedatum`
                     ( `GBAVerwijzing` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************************\
    * Plug gbaverwGeboorteplaats                             *
    *                                                        *
    * fields:                                                *
    * I/\gbaverwGeboorteplaats;gbaverwGeboorteplaats~  [ASY] *
    * gbaverwGeboorteplaats  []                              *
    \********************************************************/
    mysql_query("CREATE TABLE `gbaverwGeboorteplaats`
                     ( `GBAVerwijzing` VARCHAR(255) DEFAULT NULL
                     , `Plaats` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug gbaverwGeboorteland                           *
    *                                                    *
    * fields:                                            *
    * I/\gbaverwGeboorteland;gbaverwGeboorteland~  [ASY] *
    * gbaverwGeboorteland  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `gbaverwGeboorteland`
                     ( `GBAVerwijzing` VARCHAR(255) DEFAULT NULL
                     , `Land` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************\
    * Plug gbaverwBSNDatum                       *
    *                                            *
    * fields:                                    *
    * I/\gbaverwBSNDatum;gbaverwBSNDatum~  [ASY] *
    * gbaverwBSNDatum  []                        *
    \********************************************/
    mysql_query("CREATE TABLE `gbaverwBSNDatum`
                     ( `GBAVerwijzing` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug woonplaats                  *
    *                                  *
    * fields:                          *
    * I/\woonplaats;woonplaats~  [ASY] *
    * woonplaats  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `woonplaats`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug hrEigenaar                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * hrEigenaar  [TOT]                    *
    \**************************************/
    mysql_query("CREATE TABLE `hrEigenaar`
                     ( `Organisatie` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `hrEigenaar` (`Organisatie` ,`NatuurlijkPersoon` )
                VALUES ('NHR_1', 'NatPers_4')
                      , ('NHR_2', 'NatPers_4')
                      , ('NHR_3', 'NatPers_4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug hrMedewerker                    *
    *                                      *
    * fields:                              *
    * I/\hrMedewerker;hrMedewerker~  [ASY] *
    * hrMedewerker  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `hrMedewerker`
                     ( `Organisatie` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `hrMedewerker` (`Organisatie` ,`NatuurlijkPersoon` )
                VALUES ('NHR_1', 'NatPers_3')
                      , ('NHR_2', 'NatPers_3')
                      , ('NHR_3', 'NatPers_5')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************\
    * Plug idmEmailAddress                       *
    *                                            *
    * fields:                                    *
    * I/\idmEmailAddress;idmEmailAddress~  [ASY] *
    * idmEmailAddress  []                        *
    \********************************************/
    mysql_query("CREATE TABLE `idmEmailAddress`
                     ( `Identificatiemiddel` VARCHAR(255) DEFAULT NULL
                     , `EmailAddress` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `idmEmailAddress` (`Identificatiemiddel` ,`EmailAddress` )
                VALUES ('DigiD_1', 'kljansen@gmail.com')
                      , ('Rijbewijs_RDW678214', 'kljansen@gmail.com')
                      , ('DigiD_2', 'amvdputten@gmail.com')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug loginMet                *
    *                              *
    * fields:                      *
    * I/\loginMet;loginMet~  [ASY] *
    * loginMet  []                 *
    \******************************/
    mysql_query("CREATE TABLE `loginMet`
                     ( `Berichtje` VARCHAR(255) DEFAULT NULL
                     , `IdentificatiemiddelID` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `loginMet` (`Berichtje` ,`IdentificatiemiddelID` )
                VALUES ('GemeenteID', 'U moet inloggen met uw GemeenteID')
                      , ('EHvB', 'U moet inloggen met E-Herkenning')
                      , ('DigiD', 'U moet inloggen met uw DigiD')
                      , ('Rijkspas', 'U moet inloggen met uw Rijkspas')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug ontvanger                 *
    *                                *
    * fields:                        *
    * I/\ontvanger;ontvanger~  [ASY] *
    * ontvanger  []                  *
    \********************************/
    mysql_query("CREATE TABLE `ontvanger`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `ontvanger` (`Dagvaarding` ,`NatuurlijkPersoon` )
                VALUES ('Dag12345', 'NatPers_2')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug aanhangig                 *
    *                                *
    * fields:                        *
    * I/\aanhangig;aanhangig~  [ASY] *
    * aanhangig  []                  *
    \********************************/
    mysql_query("CREATE TABLE `aanhangig`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `aanhangig` (`Dagvaarding` ,`Zaakid` )
                VALUES ('Dag12345', '276452/KG 06-1398')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug vonnis              *
    *                          *
    * fields:                  *
    * I/\vonnis;vonnis~  [ASY] *
    * vonnis  []               *
    \**************************/
    mysql_query("CREATE TABLE `vonnis`
                     ( `Schriftelijke uitspraak` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `vonnis` (`Schriftelijke uitspraak` ,`Zaakid` )
                VALUES ('SchrUitspraak-4', '276452/KG 06-1398')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug hoortbij                *
    *                              *
    * fields:                      *
    * I/\hoortbij;hoortbij~  [ASY] *
    * hoortbij  []                 *
    \******************************/
    mysql_query("CREATE TABLE `hoortbij`
                     ( `Strafblad` VARCHAR(255) DEFAULT NULL
                     , `Strafrechtsketennummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `hoortbij` (`Strafblad` ,`Strafrechtsketennummer` )
                VALUES ('SB-12345', '5159791')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug wijsdatum                 *
    *                                *
    * fields:                        *
    * I/\wijsdatum;wijsdatum~  [ASY] *
    * wijsdatum  []                  *
    \********************************/
    mysql_query("CREATE TABLE `wijsdatum`
                     ( `Schriftelijke uitspraak` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `wijsdatum` (`Schriftelijke uitspraak` ,`Datum` )
                VALUES ('SchrUitspraak-4', '14-03-2008')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug artikelvoorschrift                          *
    *                                                  *
    * fields:                                          *
    * I/\artikelvoorschrift;artikelvoorschrift~  [ASY] *
    * artikelvoorschrift  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `artikelvoorschrift`
                     ( `Artikel` VARCHAR(255) DEFAULT NULL
                     , `Feit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `artikelvoorschrift` (`Artikel` ,`Feit` )
                VALUES ('Art. 303 Sr', 'Feit-12')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug omschrijvingartikel                           *
    *                                                    *
    * fields:                                            *
    * I/\omschrijvingartikel;omschrijvingartikel~  [ASY] *
    * omschrijvingartikel  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `omschrijvingartikel`
                     ( `Tekst` VARCHAR(255) DEFAULT NULL
                     , `Artikel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `omschrijvingartikel` (`Tekst` ,`Artikel` )
                VALUES ('Zware mishandeling met voorbedachte rade', 'Art. 303 Sr')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************\
    * Plug datumdelict                   *
    *                                    *
    * fields:                            *
    * I/\datumdelict;datumdelict~  [ASY] *
    * datumdelict  []                    *
    \************************************/
    mysql_query("CREATE TABLE `datumdelict`
                     ( `Feit` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `datumdelict` (`Feit` ,`Datum` )
                VALUES ('Feit-12', '03-12-2007')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo '<div id="ResetSuccess"/>The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "Generics.php";
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT VOG_Demo\n");
      fwrite($dumpfile, dumprel("vogAanvragerIDMSoort[VOGAanvraag*IdentificatiemiddelSoort]","SELECT DISTINCT `VOGAanvraag`, `vogAanvragerIDMSoort` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vogAanvragerIDMSoort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vogAanvragerIDMNummer[VOGAanvraag*IdentificatiemiddelNummer]","SELECT DISTINCT `VOGAanvraag`, `vogAanvragerIDMNummer` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vogAanvragerIDMNummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vogAanvragerIDVastgesteld[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `vogAanvragerIDVastgesteld` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vogAanvragerIDVastgesteld` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vogAanvragerUserid[VOGAanvraag*Userid]","SELECT DISTINCT `VOGAanvraag`, `vogAanvragerUserid` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vogAanvragerUserid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vogAanvragerPassword[VOGAanvraag*Password]","SELECT DISTINCT `VOGAanvraag`, `vogAanvragerPassword` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vogAanvragerPassword` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerTelefoonnummer[VOGAanvraag*Telefoonnummer]","SELECT DISTINCT `VOGAanvraag`, `aanvragerTelefoonnummer` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `aanvragerTelefoonnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerEmailAddress[VOGAanvraag*EmailAddress]","SELECT DISTINCT `VOGAanvraag`, `aanvragerEmailAddress` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `aanvragerEmailAddress` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerOndertekeningPlaats[VOGAanvraag*Plaats]","SELECT DISTINCT `VOGAanvraag`, `aanvragerOndertekeningPlaats` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `aanvragerOndertekeningPlaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerOndertekeningDatum[VOGAanvraag*Datum]","SELECT DISTINCT `VOGAanvraag`, `aanvragerOndertekeningDatum` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `aanvragerOndertekeningDatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerDigitaleHandtekening[VOGAanvraag*DigitaleHandtekening]","SELECT DISTINCT `VOGAanvraag`, `aanvragerDigitaleHandtekening` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `aanvragerDigitaleHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerPasswordHandtekening[VOGAanvraag*PasswordHandtekening]","SELECT DISTINCT `VOGAanvraag`, `aanvragerPasswordHandtekening` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `aanvragerPasswordHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zijnDeLegesBetaald[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `zijnDeLegesBetaald` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `zijnDeLegesBetaald` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vogAanvraagOrganisatieTemplate[VOGAanvraag*VOGAanvraagOrganisatieTemplate]","SELECT DISTINCT `VOGAanvraag`, `vogAanvraagOrganisatieTemplate` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vogAanvraagOrganisatieTemplate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemeenteAanvraagnummer[GemeentelijkeVOGZaak*GemeenteAanvraagnummer]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `gemeenteAanvraagnummer` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `gemeenteAanvraagnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemAmbtenaarUserid[GemeentelijkeVOGZaak*Userid]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `gemAmbtenaarUserid` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `gemAmbtenaarUserid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemAmbtenaarPassword[GemeentelijkeVOGZaak*Password]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `gemAmbtenaarPassword` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `gemAmbtenaarPassword` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemLegesBetaald[GemeentelijkeVOGZaak*JaNee]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `gemLegesBetaald` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `gemLegesBetaald` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemVOGAanvraag[GemeentelijkeVOGZaak*VOGAanvraag]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `gemVOGAanvraag` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `gemVOGAanvraag` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bijzonderhedenGeconstateerd[GemeentelijkeVOGZaak*JaNee]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `bijzonderhedenGeconstateerd` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `bijzonderhedenGeconstateerd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bijzonderhedenGeconstateerdToelichting[GemeentelijkeVOGZaak*BijzonderhedenGeconstateerdToelichting]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `bijzonderhedenGeconstateerdToelichting` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `bijzonderhedenGeconstateerdToelichting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("persisterenInDeAanvraag[GemeentelijkeVOGZaak*JaNee]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `persisterenInDeAanvraag` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `persisterenInDeAanvraag` IS NOT NULL"));
      fwrite($dumpfile, dumprel("persisterenInDeAanvraagToelichting[GemeentelijkeVOGZaak*PersisterenInDeAanvraagToelichting]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `persisterenInDeAanvraagToelichting` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `persisterenInDeAanvraagToelichting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("covogOmAdviesGevraagd[GemeentelijkeVOGZaak*JaNee]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `covogOmAdviesGevraagd` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `covogOmAdviesGevraagd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("covogOmAdviesGevraagdToelichting[GemeentelijkeVOGZaak*COVOGOmAdviesGevraagdToelichting]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `covogOmAdviesGevraagdToelichting` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `covogOmAdviesGevraagdToelichting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemOndertekeningDatum[GemeentelijkeVOGZaak*Datum]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `gemOndertekeningDatum` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `gemOndertekeningDatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemAmbtenaarDigitaleHandtekening[GemeentelijkeVOGZaak*DigitaleHandtekening]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `gemAmbtenaarDigitaleHandtekening` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `gemAmbtenaarDigitaleHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemAmbtenaarPasswordHandtekening[GemeentelijkeVOGZaak*PasswordHandtekening]","SELECT DISTINCT `GemeentelijkeVOGZaak`, `gemAmbtenaarPasswordHandtekening` FROM `GemeentelijkeVOGZaak` WHERE `GemeentelijkeVOGZaak` IS NOT NULL AND `gemAmbtenaarPasswordHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("covogZaakNummer[VOGAanvraag*COVOGZaakNummer]","SELECT DISTINCT `VOGAanvraag`, `covogZaakNummer` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `covogZaakNummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isVOGWettelijkVerplicht[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `isVOGWettelijkVerplicht` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `isVOGWettelijkVerplicht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isAanvraagVereistDoorBuitenlandseWet[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `isAanvraagVereistDoorBuitenlandseWet` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `isAanvraagVereistDoorBuitenlandseWet` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isAanvraagNoodzakelijkOmRisicoVoorSamenlevingTeBeperken[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `isAanvraagNoodzakelijkOmRisicoVoorSamenlevingTeBeperken` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `isAanvraagNoodzakelijkOmRisicoVoorSamenlevingTeBeperken` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isErEenAanwijsbareBelanghebbendeDerde[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `isErEenAanwijsbareBelanghebbendeDerde` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `isErEenAanwijsbareBelanghebbendeDerde` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zijnDeTeBeschermenBelangenVanPriveAard[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `zijnDeTeBeschermenBelangenVanPriveAard` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `zijnDeTeBeschermenBelangenVanPriveAard` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isAanvraagOntvankelijk[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `isAanvraagOntvankelijk` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `isAanvraagOntvankelijk` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vogAfgifteBesluit[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `vogAfgifteBesluit` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vogAfgifteBesluit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("covogOntvankelijkheidMotivatie[VOGAanvraag*Motivatie]","SELECT DISTINCT `VOGAanvraag`, `Motivatie` FROM `covogOntvankelijkheidMotivatie` WHERE `VOGAanvraag` IS NOT NULL AND `Motivatie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("orgVOGTemplateID[VOGAanvraagOrganisatieTemplate*OrgVOGTemplateID]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `orgVOGTemplateID` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `orgVOGTemplateID` IS NOT NULL"));
      fwrite($dumpfile, dumprel("organisatieUserid[VOGAanvraagOrganisatieTemplate*Userid]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `organisatieUserid` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `organisatieUserid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("organisatiePassword[VOGAanvraagOrganisatieTemplate*Password]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `organisatiePassword` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `organisatiePassword` IS NOT NULL"));
      fwrite($dumpfile, dumprel("organisatieDigitaleHandtekening[VOGAanvraagOrganisatieTemplate*DigitaleHandtekening]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `organisatieDigitaleHandtekening` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `organisatieDigitaleHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("organisatiePasswordHandtekening[VOGAanvraagOrganisatieTemplate*PasswordHandtekening]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `organisatiePasswordHandtekening` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `organisatiePasswordHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("orgOrganisatie[VOGAanvraagOrganisatieTemplate*Organisatie]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `orgOrganisatie` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `orgOrganisatie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("orgTelefoonnummer[VOGAanvraagOrganisatieTemplate*Telefoonnummer]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `orgTelefoonnummer` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `orgTelefoonnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("werkrelatie[VOGAanvraagOrganisatieTemplate*JaNee]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `werkrelatie` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `werkrelatie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("functie[VOGAanvraagOrganisatieTemplate*Functie]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `functie` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `functie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("taakomschrijving[VOGAanvraagOrganisatieTemplate*Taakomschrijving]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `taakomschrijving` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `taakomschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("overig[VOGAanvraagOrganisatieTemplate*JaNee]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `overig` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `overig` IS NOT NULL"));
      fwrite($dumpfile, dumprel("overigOmschrijving[VOGAanvraagOrganisatieTemplate*OverigOmschrijving]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `overigOmschrijving` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `overigOmschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("specifiekScreeningsProfielRelevant[VOGAanvraagOrganisatieTemplate*JaNee]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `specifiekScreeningsProfielRelevant` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `specifiekScreeningsProfielRelevant` IS NOT NULL"));
      fwrite($dumpfile, dumprel("specifiekScreeningsProfiel[VOGAanvraagOrganisatieTemplate*SpecifiekScreeningsProfiel]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `specifiekScreeningsProfiel` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `specifiekScreeningsProfiel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("algemeenScreeningsProfiel[VOGAanvraagOrganisatieTemplate*AlgemeenScreeningsProfiel]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `AlgemeenScreeningsProfiel` FROM `algemeenScreeningsProfiel2` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `AlgemeenScreeningsProfiel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("orgErZijnBijzondereOmstandigheden[VOGAanvraagOrganisatieTemplate*JaNee]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `orgErZijnBijzondereOmstandigheden` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `orgErZijnBijzondereOmstandigheden` IS NOT NULL"));
      fwrite($dumpfile, dumprel("orgErZijnBijzondereOmstandighedenToelichting[VOGAanvraagOrganisatieTemplate*Toelichting]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `orgErZijnBijzondereOmstandighedenToelichting` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `orgErZijnBijzondereOmstandighedenToelichting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("orgOndertekeningPlaats[VOGAanvraagOrganisatieTemplate*Plaats]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `orgOndertekeningPlaats` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `orgOndertekeningPlaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("orgOndertekeningDatum[VOGAanvraagOrganisatieTemplate*Datum]","SELECT DISTINCT `VOGAanvraagOrganisatieTemplate`, `orgOndertekeningDatum` FROM `VOGAanvraagOrganisatieTemplate` WHERE `VOGAanvraagOrganisatieTemplate` IS NOT NULL AND `orgOndertekeningDatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaDisplayNaam[NatuurlijkPersoon*Displaynaam]","SELECT DISTINCT `gbaBSN`, `gbaDisplayNaam` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaDisplayNaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeslachtsnaam[NatuurlijkPersoon*Geslachtsnaam]","SELECT DISTINCT `gbaBSN`, `gbaGeslachtsnaam` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaGeslachtsnaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaVoornamen[NatuurlijkPersoon*Voornamen]","SELECT DISTINCT `gbaBSN`, `gbaVoornamen` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaVoornamen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaVoorletters[NatuurlijkPersoon*Voorletters]","SELECT DISTINCT `gbaBSN`, `gbaVoorletters` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaVoorletters` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaTitelPredikaat[NatuurlijkPersoon*TitelPredikaat]","SELECT DISTINCT `gbaBSN`, `gbaTitelPredikaat` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaTitelPredikaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeboortedatum[NatuurlijkPersoon*Datum]","SELECT DISTINCT `gbaBSN`, `gbaGeboortedatum` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaGeboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeboorteplaats[NatuurlijkPersoon*Plaats]","SELECT DISTINCT `gbaBSN`, `gbaGeboorteplaats` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaGeboorteplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeboorteland[NatuurlijkPersoon*Land]","SELECT DISTINCT `gbaBSN`, `gbaGeboorteland` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaGeboorteland` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeboorteGebiedsdeel[NatuurlijkPersoon*Gebiedsdeel]","SELECT DISTINCT `gbaBSN`, `gbaGeboorteGebiedsdeel` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaGeboorteGebiedsdeel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeslacht[NatuurlijkPersoon*Geslacht]","SELECT DISTINCT `gbaBSN`, `gbaGeslacht` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaGeslacht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaNationaliteit[NatuurlijkPersoon*Nationaliteit]","SELECT DISTINCT `NatuurlijkPersoon`, `Nationaliteit` FROM `gbaNationaliteit` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Nationaliteit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGemeenteVanInschrijving[NatuurlijkPersoon*Gemeente]","SELECT DISTINCT `gbaBSN`, `gbaGemeenteVanInschrijving` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaGemeenteVanInschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaVestigingsDatum[NatuurlijkPersoon*Datum]","SELECT DISTINCT `NatuurlijkPersoon`, `Datum` FROM `gbaVestigingsDatum` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaStraatnaam[NatuurlijkPersoon*Straatnaam]","SELECT DISTINCT `NatuurlijkPersoon`, `Straatnaam` FROM `gbaStraatnaam` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Straatnaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGemeentedeel[NatuurlijkPersoon*Gemeentedeel]","SELECT DISTINCT `gbaBSN`, `gbaGemeentedeel` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaGemeentedeel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaHuisnummer[NatuurlijkPersoon*Huisnummer]","SELECT DISTINCT `NatuurlijkPersoon`, `Huisnummer` FROM `gbaHuisnummer` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Huisnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaAanduidingBijHuisnummer[NatuurlijkPersoon*AanduidingBijHuisnummer]","SELECT DISTINCT `gbaBSN`, `gbaAanduidingBijHuisnummer` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaAanduidingBijHuisnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaLetterBijHuisnummer[NatuurlijkPersoon*LetterBijHuisnummer]","SELECT DISTINCT `gbaBSN`, `gbaLetterBijHuisnummer` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaLetterBijHuisnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaToevoegingBijHuisnummer[NatuurlijkPersoon*ToevoegingBijHuisnummer]","SELECT DISTINCT `gbaBSN`, `gbaToevoegingBijHuisnummer` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaToevoegingBijHuisnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaPostcode[NatuurlijkPersoon*Postcode]","SELECT DISTINCT `gbaBSN`, `gbaPostcode` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaPostcode` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaDatumVestigingAdres[NatuurlijkPersoon*Datum]","SELECT DISTINCT `gbaBSN`, `gbaDatumVestigingAdres` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaDatumVestigingAdres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaBSN[NatuurlijkPersoon*BurgerServiceNummer]","SELECT DISTINCT `gbaBSN`, `BurgerServiceNummer` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `BurgerServiceNummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaBSNDatum[NatuurlijkPersoon*Datum]","SELECT DISTINCT `gbaBSN`, `gbaBSNDatum` FROM `BurgerServiceNummer` WHERE `gbaBSN` IS NOT NULL AND `gbaBSNDatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwGeslachtsnaam[GBAVerwijzing*Geslachtsnaam]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwGeslachtsnaam` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwGeslachtsnaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwVoornamen[GBAVerwijzing*Voornamen]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwVoornamen` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwVoornamen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwVoorletters[GBAVerwijzing*Voorletters]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwVoorletters` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwVoorletters` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwTitelPredikaat[GBAVerwijzing*TitelPredikaat]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwTitelPredikaat` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwTitelPredikaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwGeboortedatum[GBAVerwijzing*Datum]","SELECT DISTINCT `GBAVerwijzing`, `Datum` FROM `gbaverwGeboortedatum` WHERE `GBAVerwijzing` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwGeboorteplaats[GBAVerwijzing*Plaats]","SELECT DISTINCT `GBAVerwijzing`, `Plaats` FROM `gbaverwGeboorteplaats` WHERE `GBAVerwijzing` IS NOT NULL AND `Plaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwGeboorteland[GBAVerwijzing*Land]","SELECT DISTINCT `GBAVerwijzing`, `Land` FROM `gbaverwGeboorteland` WHERE `GBAVerwijzing` IS NOT NULL AND `Land` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwGeboorteGebiedsdeel[GBAVerwijzing*Gebiedsdeel]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwGeboorteGebiedsdeel` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwGeboorteGebiedsdeel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwBSN[GBAVerwijzing*BurgerServiceNummer]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwBSN` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwBSN` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwBSNDatum[GBAVerwijzing*Datum]","SELECT DISTINCT `GBAVerwijzing`, `Datum` FROM `gbaverwBSNDatum` WHERE `GBAVerwijzing` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwGemeenteVanInschrijving[GBAVerwijzing*Gemeente]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwGemeenteVanInschrijving` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwGemeenteVanInschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwVestigingsDatum[GBAVerwijzing*Datum]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwVestigingsDatum` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwVestigingsDatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwStraatnaam[GBAVerwijzing*Straatnaam]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwStraatnaam` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwStraatnaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwHuisnummer[GBAVerwijzing*Huisnummer]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwHuisnummer` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwHuisnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwAanduidingBijHuisnummer[GBAVerwijzing*AanduidingBijHuisnummer]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwAanduidingBijHuisnummer` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwAanduidingBijHuisnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwLetterBijHuisnummer[GBAVerwijzing*LetterBijHuisnummer]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwLetterBijHuisnummer` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwLetterBijHuisnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwToevoegingBijHuisnummer[GBAVerwijzing*ToevoegingBijHuisnummer]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwToevoegingBijHuisnummer` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwToevoegingBijHuisnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaverwPostcode[GBAVerwijzing*Postcode]","SELECT DISTINCT `GBAVerwijzing`, `gbaverwPostcode` FROM `GBAVerwijzing` WHERE `GBAVerwijzing` IS NOT NULL AND `gbaverwPostcode` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaats[NatuurlijkPersoon*Adres]","SELECT DISTINCT `NatuurlijkPersoon`, `Adres` FROM `woonplaats` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hrOrganisatieNaam[Organisatie*OrganisatieNaam]","SELECT DISTINCT `Organisatie`, `hrOrganisatieNaam` FROM `Organisatie` WHERE `Organisatie` IS NOT NULL AND `hrOrganisatieNaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hrVestigingsAdres[Organisatie*VestigingsAdres]","SELECT DISTINCT `Organisatie`, `hrVestigingsAdres` FROM `Organisatie` WHERE `Organisatie` IS NOT NULL AND `hrVestigingsAdres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hrOrganisatieVorm[Organisatie*OrganisatieVorm]","SELECT DISTINCT `Organisatie`, `hrOrganisatieVorm` FROM `Organisatie` WHERE `Organisatie` IS NOT NULL AND `hrOrganisatieVorm` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hrKVKNummer[Organisatie*KVKNummer]","SELECT DISTINCT `Organisatie`, `hrKVKNummer` FROM `Organisatie` WHERE `Organisatie` IS NOT NULL AND `hrKVKNummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hrEigenaar[Organisatie*NatuurlijkPersoon]","SELECT DISTINCT `Organisatie`, `NatuurlijkPersoon` FROM `hrEigenaar` WHERE `Organisatie` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hrMedewerker[Organisatie*NatuurlijkPersoon]","SELECT DISTINCT `Organisatie`, `NatuurlijkPersoon` FROM `hrMedewerker` WHERE `Organisatie` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmDisplayName[Identificatiemiddel*IdentificatiemiddelID]","SELECT DISTINCT `Identificatiemiddel`, `idmDisplayName` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmDisplayName` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmSoort[Identificatiemiddel*IdentificatiemiddelSoort]","SELECT DISTINCT `Identificatiemiddel`, `idmSoort` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmSoort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmNummer[Identificatiemiddel*IdentificatiemiddelNummer]","SELECT DISTINCT `Identificatiemiddel`, `idmNummer` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmNummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmUserid[Identificatiemiddel*Userid]","SELECT DISTINCT `Identificatiemiddel`, `idmUserid` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmUserid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmPassword[Identificatiemiddel*Password]","SELECT DISTINCT `Identificatiemiddel`, `idmPassword` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmPassword` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmDisplayHandtekening[Identificatiemiddel*Handtekening]","SELECT DISTINCT `Identificatiemiddel`, `idmDisplayHandtekening` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmDisplayHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmDigitaleHandtekening[Identificatiemiddel*DigitaleHandtekening]","SELECT DISTINCT `Identificatiemiddel`, `idmDigitaleHandtekening` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmDigitaleHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmPasswordHandtekening[Identificatiemiddel*PasswordHandtekening]","SELECT DISTINCT `Identificatiemiddel`, `idmPasswordHandtekening` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmPasswordHandtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmHouder[Identificatiemiddel*BurgerServiceNummer]","SELECT DISTINCT `Identificatiemiddel`, `idmHouder` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmHouder` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmOrganisatie[Identificatiemiddel*Organisatie]","SELECT DISTINCT `Identificatiemiddel`, `idmOrganisatie` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmOrganisatie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmGemeente[Identificatiemiddel*Gemeente]","SELECT DISTINCT `Identificatiemiddel`, `idmGemeente` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmGemeente` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmGemeentePlaats[Identificatiemiddel*Plaats]","SELECT DISTINCT `Identificatiemiddel`, `idmGemeentePlaats` FROM `Identificatiemiddel` WHERE `Identificatiemiddel` IS NOT NULL AND `idmGemeentePlaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("idmEmailAddress[Identificatiemiddel*EmailAddress]","SELECT DISTINCT `Identificatiemiddel`, `EmailAddress` FROM `idmEmailAddress` WHERE `Identificatiemiddel` IS NOT NULL AND `EmailAddress` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionUserid[SESSION*Userid]","SELECT DISTINCT `SESSION`, `sessionUserid` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionUserid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionPassword[SESSION*Password]","SELECT DISTINCT `SESSION`, `sessionPassword` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionPassword` IS NOT NULL"));
      fwrite($dumpfile, dumprel("loginMet[Berichtje*IdentificatiemiddelID]","SELECT DISTINCT `Berichtje`, `IdentificatiemiddelID` FROM `loginMet` WHERE `Berichtje` IS NOT NULL AND `IdentificatiemiddelID` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ontvanger[Dagvaarding*NatuurlijkPersoon]","SELECT DISTINCT `Dagvaarding`, `NatuurlijkPersoon` FROM `ontvanger` WHERE `Dagvaarding` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanhangig[Dagvaarding*Zaakid]","SELECT DISTINCT `Dagvaarding`, `Zaakid` FROM `aanhangig` WHERE `Dagvaarding` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vonnis[Schriftelijke uitspraak*Zaakid]","SELECT DISTINCT `Schriftelijke uitspraak`, `Zaakid` FROM `vonnis` WHERE `Schriftelijke uitspraak` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("strafblad[Strafblad*Document]","SELECT DISTINCT `Strafblad`, `Document` FROM `strafblad2` WHERE `Strafblad` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hoortbij[Strafblad*Strafrechtsketennummer]","SELECT DISTINCT `Strafblad`, `Strafrechtsketennummer` FROM `hoortbij` WHERE `Strafblad` IS NOT NULL AND `Strafrechtsketennummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("wijsdatum[Schriftelijke uitspraak*Datum]","SELECT DISTINCT `Schriftelijke uitspraak`, `Datum` FROM `wijsdatum` WHERE `Schriftelijke uitspraak` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("feit[Dagvaarding*Feit]","SELECT DISTINCT `Dagvaarding`, `Feit` FROM `feit2` WHERE `Dagvaarding` IS NOT NULL AND `Feit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("artikelvoorschrift[Artikel*Feit]","SELECT DISTINCT `Artikel`, `Feit` FROM `artikelvoorschrift` WHERE `Artikel` IS NOT NULL AND `Feit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omschrijvingartikel[Tekst*Artikel]","SELECT DISTINCT `Tekst`, `Artikel` FROM `omschrijvingartikel` WHERE `Tekst` IS NOT NULL AND `Artikel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("datumdelict[Feit*Datum]","SELECT DISTINCT `Feit`, `Datum` FROM `datumdelict` WHERE `Feit` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beslissing[Zaak*Beslissing]","SELECT DISTINCT `Zaak`, `Beslissing` FROM `beslissing2` WHERE `Zaak` IS NOT NULL AND `Beslissing` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beslissing[Schriftelijke uitspraak*Beslissing]","SELECT DISTINCT `Schriftelijke uitspraak`, `Beslissing` FROM `beslissing3` WHERE `Schriftelijke uitspraak` IS NOT NULL AND `Beslissing` IS NOT NULL"));
      fwrite($dumpfile, dumprel("strafrechtsketennummer[Strafrechtsketennummer*NatuurlijkPersoon]","SELECT DISTINCT `strafrechtsketennummer`, `gbaBSN` FROM `BurgerServiceNummer` WHERE `strafrechtsketennummer` IS NOT NULL AND `gbaBSN` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer($quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
