<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass elsewhere
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('mcpp_DEMO_WJG')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `mcpp_DEMO_WJG` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('mcpp_DEMO_WJG');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'mcpp_DEMO_WJG'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Session timeout table
    if($columns = mysql_query("SHOW COLUMNS FROM `__SessionTimeout__`")){
        mysql_query("DROP TABLE `__SessionTimeout__`");
    }
    mysql_query("CREATE TABLE `__SessionTimeout__`
                         ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                         , `lastAccess` BIGINT NOT NULL
                          ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
    }
    mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                          ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 20
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `NatuurlijkPersoon`")){
        mysql_query("DROP TABLE `NatuurlijkPersoon`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `VOGAanvraag`")){
        mysql_query("DROP TABLE `VOGAanvraag`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Authenticatiemiddel1`")){
        mysql_query("DROP TABLE `Authenticatiemiddel1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `authenticatiemiddel2`")){
        mysql_query("DROP TABLE `authenticatiemiddel2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `SESSION`")){
        mysql_query("DROP TABLE `SESSION`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Account`")){
        mysql_query("DROP TABLE `Account`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Aanvrager`")){
        mysql_query("DROP TABLE `Aanvrager`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `JaNee`")){
        mysql_query("DROP TABLE `JaNee`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Identificatienummer`")){
        mysql_query("DROP TABLE `Identificatienummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `AuthenticatiemiddelSoort`")){
        mysql_query("DROP TABLE `AuthenticatiemiddelSoort`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `EmailAddr1`")){
        mysql_query("DROP TABLE `EmailAddr1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `emailaddr2`")){
        mysql_query("DROP TABLE `emailaddr2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Role`")){
        mysql_query("DROP TABLE `Role`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Password`")){
        mysql_query("DROP TABLE `Password`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Userid`")){
        mysql_query("DROP TABLE `Userid`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gemeente`")){
        mysql_query("DROP TABLE `Gemeente`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Datum`")){
        mysql_query("DROP TABLE `Datum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Text`")){
        mysql_query("DROP TABLE `Text`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `roles`")){
        mysql_query("DROP TABLE `roles`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `isAmbtenaarBij`")){
        mysql_query("DROP TABLE `isAmbtenaarBij`");
      }
    }
    /**************************************\
    * Plug NatuurlijkPersoon               *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * gbaBSN  [INJ,SUR,UNI,TOT]            *
    * gbaAchternaam  [UNI,TOT]             *
    * gbaVoorletters  [UNI,TOT]            *
    * gbaVoornamen  [UNI,TOT]              *
    * gbaGeboortedatum  [UNI,TOT]          *
    * ingezeteneVan  [UNI]                 *
    \**************************************/
    mysql_query("CREATE TABLE `NatuurlijkPersoon`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `gbaBSN` VARCHAR(255) DEFAULT NULL
                     , `gbaAchternaam` VARCHAR(255) DEFAULT NULL
                     , `gbaVoorletters` VARCHAR(255) DEFAULT NULL
                     , `gbaVoornamen` VARCHAR(255) DEFAULT NULL
                     , `gbaGeboortedatum` VARCHAR(255) DEFAULT NULL
                     , `ingezeteneVan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /***************************************************\
    * Plug VOGAanvraag                                  *
    *                                                   *
    * fields:                                           *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]              *
    * doelVanDeAanvraag  [UNI]                          *
    * aanvrager  [UNI]                                  *
    * vastgesteldeIdentiteit  [UNI]                     *
    * ingediendBij  [UNI]                               *
    * volledigheidGegevensVOGAanvraagVastgesteld  [UNI] *
    \***************************************************/
    mysql_query("CREATE TABLE `VOGAanvraag`
                     ( `VOGAanvraag` VARCHAR(255) DEFAULT NULL
                     , `doelVanDeAanvraag` VARCHAR(255) DEFAULT NULL
                     , `aanvrager` VARCHAR(255) DEFAULT NULL
                     , `vastgesteldeIdentiteit` VARCHAR(255) DEFAULT NULL
                     , `ingediendBij` VARCHAR(255) DEFAULT NULL
                     , `volledigheidGegevensVOGAanvraagVastgesteld` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Authenticatiemiddel1            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * amSoort  [UNI,TOT]                   *
    * amNummer  [UNI,TOT]                  *
    * amHouder  [UNI,TOT]                  *
    \**************************************/
    mysql_query("CREATE TABLE `Authenticatiemiddel1`
                     ( `Authenticatiemiddel` VARCHAR(255) DEFAULT NULL
                     , `amSoort` VARCHAR(255) DEFAULT NULL
                     , `amNummer` VARCHAR(255) DEFAULT NULL
                     , `amHouder` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug authenticatiemiddel2                          *
    *                                                    *
    * fields:                                            *
    * I/\authenticatiemiddel;authenticatiemiddel~  [ASY] *
    * authenticatiemiddel  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `authenticatiemiddel2`
                     ( `Aanvrager` VARCHAR(255) DEFAULT NULL
                     , `Authenticatiemiddel` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug SESSION                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * sessionUser  [UNI]                   *
    * sessionPassword  [UNI]               *
    \**************************************/
    mysql_query("CREATE TABLE `SESSION`
                     ( `SESSION` VARCHAR(255) DEFAULT NULL
                     , `sessionUser` VARCHAR(255) DEFAULT NULL
                     , `sessionPassword` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Account                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * userid  [UNI,TOT]                    *
    * password  [UNI,TOT]                  *
    \**************************************/
    mysql_query("CREATE TABLE `Account`
                     ( `Account` VARCHAR(255) DEFAULT NULL
                     , `userid` VARCHAR(255) DEFAULT NULL
                     , `password` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Aanvrager                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * aanvragerVoornamen  [UNI]            *
    * aanvragerGeboortedatum  [UNI]        *
    \**************************************/
    mysql_query("CREATE TABLE `Aanvrager`
                     ( `Aanvrager` VARCHAR(255) DEFAULT NULL
                     , `aanvragerVoornamen` VARCHAR(255) DEFAULT NULL
                     , `aanvragerGeboortedatum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug JaNee                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `JaNee`
                     ( `JaNee` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `JaNee` (`JaNee` )
                VALUES ('Nee')
                      , ('Ja')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Identificatienummer             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Identificatienummer`
                     ( `Identificatienummer` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug AuthenticatiemiddelSoort        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `AuthenticatiemiddelSoort`
                     ( `AuthenticatiemiddelSoort` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `AuthenticatiemiddelSoort` (`AuthenticatiemiddelSoort` )
                VALUES ('DigiD')
                      , ('Rijbewijs')
                      , ('ID-kaart')
                      , ('Paspoort')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug EmailAddr1                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `EmailAddr1`
                     ( `EmailAddr` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug emailaddr2                *
    *                                *
    * fields:                        *
    * I/\emailaddr;emailaddr~  [ASY] *
    * emailaddr  []                  *
    \********************************/
    mysql_query("CREATE TABLE `emailaddr2`
                     ( `Account` VARCHAR(255) DEFAULT NULL
                     , `EmailAddr` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Role                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Role`
                     ( `Role` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Password                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Password`
                     ( `Password` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Userid                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Userid`
                     ( `Userid` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gemeente                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Gemeente`
                     ( `Gemeente` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Datum                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Datum`
                     ( `Datum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Text                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Text`
                     ( `Text` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************\
    * Plug roles             *
    *                        *
    * fields:                *
    * I/\roles;roles~  [ASY] *
    * roles  []              *
    \************************/
    mysql_query("CREATE TABLE `roles`
                     ( `Account` VARCHAR(255) DEFAULT NULL
                     , `Role` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug isAmbtenaarBij                      *
    *                                          *
    * fields:                                  *
    * I/\isAmbtenaarBij;isAmbtenaarBij~  [ASY] *
    * isAmbtenaarBij  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `isAmbtenaarBij`
                     ( `Account` VARCHAR(255) DEFAULT NULL
                     , `Gemeente` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo '<div id="ResetSuccess"/>The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT DEMO_WJG\n");
      fwrite($dumpfile, dumprel("doelVanDeAanvraag[VOGAanvraag*Text]","SELECT DISTINCT `VOGAanvraag`, `doelVanDeAanvraag` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `doelVanDeAanvraag` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvrager[VOGAanvraag*Aanvrager]","SELECT DISTINCT `VOGAanvraag`, `aanvrager` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `aanvrager` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerVoornamen[Aanvrager*Text]","SELECT DISTINCT `Aanvrager`, `aanvragerVoornamen` FROM `Aanvrager` WHERE `Aanvrager` IS NOT NULL AND `aanvragerVoornamen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerGeboortedatum[Aanvrager*Datum]","SELECT DISTINCT `Aanvrager`, `aanvragerGeboortedatum` FROM `Aanvrager` WHERE `Aanvrager` IS NOT NULL AND `aanvragerGeboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("authenticatiemiddel[Aanvrager*Authenticatiemiddel]","SELECT DISTINCT `Aanvrager`, `Authenticatiemiddel` FROM `authenticatiemiddel2` WHERE `Aanvrager` IS NOT NULL AND `Authenticatiemiddel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vastgesteldeIdentiteit[VOGAanvraag*NatuurlijkPersoon]","SELECT DISTINCT `VOGAanvraag`, `vastgesteldeIdentiteit` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vastgesteldeIdentiteit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ingediendBij[VOGAanvraag*Gemeente]","SELECT DISTINCT `VOGAanvraag`, `ingediendBij` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `ingediendBij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("userid[Account*Userid]","SELECT DISTINCT `Account`, `userid` FROM `Account` WHERE `Account` IS NOT NULL AND `userid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("password[Account*Password]","SELECT DISTINCT `Account`, `password` FROM `Account` WHERE `Account` IS NOT NULL AND `password` IS NOT NULL"));
      fwrite($dumpfile, dumprel("roles[Account*Role]","SELECT DISTINCT `Account`, `Role` FROM `roles` WHERE `Account` IS NOT NULL AND `Role` IS NOT NULL"));
      fwrite($dumpfile, dumprel("emailaddr[Account*EmailAddr]","SELECT DISTINCT `Account`, `EmailAddr` FROM `emailaddr2` WHERE `Account` IS NOT NULL AND `EmailAddr` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionUser[SESSION*Userid]","SELECT DISTINCT `SESSION`, `sessionUser` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionUser` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionPassword[SESSION*Password]","SELECT DISTINCT `SESSION`, `sessionPassword` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionPassword` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isAmbtenaarBij[Account*Gemeente]","SELECT DISTINCT `Account`, `Gemeente` FROM `isAmbtenaarBij` WHERE `Account` IS NOT NULL AND `Gemeente` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaBSN[NatuurlijkPersoon*BurgerServiceNummer]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaBSN` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaBSN` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaAchternaam[NatuurlijkPersoon*Text]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaAchternaam` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaAchternaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaVoorletters[NatuurlijkPersoon*Text]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaVoorletters` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaVoorletters` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaVoornamen[NatuurlijkPersoon*Text]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaVoornamen` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaVoornamen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeboortedatum[NatuurlijkPersoon*Datum]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaGeboortedatum` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaGeboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ingezeteneVan[NatuurlijkPersoon*Gemeente]","SELECT DISTINCT `NatuurlijkPersoon`, `ingezeteneVan` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `ingezeteneVan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("amSoort[Authenticatiemiddel*AuthenticatiemiddelSoort]","SELECT DISTINCT `Authenticatiemiddel`, `amSoort` FROM `Authenticatiemiddel1` WHERE `Authenticatiemiddel` IS NOT NULL AND `amSoort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("amNummer[Authenticatiemiddel*Identificatienummer]","SELECT DISTINCT `Authenticatiemiddel`, `amNummer` FROM `Authenticatiemiddel1` WHERE `Authenticatiemiddel` IS NOT NULL AND `amNummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("amHouder[Authenticatiemiddel*BurgerServiceNummer]","SELECT DISTINCT `Authenticatiemiddel`, `amHouder` FROM `Authenticatiemiddel1` WHERE `Authenticatiemiddel` IS NOT NULL AND `amHouder` IS NOT NULL"));
      fwrite($dumpfile, dumprel("volledigheidGegevensVOGAanvraagVastgesteld[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `volledigheidGegevensVOGAanvraagVastgesteld` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `volledigheidGegevensVOGAanvraagVastgesteld` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("mcpp_DEMO_WJG", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
