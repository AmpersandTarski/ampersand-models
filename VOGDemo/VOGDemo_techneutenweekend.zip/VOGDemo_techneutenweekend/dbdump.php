
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT DEMO_WJG\n");
      fwrite($dumpfile, dumprel("doelVanDeAanvraag[VOGAanvraag*Text]","SELECT DISTINCT `VOGAanvraag`, `doelVanDeAanvraag` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `doelVanDeAanvraag` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvrager[VOGAanvraag*Aanvrager]","SELECT DISTINCT `VOGAanvraag`, `aanvrager` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `aanvrager` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerVoornamen[Aanvrager*Text]","SELECT DISTINCT `Aanvrager`, `aanvragerVoornamen` FROM `Aanvrager` WHERE `Aanvrager` IS NOT NULL AND `aanvragerVoornamen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanvragerGeboortedatum[Aanvrager*Datum]","SELECT DISTINCT `Aanvrager`, `aanvragerGeboortedatum` FROM `Aanvrager` WHERE `Aanvrager` IS NOT NULL AND `aanvragerGeboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("authenticatiemiddel[Aanvrager*Authenticatiemiddel]","SELECT DISTINCT `Aanvrager`, `Authenticatiemiddel` FROM `authenticatiemiddel2` WHERE `Aanvrager` IS NOT NULL AND `Authenticatiemiddel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vastgesteldeIdentiteit[VOGAanvraag*NatuurlijkPersoon]","SELECT DISTINCT `VOGAanvraag`, `vastgesteldeIdentiteit` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `vastgesteldeIdentiteit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ingediendBij[VOGAanvraag*Gemeente]","SELECT DISTINCT `VOGAanvraag`, `ingediendBij` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `ingediendBij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("userid[Account*Userid]","SELECT DISTINCT `Account`, `userid` FROM `Account` WHERE `Account` IS NOT NULL AND `userid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("password[Account*Password]","SELECT DISTINCT `Account`, `password` FROM `Account` WHERE `Account` IS NOT NULL AND `password` IS NOT NULL"));
      fwrite($dumpfile, dumprel("roles[Account*Role]","SELECT DISTINCT `Account`, `Role` FROM `roles` WHERE `Account` IS NOT NULL AND `Role` IS NOT NULL"));
      fwrite($dumpfile, dumprel("emailaddr[Account*EmailAddr]","SELECT DISTINCT `Account`, `EmailAddr` FROM `emailaddr2` WHERE `Account` IS NOT NULL AND `EmailAddr` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionUser[SESSION*Userid]","SELECT DISTINCT `SESSION`, `sessionUser` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionUser` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionPassword[SESSION*Password]","SELECT DISTINCT `SESSION`, `sessionPassword` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionPassword` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isAmbtenaarBij[Account*Gemeente]","SELECT DISTINCT `Account`, `Gemeente` FROM `isAmbtenaarBij` WHERE `Account` IS NOT NULL AND `Gemeente` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaBSN[NatuurlijkPersoon*BurgerServiceNummer]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaBSN` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaBSN` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaAchternaam[NatuurlijkPersoon*Text]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaAchternaam` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaAchternaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaVoorletters[NatuurlijkPersoon*Text]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaVoorletters` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaVoorletters` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaVoornamen[NatuurlijkPersoon*Text]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaVoornamen` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaVoornamen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeboortedatum[NatuurlijkPersoon*Datum]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaGeboortedatum` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaGeboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ingezeteneVan[NatuurlijkPersoon*Gemeente]","SELECT DISTINCT `NatuurlijkPersoon`, `ingezeteneVan` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `ingezeteneVan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("amSoort[Authenticatiemiddel*AuthenticatiemiddelSoort]","SELECT DISTINCT `Authenticatiemiddel`, `amSoort` FROM `Authenticatiemiddel1` WHERE `Authenticatiemiddel` IS NOT NULL AND `amSoort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("amNummer[Authenticatiemiddel*Identificatienummer]","SELECT DISTINCT `Authenticatiemiddel`, `amNummer` FROM `Authenticatiemiddel1` WHERE `Authenticatiemiddel` IS NOT NULL AND `amNummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("amHouder[Authenticatiemiddel*BurgerServiceNummer]","SELECT DISTINCT `Authenticatiemiddel`, `amHouder` FROM `Authenticatiemiddel1` WHERE `Authenticatiemiddel` IS NOT NULL AND `amHouder` IS NOT NULL"));
      fwrite($dumpfile, dumprel("volledigheidGegevensVOGAanvraagVastgesteld[VOGAanvraag*JaNee]","SELECT DISTINCT `VOGAanvraag`, `volledigheidGegevensVOGAanvraagVastgesteld` FROM `VOGAanvraag` WHERE `VOGAanvraag` IS NOT NULL AND `volledigheidGegevensVOGAanvraagVastgesteld` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("mcpp_DEMO_WJG", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\"",$str); }
      ?>