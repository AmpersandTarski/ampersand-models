<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass elsewhere
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('demozaakgegevens')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `demozaakgegevens` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('demozaakgegevens');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'demozaakgegevens'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Session timeout table
    if($columns = mysql_query("SHOW COLUMNS FROM `__SessionTimeout__`")){
        mysql_query("DROP TABLE `__SessionTimeout__`");
    }
    mysql_query("CREATE TABLE `__SessionTimeout__`
                         ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                         , `lastAccess` BIGINT NOT NULL
                         ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
    }
    mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                         ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 160
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `Gebeurtenis`")){
        mysql_query("DROP TABLE `Gebeurtenis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Dagvaarding`")){
        mysql_query("DROP TABLE `Dagvaarding`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Handeling`")){
        mysql_query("DROP TABLE `Handeling`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `NatuurlijkPersoon`")){
        mysql_query("DROP TABLE `NatuurlijkPersoon`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zitting`")){
        mysql_query("DROP TABLE `Zitting`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijving`")){
        mysql_query("DROP TABLE `Inschrijving`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Vertegenwoordiging`")){
        mysql_query("DROP TABLE `Vertegenwoordiging`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Beroepschrift`")){
        mysql_query("DROP TABLE `Beroepschrift`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Orgaan`")){
        mysql_query("DROP TABLE `Orgaan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaakid`")){
        mysql_query("DROP TABLE `Zaakid`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaak`")){
        mysql_query("DROP TABLE `Zaak`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `SESSION`")){
        mysql_query("DROP TABLE `SESSION`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Arrondissement`")){
        mysql_query("DROP TABLE `Arrondissement`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `MondelingeBehandeling`")){
        mysql_query("DROP TABLE `MondelingeBehandeling`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kantoornummer`")){
        mysql_query("DROP TABLE `Kantoornummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Document`")){
        mysql_query("DROP TABLE `Document`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Bformulier`")){
        mysql_query("DROP TABLE `Bformulier`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `SchriftelijkeUitspraak`")){
        mysql_query("DROP TABLE `SchriftelijkeUitspraak`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Selectiecriterium`")){
        mysql_query("DROP TABLE `Selectiecriterium`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Anummer`")){
        mysql_query("DROP TABLE `Anummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Plaats`")){
        mysql_query("DROP TABLE `Plaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Griffier`")){
        mysql_query("DROP TABLE `Griffier`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaalnaam`")){
        mysql_query("DROP TABLE `Zaalnaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Barnummer`")){
        mysql_query("DROP TABLE `Barnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Wachtwoord1`")){
        mysql_query("DROP TABLE `Wachtwoord1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `wachtwoord2`")){
        mysql_query("DROP TABLE `wachtwoord2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Beslissing1`")){
        mysql_query("DROP TABLE `Beslissing1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `beslissing2`")){
        mysql_query("DROP TABLE `beslissing2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Waardering1`")){
        mysql_query("DROP TABLE `Waardering1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `waardering2`")){
        mysql_query("DROP TABLE `waardering2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Actor`")){
        mysql_query("DROP TABLE `Actor`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Categorie`")){
        mysql_query("DROP TABLE `Categorie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Vernietigingstermijn`")){
        mysql_query("DROP TABLE `Vernietigingstermijn`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `RIO handeling`")){
        mysql_query("DROP TABLE `RIO handeling`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Object`")){
        mysql_query("DROP TABLE `Object`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaakstuktype`")){
        mysql_query("DROP TABLE `Zaakstuktype`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Dossier`")){
        mysql_query("DROP TABLE `Dossier`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Nationaliteit1`")){
        mysql_query("DROP TABLE `Nationaliteit1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `nationaliteit2`")){
        mysql_query("DROP TABLE `nationaliteit2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Geslacht`")){
        mysql_query("DROP TABLE `Geslacht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Land`")){
        mysql_query("DROP TABLE `Land`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Titel`")){
        mysql_query("DROP TABLE `Titel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `BurgerServiceNummer`")){
        mysql_query("DROP TABLE `BurgerServiceNummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Geslachtsnaam`")){
        mysql_query("DROP TABLE `Geslachtsnaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Voornamen`")){
        mysql_query("DROP TABLE `Voornamen`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Ressort`")){
        mysql_query("DROP TABLE `Ressort`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Rechternaam`")){
        mysql_query("DROP TABLE `Rechternaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaal`")){
        mysql_query("DROP TABLE `Zaal`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Appointeringsvoorstel1`")){
        mysql_query("DROP TABLE `Appointeringsvoorstel1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `appointeringsvoorstel2`")){
        mysql_query("DROP TABLE `appointeringsvoorstel2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Termijndatum`")){
        mysql_query("DROP TABLE `Termijndatum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Eis`")){
        mysql_query("DROP TABLE `Eis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Advocaat`")){
        mysql_query("DROP TABLE `Advocaat`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kantoordeurwaarder`")){
        mysql_query("DROP TABLE `Kantoordeurwaarder`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Aantal`")){
        mysql_query("DROP TABLE `Aantal`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Tekst`")){
        mysql_query("DROP TABLE `Tekst`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Artikel`")){
        mysql_query("DROP TABLE `Artikel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Tijdstip1`")){
        mysql_query("DROP TABLE `Tijdstip1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `tijdstip2`")){
        mysql_query("DROP TABLE `tijdstip2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Feit1`")){
        mysql_query("DROP TABLE `Feit1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `feit2`")){
        mysql_query("DROP TABLE `feit2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Rechter1`")){
        mysql_query("DROP TABLE `Rechter1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `rechter2`")){
        mysql_query("DROP TABLE `rechter2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Partij`")){
        mysql_query("DROP TABLE `Partij`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Samenstelling1`")){
        mysql_query("DROP TABLE `Samenstelling1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `samenstelling2`")){
        mysql_query("DROP TABLE `samenstelling2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kamerid`")){
        mysql_query("DROP TABLE `Kamerid`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Griffierechtbetaald1`")){
        mysql_query("DROP TABLE `Griffierechtbetaald1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `griffierechtbetaald2`")){
        mysql_query("DROP TABLE `griffierechtbetaald2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaaktype`")){
        mysql_query("DROP TABLE `Zaaktype`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Sector`")){
        mysql_query("DROP TABLE `Sector`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gerecht`")){
        mysql_query("DROP TABLE `Gerecht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Datum1`")){
        mysql_query("DROP TABLE `Datum1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `datum2`")){
        mysql_query("DROP TABLE `datum2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Soort recht`")){
        mysql_query("DROP TABLE `Soort recht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Systeemcode`")){
        mysql_query("DROP TABLE `Systeemcode`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaaknummer`")){
        mysql_query("DROP TABLE `Zaaknummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Volgnummer`")){
        mysql_query("DROP TABLE `Volgnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Jaar`")){
        mysql_query("DROP TABLE `Jaar`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Adres`")){
        mysql_query("DROP TABLE `Adres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kantoor`")){
        mysql_query("DROP TABLE `Kantoor`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijvingsstatus`")){
        mysql_query("DROP TABLE `Inschrijvingsstatus`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijvingseis`")){
        mysql_query("DROP TABLE `Inschrijvingseis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Strafblad1`")){
        mysql_query("DROP TABLE `Strafblad1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `strafblad2`")){
        mysql_query("DROP TABLE `strafblad2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `hoortbij`")){
        mysql_query("DROP TABLE `hoortbij`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zaakreferentie`")){
        mysql_query("DROP TABLE `zaakreferentie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `jaarAanleg`")){
        mysql_query("DROP TABLE `jaarAanleg`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gedingdatum`")){
        mysql_query("DROP TABLE `gedingdatum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `behandelendgerecht`")){
        mysql_query("DROP TABLE `behandelendgerecht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gegevenAan`")){
        mysql_query("DROP TABLE `gegevenAan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `kamer`")){
        mysql_query("DROP TABLE `kamer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ispartij`")){
        mysql_query("DROP TABLE `ispartij`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `deskundige`")){
        mysql_query("DROP TABLE `deskundige`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `benadeeld`")){
        mysql_query("DROP TABLE `benadeeld`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gevoegde`")){
        mysql_query("DROP TABLE `gevoegde`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `klager`")){
        mysql_query("DROP TABLE `klager`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gewraakte`")){
        mysql_query("DROP TABLE `gewraakte`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `wraker`")){
        mysql_query("DROP TABLE `wraker`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `wrakingsverzoek`")){
        mysql_query("DROP TABLE `wrakingsverzoek`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verschonende`")){
        mysql_query("DROP TABLE `verschonende`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verschoningsverzoek`")){
        mysql_query("DROP TABLE `verschoningsverzoek`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `datumdelict`")){
        mysql_query("DROP TABLE `datumdelict`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `tijdstipdelict`")){
        mysql_query("DROP TABLE `tijdstipdelict`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `plaatsdelict`")){
        mysql_query("DROP TABLE `plaatsdelict`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `artikelvoorschrift`")){
        mysql_query("DROP TABLE `artikelvoorschrift`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `omschrijvingartikel`")){
        mysql_query("DROP TABLE `omschrijvingartikel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `omstandigheden`")){
        mysql_query("DROP TABLE `omstandigheden`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `producties`")){
        mysql_query("DROP TABLE `producties`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `deurwaarder`")){
        mysql_query("DROP TABLE `deurwaarder`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `afschrift`")){
        mysql_query("DROP TABLE `afschrift`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `adresafschrift`")){
        mysql_query("DROP TABLE `adresafschrift`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gemachtigdecivielstraf`")){
        mysql_query("DROP TABLE `gemachtigdecivielstraf`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gronden`")){
        mysql_query("DROP TABLE `gronden`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `behandelplaats`")){
        mysql_query("DROP TABLE `behandelplaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `behandeladres`")){
        mysql_query("DROP TABLE `behandeladres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `adresvoorstukken`")){
        mysql_query("DROP TABLE `adresvoorstukken`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verschijningswijze`")){
        mysql_query("DROP TABLE `verschijningswijze`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `conclusievanantwoord`")){
        mysql_query("DROP TABLE `conclusievanantwoord`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `indiener`")){
        mysql_query("DROP TABLE `indiener`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gemachtigdebestuur`")){
        mysql_query("DROP TABLE `gemachtigdebestuur`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verweerder`")){
        mysql_query("DROP TABLE `verweerder`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `aanhangigbestuur`")){
        mysql_query("DROP TABLE `aanhangigbestuur`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `behandeld`")){
        mysql_query("DROP TABLE `behandeld`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `rechtertekent`")){
        mysql_query("DROP TABLE `rechtertekent`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `tolk`")){
        mysql_query("DROP TABLE `tolk`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `bewijsstuk`")){
        mysql_query("DROP TABLE `bewijsstuk`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verhinderdatumrechter`")){
        mysql_query("DROP TABLE `verhinderdatumrechter`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `verhinderdatumpartij`")){
        mysql_query("DROP TABLE `verhinderdatumpartij`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `geschorst`")){
        mysql_query("DROP TABLE `geschorst`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `hervat`")){
        mysql_query("DROP TABLE `hervat`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zittinghouden`")){
        mysql_query("DROP TABLE `zittinghouden`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `naamrechter`")){
        mysql_query("DROP TABLE `naamrechter`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `rechtsgebied1`")){
        mysql_query("DROP TABLE `rechtsgebied1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `rechtsgebied2`")){
        mysql_query("DROP TABLE `rechtsgebied2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ressorteertHGK`")){
        mysql_query("DROP TABLE `ressorteertHGK`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaVoornamen`")){
        mysql_query("DROP TABLE `gbaVoornamen`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gbaGeslachtsnaam`")){
        mysql_query("DROP TABLE `gbaGeslachtsnaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `adelijketitel`")){
        mysql_query("DROP TABLE `adelijketitel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `opleidingstitel`")){
        mysql_query("DROP TABLE `opleidingstitel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zaaksdossier`")){
        mysql_query("DROP TABLE `zaaksdossier`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zaakstuk`")){
        mysql_query("DROP TABLE `zaakstuk`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zaaksdocument`")){
        mysql_query("DROP TABLE `zaaksdocument`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `type`")){
        mysql_query("DROP TABLE `type`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `inhoud`")){
        mysql_query("DROP TABLE `inhoud`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ontstaan`")){
        mysql_query("DROP TABLE `ontstaan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zorgdrager`")){
        mysql_query("DROP TABLE `zorgdrager`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ingevoegd`")){
        mysql_query("DROP TABLE `ingevoegd`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `afgedrukt`")){
        mysql_query("DROP TABLE `afgedrukt`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `over`")){
        mysql_query("DROP TABLE `over`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `neerslag`")){
        mysql_query("DROP TABLE `neerslag`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `rIOhandeling`")){
        mysql_query("DROP TABLE `rIOhandeling`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `criterium`")){
        mysql_query("DROP TABLE `criterium`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `locatie`")){
        mysql_query("DROP TABLE `locatie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ouder`")){
        mysql_query("DROP TABLE `ouder`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `plandatum`")){
        mysql_query("DROP TABLE `plandatum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `eindbeslissing`")){
        mysql_query("DROP TABLE `eindbeslissing`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `vonnis`")){
        mysql_query("DROP TABLE `vonnis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `wijzen`")){
        mysql_query("DROP TABLE `wijzen`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `wijsdatum`")){
        mysql_query("DROP TABLE `wijsdatum`");
      }
    }
    /**************************************\
    * Plug Gebeurtenis                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * Beëdiging~  [INJ,SUR,UNI]            *
    * Bericht~  [INJ,SUR,UNI]              *
    * beëdigd  [UNI,TOT]                   *
    * locatieBeëdiging  [UNI,TOT]          *
    * schrappingvan  [UNI]                 *
    * schorsingvan  [UNI]                  *
    * schorsingopheffen  [UNI]             *
    * doc  [UNI,TOT]                       *
    * handeling  [UNI]                     *
    \**************************************/
    mysql_query("CREATE TABLE `Gebeurtenis`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Beëdiging` VARCHAR(255) DEFAULT NULL
                     , `Bericht` VARCHAR(255) DEFAULT NULL
                     , `beëdigd` VARCHAR(255) DEFAULT NULL
                     , `locatieBeëdiging` VARCHAR(255) DEFAULT NULL
                     , `schrappingvan` VARCHAR(255) DEFAULT NULL
                     , `schorsingvan` VARCHAR(255) DEFAULT NULL
                     , `schorsingopheffen` VARCHAR(255) DEFAULT NULL
                     , `doc` VARCHAR(255) DEFAULT NULL
                     , `handeling` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gebeurtenis` (`Gebeurtenis` ,`Beëdiging` ,`Bericht` ,`beëdigd` ,`locatieBeëdiging` ,`schrappingvan` ,`schorsingvan` ,`schorsingopheffen` ,`doc` ,`handeling` )
                VALUES ('Be1', 'Be1', NULL, 'Inschrijving 1', 'Rechtbank Amsterdam', NULL, NULL, NULL, NULL, NULL)
                      , ('Be2', 'Be2', NULL, 'Inschrijving 2', 'Rechtbank Rotterdam', NULL, NULL, NULL, NULL, NULL)
                      , ('Be3', 'Be3', NULL, 'Inschrijving 3', 'Rechtbank Utrecht', NULL, NULL, NULL, NULL, NULL)
                      , ('Be4', 'Be4', NULL, 'Inschrijving 4', 'Rechtbank Utrecht', NULL, NULL, NULL, NULL, NULL)
                      , ('Vts1', NULL, 'Vts1', NULL, NULL, 'Inschrijving 2', NULL, NULL, 'Verzoek tot schorsing 11/5', NULL)
                      , ('Vtos1', NULL, 'Vtos1', NULL, NULL, 'Inschrijving 2', NULL, NULL, 'Verzoek tot opheffing schorsing 12/4', NULL)
                      , ('Msg598', NULL, 'Msg598', NULL, NULL, NULL, NULL, NULL, 'Proc 11/123458', NULL)
                      , ('Msg449', NULL, 'Msg449', NULL, NULL, NULL, NULL, NULL, 'Proc 10/569423', NULL)
                      , ('Msg779', NULL, 'Msg779', NULL, NULL, NULL, NULL, NULL, 'Proc 11/489631', NULL)
                      , ('Msg566', NULL, 'Msg566', NULL, NULL, NULL, NULL, NULL, 'Von11/123458', NULL)
                      , ('Msg795', NULL, 'Msg795', NULL, NULL, NULL, NULL, NULL, 'Von10/569423', NULL)
                      , ('Msg791', NULL, 'Msg791', NULL, NULL, NULL, NULL, NULL, 'Von11/489631', NULL)
                      , ('Ev695', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Ev426', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Ev336', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Zitting RbsGr 35', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '61')
                      , ('Zitting RbLee 591', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '61')
                      , ('Zitting RbAlm 68', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '61')
                      , ('Ev739920', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Ev930023', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Ev456188', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Ev732491', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Ev993123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Ev476228', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Dagvaarding                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * dagvaarding  [UNI]                   *
    * aanhangig  [UNI,TOT]                 *
    * datumbetekening  [UNI]               *
    * eiser  [UNI]                         *
    * kantoordeurwaarder  [UNI]            *
    * ontvanger  [UNI]                     *
    * woonplaatsontvanger  [UNI]           *
    * roldatum  [UNI]                      *
    \**************************************/
    mysql_query("CREATE TABLE `Dagvaarding`
                     ( `Dagvaarding0` VARCHAR(255) DEFAULT NULL
                     , `dagvaarding1` VARCHAR(255) DEFAULT NULL
                     , `aanhangig` VARCHAR(255) DEFAULT NULL
                     , `datumbetekening` VARCHAR(255) DEFAULT NULL
                     , `eiser` VARCHAR(255) DEFAULT NULL
                     , `kantoordeurwaarder` VARCHAR(255) DEFAULT NULL
                     , `ontvanger` VARCHAR(255) DEFAULT NULL
                     , `woonplaatsontvanger` VARCHAR(255) DEFAULT NULL
                     , `roldatum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Dagvaarding` (`Dagvaarding0` ,`dagvaarding1` ,`aanhangig` ,`datumbetekening` ,`eiser` ,`kantoordeurwaarder` ,`ontvanger` ,`woonplaatsontvanger` ,`roldatum` )
                VALUES ('Dagvaarding 1', 'Dag20120205', 'Zaak 4', '07-02-2012', '4', 'H.J. Jansen BV', '15', 'Heimerstein 91, 3328MH Dordrecht', '20-03-2012')
                      , ('Dagvaarding 2', 'Dag20110513', 'Zaak 5', '07-02-2012', '17', 'H.J. Jansen BV', '5', 'Bornsestraat 28, 7556BG Hengelo ov', '20-03-2012')
                      , ('Dagvaarding 3', 'Dag20110216', 'Zaak 6', '07-02-2012', '14', 'H.J. Jansen BV', '6', 'Zeedijken 42, 9919BM Loppersum', '20-03-2012')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Handeling                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * omschrijving  [UNI,TOT]              *
    * bron  [UNI]                          *
    * opmerking  [UNI]                     *
    * product  [UNI]                       *
    * vernietigingstermijn  [UNI]          *
    * categorie  [UNI,TOT,SUR]             *
    * actor  [UNI]                         *
    \**************************************/
    mysql_query("CREATE TABLE `Handeling`
                     ( `Handeling` VARCHAR(255) DEFAULT NULL
                     , `omschrijving` VARCHAR(255) DEFAULT NULL
                     , `bron` VARCHAR(255) DEFAULT NULL
                     , `opmerking` VARCHAR(255) DEFAULT NULL
                     , `product` VARCHAR(255) DEFAULT NULL
                     , `vernietigingstermijn` VARCHAR(255) DEFAULT NULL
                     , `categorie` VARCHAR(255) DEFAULT NULL
                     , `actor` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Handeling` (`Handeling` ,`omschrijving` ,`bron` ,`opmerking` ,`product` ,`vernietigingstermijn` ,`categorie` ,`actor` )
                VALUES ('1', 'Het voorbereiden, mede-vaststellen, evalueren en coördineren van het strategische en het operationele beleid met betrekking tot (elementen van) de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke organisatie', 'Organisatiebesluiten ministerie van Justitie; Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'De handeling betreft de vormgeving op lange en middellange termijn van enerzijds de beheersmatige inbedding van de RO (apparaatszorg) en anderzijds de inwendige structuur van de RO (bijv. territoriale indeling, werkwijzen, formatie). De handeling omvat zowel de algemene beleidsontwikkeling als het beleid ten aanzien van specifieke elementen (bijv. materieel beheer, automatisering, personeelszaken) dat binnen het algemene kader wordt ontwikkeld.', 'Notities, nota\'s, rapporten, evaluaties', NULL, 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('4', 'Het (periodiek) doorlichten, op basis van enquêtes of anderszins verzameld statistisch materiaal, van het functioneren van de (administratieve diensten van) de gerechten', 'Organisatiebesluiten ministerie van Justitie', 'De neerslag van de handeling wordt veelal verwerkt in (periodieke) verslagen. Zie handeling 6.', NULL, '10', 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('5', 'Het adviseren en ondersteunen van de hoofden van dienst van (de administratieve diensten bij) de gerechten inzake de uitvoering van de onderdelen van het beleid waarmee zij zijn belast en het ondersteunen van de Rechterlijke Organisaties bij de implementatie van beleid inzake de bedrijfsvoering', 'Organisatiebesluiten ministerie van Justitie, Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Betreft bijv. kwesties van algemeen management, maar ook specifieke aangelegenheden, zoals inrichting en beheer van gerechtsbibliotheken, de automatisering, personeelsbeleid. Deze handeling kan geschieden in het kader van projecten. Betreft ook coördinatie, afstemming en advisering inzake het bewaken en verbeteren van de kwaliteit, uniformiteit en het doelmatig functioneren van de rechterlijke macht als geheel.', NULL, '10', 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('6', 'Het opstellen van periodieke verslagen omtrent ontwikkelingen met betrekking tot de organisatie van de rechtspleging en de (uitvoering van) bedrijfsvoering van de rechterlijke macht', NULL, 'De handeling betreft veelal (deels) een presentatie en analyse van verzamelde statistieken, uitkomsten van gehouden enquêtes of managementrapportages (zie handeling 4).', '(Jaar)verslag', NULL, 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('7', 'Het beantwoorden van Kamervragen en het anderszins informeren van leden van of commissies uit de Kamers der Staten-Generaal inzake aangelegenheden met betrekking tot de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht', NULL, 'Betreft bijv. ook het informeren van de Commissies voor de Verzoekschriften en andere tot het onderzoeken van klachten bevoegde commissies uit de Kamers der Staten-Generaal.', NULL, NULL, 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('8', 'Het beantwoorden van vragen van individuele burgers, bedrijven en instellingen met betrekking tot de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht', NULL, NULL, NULL, '2', 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('9', 'Het ontwikkelen en verspreiden van voorlichtingsmateriaal met betrekking tot de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht', 'Organisatiebesluiten ministerie van Justitie.', NULL, 'Brochures, artikelen, films, enz.', NULL, 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('10', 'Het instellen van commissies of raden en het vaststellen van hun taken betreffende de bedrijfsvoering van de rechterlijke macht en op het terrein van de rechterlijke organisatie', 'Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555, art. 17 e.v.: RAIO-selectiecommissie); RIO Bijlage 4: deze betreft echter veel ambtelijke of gemengde commissies en werkgroepen, die hier niet zijn bedoeld).', NULL, NULL, NULL, 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('11', 'Het benoemen van de leden van commissies of raden op het terrein van de (advisering over het beleid en wet- en regelgeving betreffende de) rechterlijke organisatie en de bedrijfsvoering van de rechterlijke macht en het voorzien in administratieve ondersteuning en financieel beheer', 'Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555, art. 17 e.v.: RAIO-selectiecommissie)', NULL, NULL, '7', 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('13', 'Het administratief ondersteunen en/of financieel beheren van instellingen die actief zijn op het gebied van de organisatie van de rechtspleging', 'Organisatiebesluiten ministerie van Justitie', 'Betreft bijv. het Studiecentrum Rechtspleging.', NULL, '10', 'Beleidsontwikkeling en algemene zaken', 'Minister van Justitie')
                      , ('14', 'Het voorbereiden van de totstandkoming, wijziging of intrekking van wet- en regelgeving met betrekking tot de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke organisatie', 'Organisatiebesluiten ministerie van Justitie. Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Voor een overzicht van wetten zie RIO, Bijlage 3. De handeling betreft voorts de daarop gebaseerde amvb\'s en ministeriële regelingen.', 'Notities, nota\'s, rapporten, wetten, regelingen, reglementen', NULL, 'Regelgeving en juridische zaken', 'Minister van Justitie')
                      , ('15', 'Het voorbereiden van de totstandkoming, wijziging of intrekking van administratieve en organisatorische (uitvoerings)voorschriften en richtlijnen met betrekking tot de organisatie van de rechtspleging', 'Organisatiebesluiten ministerie van Justitie', 'De handeling betreft voorschriften en richtlijnen betreffende de administratieve organisatie, het materiële beheer, de werving en selectie van personeel, het archiefbeheer, etc.', NULL, NULL, 'Regelgeving en juridische zaken', 'Minister van Justitie')
                      , ('16', 'Het behandelen van bezwaar- en beroepschriften naar aanleiding van beschikkingen met betrekking tot de organisatie van de rechtspleging alsmede het voeren van verweer voor rechterlijke instanties in beroepsprocedures ter zake', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '10', 'Regelgeving en juridische zaken', 'Minister van Justitie')
                      , ('17', 'Het geven van voorlichting en advies omtrent de juridische interpretatie en toepassing van wet- en regelgeving met betrekking tot de organisatie van de rechtspleging', 'Organisatiebesluiten ministerie van Justitie.', 'Onder andere in landelijk overleg', NULL, NULL, 'Regelgeving en juridische zaken', 'Minister van Justitie')
                      , ('58', 'Het adviseren van de regering, de Staten-Generaal en de rechtspraak in andere landen betreffende het beleidsterrein rechtspleging', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Betreft adviezen over: het te voeren beleid, voornamelijk inzake strategie en toekomstvisie; wet- en regelgeving inzake de rechtspraak; wet- en regelgeving die niet direct gerelateerd is aan de rechtspraak, maar waarvan de uitvoering wel gevolgen heeft voor de rechtspraak. Wat betreft de (vertegenwoordigers van) de rechtspraak in andere landen betreft het naast de overzeese gebiedsdelen en Suriname ook bijvoorbeeld het -op verzoek van de EU- adviseren van andere landen', NULL, NULL, 'Regelgeving en juridische zaken', 'Minister van Justitie')
                      , ('18', 'Het (jaarlijks) vaststellen van de kwantitatieve en kwalitatieve (rechtsgeleerde) personeelsformatie bij de burgerlijke gerechten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '10', 'Personeel', 'Minister van Justitie')
                      , ('19', 'Het systematisch vastleggen van de personeelsgegevens met betrekking tot de burgerlijke gerechten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('20', 'Het voorbereiden van de KB\'s met betrekking tot de personele bezetting van de zittende magistratuur', 'Wet RO, passim; organisatiebesluiten ministerie van Justitie. Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet Bestuursrechtspraak Bedrijfsorganisatie (1954-) (Stb. 1954, 416), Beroepswet (1955-) (Stb. 1955, 47), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463), Wet op de Raad van State (Stb. 1994, 2), Wet voltooiing 1e fase Herziening Rechterlijke Organisatie (Stb. 1993, 650)', 'Betreft benoeming, ontslagverlening, onbetaald buitengewoon verlof, deeltijdaanstelling, etc. Tot de zittende magistratuur behoren naast de rechtsprekende rechterlijke ambtenaren ook de (senior)gerechtsauditeurs in vaste dienst. Bijvoorbeeld: de leden van enkelvoudige en meervoudige kamers voor het behandelen en beslissen van bestuurs-, civiel- en strafrechtelijke zaken, de belasting- , ondernemings- , grond- en pachtkamers, de kamer voor het kwekersrecht etc., de verkeersschouten en hun vervangers. Hieronder vallen ook de Hoge Raad, de Colleges van Beroep, de Centrale Raad van Beroep en de Raad van State.', 'Koninklijk Besluit, benoeming', '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('21', 'Het voorbereiden van de KB\'s met betrekking tot de personele bezetting van posten in rechterlijke colleges, bestemd voor niet tot de rechterlijke macht behorende deskundigen', 'Wet RO, art. 72 en 73; organisatiebesluiten ministerie van Justitie', 'Betreft benoeming, herbenoeming, ontslag, etc. van de deskundigen die als (plaatsvervangende) raden zitting hebben in de ondernemingskamer van het gerechtshof te Amsterdam en de bijzondere kamer van het gerechtshof te Arnhem.', NULL, '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('22', 'Het nemen van besluiten met betrekking tot de verdere personele bezetting van de zittende magistratuur', 'Wet RO passim; organisatiebesluiten ministerie van Justitie', 'Betreft benoeming, ontslag, etc. van gerechtsauditeurs in tijdelijke dienst, alsmede de aanwijzing van magistraten in waarnemende functies.', NULL, '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('23', 'Het voorbereiden van de KB\'s met betrekking tot de personele bezetting van het Openbaar Ministerie', 'Wet RO passim; organisatiebesluiten ministerie van Justitie', 'Betreft benoeming, ontslagverlening, onbetaald buitengewoon verlof, deeltijdaanstelling, aanstelling in buitengewone dienst, etc.', NULL, '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('24', 'Het nemen van besluiten met betrekking tot de verdere personele bezetting van het Openbaar Ministerie', 'Wet RO passim; organisatiebesluiten ministerie van Justitie', 'Betreft benoeming, ontslag, etc. van plaatsvervangende officieren van justitie en parketsecretarissen, alsmede de aanwijzing van leden van het OM in waarnemende functies.', NULL, '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('25', 'Het voorbereiden van de KB\'s met betrekking tot de rechtsgeleerde personele bezetting van de griffies van de burgerlijke gerechten', 'Wet RO passim; organisatiebesluiten ministerie van Justitie', 'Betreft benoeming, ontslag, etc. van griffiers en substituut-griffiers.', NULL, '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('26', 'Het nemen van besluiten met betrekking tot de rechtsgeleerde personele bezetting van de griffies van de burgerlijke gerechten', 'Wet RO passim; organisatiebesluiten ministerie van Justitie', 'Betreft benoeming, ontslag, etc. van waarnemend griffiers en gerechtssecretarissen', NULL, '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('27', 'Het nemen van besluiten met betrekking tot de personele bezetting van de administratieve diensten van (de griffies van) de burgerlijke gerechten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '7', 'Personeel', 'Minister van Justitie')
                      , ('28', 'Het ontwikkelen van plannen en programma\'s betreffende de werving, selectie en opleiding van personen met het oog de vervulling van functies in de magistratuur of kaderfuncties in de administratieve diensten bij de gerechten', 'Organisatiebesluiten ministerie van justitie', NULL, NULL, NULL, 'Personeel', 'Minister van Justitie')
                      , ('29', 'Het ontwikkelen van plannen en programma\'s betreffende de werving, selectie en opleiding van personen met het oog de vervulling van lagere functies in de administratieve diensten bij de gerechten', 'Organisatiebesluiten ministerie van justitie', NULL, NULL, NULL, 'Personeel', 'Minister van Justitie')
                      , ('30', 'Het (doen) organiseren van voorlichtingsbijeenkomsten en wervingsacties gericht op (juridische) studenten, alsmede het (doen) geven van voorlichting op scholen en aan individuele gegadigden over een loopbaan of beroep bij de burgerlijke gerechten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '10', 'Personeel', 'Minister van Justitie')
                      , ('31', 'Het besluiten omtrent toelating van personen tot opleidingen voor het vervullen van een functie in de magistratuur of kaderfuncties in de administratieve diensten bij de gerechten', 'Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555).', NULL, NULL, '15', 'Personeel', 'Minister van Justitie')
                      , ('32', 'Het plaatsen van stagiaire(s) en het aanstellen (in tijdelijke, resp. vaste dienst) van personen in opleiding voor het vervullen van een functie in de magistratuur of kaderfunctie in de administratieve diensten bij de gerechten', 'Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555); organisatiebesluiten ministerie van Justitie', NULL, NULL, '5', 'Personeel', 'Minister van Justitie')
                      , ('33', 'Het (doen) beoordelen (door tentamens, examens, ambtsberichten, etc.) van personen in opleiding voor het vervullen van een functie in de magistratuur of kaderfunctie in de administratieve diensten bij de gerechten en het eventueel besluiten tot tussentijdse beëindiging', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '10', 'Personeel', 'Minister van Justitie')
                      , ('34', 'Het besluiten omtrent dispensatieverzoeken, programmawijzigingen en rechtspositionele aangelegenheden met betrekking tot stagiaire(s) en (overige) personen in opleiding voor het vervullen van een functie in de magistratuur of kaderfunctie in de administratieve diensten bij de gerechten', 'Wet- en regelgeving (bijv. Besluit opleiding verkeersschouten, Stb. 1974, 44).', 'De handeling betreft dispensatieverzoeken', NULL, '5', 'Personeel', 'Minister van Justitie')
                      , ('35', 'Het besluiten of personen hun opleiding voor het vervullen van een functie in de magistratuur of kaderfunctie in de administratieve diensten bij de gerechten met goed gevolg hebben voltooid', 'Wet- en regelgeving (bijv. Opleidingsreglement verkeersschouten, Stcrt. 1974, 249).', NULL, NULL, '5', 'Personeel', 'Minister van Justitie')
                      , ('36', 'Het instellen en medebesturen van de Stichting opleiding rechterlijke ambtenaren', 'Besluit opleiding rechterlijke ambtenaren (Stb. 1985, 555) art. 9 en 10', 'De stichting is het instituut voor de RAIO-opleiding en wordt door Justitie gefinancierd. Het bestuur bestaat grotendeels uit personen aangewezen door de Nederlandse Vereniging voor Rechtspraak.', NULL, NULL, 'Personeel', 'Minister van Justitie')
                      , ('37', 'Het al dan niet accorderen van besluiten van de Stichting opleiding rechterlijke ambtenaren inzake het opleidingsreglement en de samenstelling van het personele kader van de opleiding', 'Besluit opleiding rechterlijke ambtenaren (Stb. 1985, 555) art. 11 en 12.', NULL, NULL, NULL, 'Personeel', 'Minister van Justitie')
                      , ('38', 'Het uitvoeren van de praktische organisatie van opleidingen voor functies bij de burgerlijke gerechten', 'Organisatiebesluiten ministerie van Justitie', 'Zie opsomming van activiteiten bij RIO handeling nr. 100', NULL, '10', 'Personeel', 'Minister van Justitie')
                      , ('39', 'Het verzorgen van cursussen, studie- en vormingsbijeenkomsten in het kader van opleidingen tot griffier en kaderfuncties bij de administratieve diensten van de burgerlijke gerechten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '10', 'Personeel', 'Minister van Justitie')
                      , ('40', 'Het voorbereiden van de KB\'s waarbij wordt uitgemaakt of een bepaalde openbare nevenfunctie toelaatbaar is voor een voor het leven benoemde rechterlijke ambtenaar', 'Wet RO art. 8, lid 3.', 'Deze handeling geschiedt alleen in bijzondere twijfelgevallen.', NULL, NULL, 'Personeel', 'Minister van Justitie')
                      , ('41', 'Het doen van voorstellen in verband met de toekenning van koninklijke onderscheidingen aan rechterlijke ambtenaren', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '70, of 1 jaar na aftreden', 'Personeel', 'Minister van Justitie')
                      , ('42', 'Het voorbereiden van de KB\'s ter goedkeuring van (wijzigingen van) de reglementen van de gerechten', 'Reglement I (Stb. 1838, 36), zoals sindsdien gewijzigd.', NULL, NULL, NULL, 'Organisatie', 'Minister van Justitie')
                      , ('43', 'Het bevorderen van de unificatie van formulieren, registers, handleidingen en overige administratieve bescheiden van (de administratieve diensten bij) de gerechten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '10', 'Organisatie', 'Minister van Justitie')
                      , ('44', 'Het ontwerpen en doorvoeren van (nieuwe) taakverdelingspatronen, werkprocedures en -methoden, alsmede administratievormen bij de griffies en parketten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, NULL, 'Organisatie', 'Minister van Justitie')
                      , ('45', 'Het toezien op de naleving van voorschriften en de administratieve gang van zaken bij de griffies van en de parketten bij de gerechten', 'Organisatiebesluiten ministerie van Justitie', 'De handeling betreft in voorkomende gevallen mede het beslissen inzake de werkwijze van gerechten als bedoeld in art. 63a, 63b en 73 van Reglement I.', NULL, NULL, 'Organisatie', 'Minister van Justitie')
                      , ('59', 'Het vaststellen en verdelen van het rechtsgebied en de zetels der Rechterlijke Organisaties', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Bijvoorbeeld: in arrondissementen en kantons.', NULL, NULL, 'Organisatie', 'Minister van Justitie')
                      , ('60', 'Het vormen van enkelvoudige en meervoudige kamers voor het behandelen en beslissen van zaken', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet Bestuursrechtspraak Bedrijfsorganisatie (1954-) (Stb. 1954, 416), Beroepswet (1955-) (Stb. 1955, 47), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Onder andere bestuurs-, civiel- en strafrechterlijke zaken of zaken aangaande belasting', NULL, NULL, 'Organisatie', 'Minister van Justitie')
                      , ('61', 'Het verdelen van de behandeling van rechtzaken over hoofd-, nevenvestiging- en nevenzittingsplaatsen', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Betreft reguliere werkverdeling binnen een arrondissement.', NULL, '1', 'Organisatie', 'Minister van Justitie')
                      , ('62', 'Het houden van bijzondere zittingen', NULL, 'Onder andere het inplannen van de zittingen. Voor de behandeling van een bepaalde zaak kan, in verband met omstandigheden, afgeweken worden van de in het reglement opgenomen dagen, tijdstippen en plaatsen.', NULL, '5', 'Organisatie', 'Minister van Justitie')
                      , ('63', 'Het (inzake de aard of anderszins) overdragen van rechtzaken aan andere gerechten', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Een zaak kan worden overgedragen wanneer er sprake zou kunnen zijn van (schijn van) belangenverstrengeling. Ook bij megastrafzaken die naar verwachting 30 uur of meer in beslag nemen, kan een afwijkende zittingsplaats worden aangewezen. De Minister van Justitie kan, na overleg met het gerechtsbestuur besluiten om een rechtszaak op een andere locatie plaats te laten vinden in verband met veiligheidsoverwegingen. Handeling is niet van toepassing op de CRvB.', NULL, '1', 'Organisatie', 'Minister van Justitie')
                      , ('64', 'Het (laten) onderhouden en beheren van gegevensbestanden met betrekking tot het behandelen en beslissen van rechtszaken', NULL, NULL, NULL, '7', 'Organisatie', 'Minister van Justitie')
                      , ('46', 'Het ontwikkelen van systemen en procedures met betrekking tot het financieel-economisch beheer van de rechterlijke organisatie', 'Organisatiebesluiten ministerie van Justitie', 'Betreft bijv. de planning- & controlsystematiek.', NULL, '10', 'Financiën', 'Minister van Justitie')
                      , ('47', 'Het ramen van de begrotingsgelden voor de onderscheidene soorten kosten van de rechterlijke organisatie en het daaruit samenstellen van een begroting voor de gehele sector', 'Organisatiebesluiten ministerie van Justitie', 'Betreft mede de financieel-economische onderbouwing van beleidsplannen en -voornemens', NULL, '7', 'Financiën', 'Minister van Justitie')
                      , ('48', 'Het (al dan niet) toewijzen van kredieten en voorschotten aan de rekenplichtigen voor de (administratieve diensten bij) de gerechten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, NULL, 'Financiën', 'Minister van Justitie')
                      , ('49', 'Het toepassen van de voorschriften inzake gerechtskosten in straf- en burgerlijke zaken en overige sectorspecifieke financiële regelingen', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '10', 'Financiën', 'Minister van Justitie')
                      , ('50', 'Het toezien op de besteding van de bij begroting toegewezen bedragen aan (de administratieve diensten bij) de gerechten en uitvoering van de formatie- en begrotingsbewaking', 'Organisatiebesluiten ministerie van Justitie', 'Betreft mede het aangeven van compensatievoorstellen bij dreigende overschrijding van de sectorale begroting.', NULL, '10', 'Financiën', 'Minister van Justitie')
                      , ('51', 'Het door middel van een planning- en controlesystematiek uitvoeren van het financieel-economisch beheer van de rechterlijke organisatie', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '10', 'Financiën', 'Minister van Justitie')
                      , ('52', 'Het toezien op het beheer en de overbrenging van de gerechtelijke en de burgerlijke stand-archieven, alsmede het zorgen voor de eventuele vervanging en de beveiliging van de burgerlijke stand-archieven', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, NULL, 'Documentatie en informatie', 'Minister van Justitie')
                      , ('53', 'Het (her)inrichten van gerechtsgebouwen', 'Organisatiebesluiten ministerie van Justitie', 'Deze handeling geschiedt in samenwerking met de Rijks Gebouwen Dienst', NULL, '7', 'Huisvesting en materieel', 'Minister van Justitie')
                      , ('54', 'Het (doen) uitvoeren van de verhuizing van gerechten en hun administratieve diensten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '7', 'Huisvesting en materieel', 'Minister van Justitie')
                      , ('55', 'Het treffen van materiële voorzieningen betreffende de huishoudelijke en de administratieve diensten der gerechten', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '7', 'Huisvesting en materieel', 'Minister van Justitie')
                      , ('56', 'Het zorgdragen voor de bewaking en het schoonhouden van de gerechtsgebouwen', 'Organisatiebesluiten ministerie van Justitie', 'Betreft het afsluiten van contracten en toezicht op de naleving daarvan', NULL, '7', 'Huisvesting en materieel', 'Minister van Justitie')
                      , ('57', 'Het zorgdragen voor de bedrijfsvoering van de kantines in de gerechtsgebouwen', 'Organisatiebesluiten ministerie van Justitie', NULL, NULL, '7', 'Huisvesting en materieel', 'Minister van Justitie')
                      , ('65', 'Het ontwikkelen, vaststellen en wijzigen van een klachtenregeling betreffende de bedrijfsvoering van de rechterlijke organisatie', NULL, NULL, NULL, NULL, 'Klachten', 'Minister van Justitie')
                      , ('66', 'Het behandelen van klachten van burgers over hun behandeling tijdens rechtszaken', NULL, 'Betreft alle klachten die niet rechtstreeks betrekking hebben op een zaak, bijvoorbeeld klachten tegen bejegening door gerechtsambtenaren, niet tijdig beantwoorden van brieven, etc.', NULL, '10', 'Klachten', 'Minister van Justitie')
                      , ('2', 'Het vaststellen van een opdracht en resultaat van onderzoek naar het beleid en de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht', 'Organisatiebesluiten ministerie van Justitie', 'Het kan hierbij gaan om juridische studies, organisatie-onderzoeken, financieel-economische analyses, arbeidsmarktonderzoek, etc. vanuit een bijzondere vraagstelling. De vraag kan betrekking hebben op het rechterlijke functioneren, uniforme rechtstoepassing en (de kwaliteit van) de organisatie van de rechtspleging in het algemeen, of op een afzonderlijk element (informatievoorziening, beveiliging, loopbaanontwikkeling, etc.). Voor (periodieke) enquêtes en statistieken betreffende het functioneren van de gerechten en hun diensten zie handeling 4', 'Offerte, brief, rapport, contract', NULL, 'Onderzoek', 'Minister van Justitie')
                      , ('3', 'Het (mede-)voorbereiden en begeleiden van (wetenschappelijke) studies en onderzoeken met betrekking tot de organisatie van de rechtspleging', 'Organisatiebesluiten ministerie van Justitie', NULL, 'Notitie, notulen, brief', NULL, 'Onderzoek', 'Minister van Justitie')
                      , ('67', 'Het verzamelen en bewerken van gegevens ten behoeve van (wetenschappelijk) onderzoek betreffende de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht', NULL, NULL, NULL, '5', 'Onderzoek', 'Minister van Justitie')
                      , ('68', 'Het financieren van (wetenschappelijk) onderzoek betreffende de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht', NULL, NULL, 'Rekening, declaratie', '7', 'Onderzoek', 'Minister van Justitie')
                      , ('69', 'Het (doen) uitvoeren van onderzoeken betreffende efficiëntie, effectiviteit en kwaliteit van de eigen bedrijfsvoering', NULL, NULL, NULL, '10', 'Onderzoek', 'Minister van Justitie')
                      , ('70', 'Het deelnemen aan advies- of overlegcommissies en werkgroepen inzake de bedrijfsvoering van de rechterlijke macht waarvan het secretariaat bij het ministerie berust', NULL, NULL, NULL, NULL, 'Overleg', 'Minister van Justitie')
                      , ('71', 'Het deelnemen aan advies- of overlegcommissies en werkgroepen inzake de bedrijfsvoering van de rechterlijke macht waarvan het secretariaat niet bij het ministerie berust', NULL, NULL, NULL, '5', 'Overleg', 'Minister van Justitie')
                      , ('72', 'Het (adviseren inzake) voorbereiden, vaststellen en evalueren van het beleid betreffende de bedrijfsvoering van de rechterlijke organisatie', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', NULL, 'Notities, nota\'s, rapporten, evaluaties', NULL, 'Beleid', 'Rechterlijke Organisatie')
                      , ('73', 'Het adviseren over (verbetering van) de wijze waarop recht wordt toegepast', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Onder andere in landelijk overleg', NULL, NULL, 'Advies', 'Rechterlijke Organisatie')
                      , ('74', 'Het adviseren van de minister van Justitie betreffende het beleidsterrein rechtspleging', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Betreft adviezen over: het te voeren beleid, voornamelijk inzake strategie en toekomstvisie; wet- en regelgeving inzake de rechtspraak; wet- en regelgeving die niet direct gerelateerd is aan de rechtspraak, maar waarvan de uitvoering wel gevolgen heeft voor de rechtspraak.', NULL, NULL, 'Advies', 'Rechterlijke Organisatie')
                      , ('75', 'Het vormen van enkelvoudige en meervoudige kamers voor het behandelen en beslissen van zaken', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet Bestuursrechtspraak Bedrijfsorganisatie (1954-) (Stb. 1954, 416), Beroepswet (1955-) (Stb. 1955, 47), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Onder andere bestuurs-, civiel- en strafrechtelijke zaken of zaken aangaande belasting', NULL, NULL, 'Organisatie', 'Rechterlijke Organisatie')
                      , ('76', 'Het verdelen van de behandeling van rechtzaken over hoofd-, nevenvestiging- en nevenzittingsplaatsen', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Betreft reguliere werkverdeling binnen een arrondissement', NULL, '1', 'Organisatie', 'Rechterlijke Organisatie')
                      , ('77', 'Het inplannen van bijzondere zittingen', NULL, 'Voor de behandeling van een bepaalde zaak kan, in verband met omstandigheden, afgeweken worden van de in het reglement opgenomen dagen, tijdstippen en plaatsen', NULL, '5', 'Organisatie', 'Rechterlijke Organisatie')
                      , ('78', 'Het (inzake de aard of anderszins) overdragen van rechtzaken aan andere gerechten', 'Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)', 'Een zaak kan worden overgedragen wanneer er sprake zou kunnen zijn van (schijn van) belangenverstrengeling. Ook bij megastrafzaken die naar verwachting 30 uur of meer in beslag nemen, kan een afwijkende zittingsplaats worden aangewezen. De Minister van Justitie kan, na overleg met het gerechtsbestuur besluiten om een rechtszaak op een andere locatie plaats te laten vinden in verband met veiligheidsoverwegingen. Handeling is niet van toepassing op de CRvB.', NULL, '1', 'Organisatie', 'Rechterlijke Organisatie')
                      , ('12', 'Het (laten) onderhouden en beheren van gegevensbestanden met betrekking tot het behandelen en beslissen van rechtszaken', NULL, NULL, NULL, '7', 'Organisatie', 'Rechterlijke Organisatie')
                      , ('79', 'Het opstellen van verslagen betreffende het beleid inzake de bedrijfsvoering van de rechterlijke macht en de uitvoering daarvan', NULL, NULL, '(Jaar)verslag', NULL, 'Verantwoording en voorlichting', 'Rechterlijke Organisatie')
                      , ('80', 'Het beantwoorden van vragen van individuele burgers, bedrijven en instellingen betreffende de bedrijfsvoering van de rechterlijke macht', NULL, NULL, NULL, '2', 'Verantwoording en voorlichting', 'Rechterlijke Organisatie')
                      , ('81', 'Het uitvoeren van voorlichtingsactiviteiten op het terrein van de bedrijfsvoering van de rechterlijke macht (brochures, artikelen, films, enz.)', NULL, NULL, NULL, NULL, 'Verantwoording en voorlichting', 'Rechterlijke Organisatie')
                      , ('82', 'Het ontwikkelen, vaststellen en wijzigen van een klachtenregeling betreffende de bedrijfsvoering van de rechterlijke organisatie', NULL, NULL, NULL, NULL, 'Klachten', 'Rechterlijke Organisatie')
                      , ('83', 'Het behandelen van klachten van burgers over hun behandeling tijdens rechtszaken', NULL, 'Betreft alle klachten die niet rechtstreeks betrekking hebben op een zaak, bijv. klachten tegen bejegening door gerechtsambtenaren, niet tijdig beantwoorden van brieven, etc.', NULL, '10', 'Klachten', 'Rechterlijke Organisatie')
                      , ('84', 'Het vaststellen van de opdracht en het eindproduct van een intern of extern (wetenschappelijk) onderzoek betreffende de bedrijfsvoering van de rechterlijke macht', NULL, NULL, NULL, NULL, 'Onderzoek', 'Rechterlijke Organisatie')
                      , ('85', 'Het (laten) uitvoeren van onderzoeken naar de kwaliteit van de rechterlijke organisatie, het rechterlijke functioneren en uniforme rechtstoepassing', NULL, NULL, NULL, NULL, 'Onderzoek', 'Rechterlijke Organisatie')
                      , ('86', 'Het (doen) uitvoeren van onderzoeken betreffende de efficiëntie, effectiviteit en kwaliteit van de eigen bedrijfsvoering', NULL, NULL, NULL, NULL, 'Onderzoek', 'Rechterlijke Organisatie')
                      , ('87', 'Het deelnemen aan advies- of overlegcommissies en werkgroepen inzake de bedrijfsvoering van de rechterlijke macht waarvan het secretariaat bij de eigen organisatie berust', NULL, NULL, NULL, NULL, 'Overleg', 'Rechterlijke Organisatie')
                      , ('88', 'Het deelnemen aan advies- of overlegcommissies en werkgroepen inzake de bedrijfsvoering van de rechterlijke macht waarvan het secretariaat niet bij de eigen organisatie berust', NULL, NULL, NULL, '5', 'Overleg', 'Rechterlijke Organisatie')
                      , ('89', 'Het adviseren van de Minister van Justitie inzake de rechterlijke organisatie', 'Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555, art. 17 e.v.: RAIO-selectiecommissie)', NULL, NULL, NULL, 'Overleg', 'Commissie of Raad')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug NatuurlijkPersoon                 *
    *                                        *
    * fields:                                *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]   *
    * strafrechtsketennummer~  [UNI,INJ,SUR] *
    * gbaBSN  [UNI,TOT]                      *
    * geboortedatum  [UNI]                   *
    * geboorteplaats  [UNI]                  *
    * geboorteland  [UNI]                    *
    * woonplaats  [UNI]                      *
    * geslacht  [UNI]                        *
    \****************************************/
    mysql_query("CREATE TABLE `NatuurlijkPersoon`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `strafrechtsketennummer` VARCHAR(255) DEFAULT NULL
                     , `gbaBSN` VARCHAR(255) DEFAULT NULL
                     , `geboortedatum` VARCHAR(255) DEFAULT NULL
                     , `geboorteplaats` VARCHAR(255) DEFAULT NULL
                     , `geboorteland` VARCHAR(255) DEFAULT NULL
                     , `woonplaats` VARCHAR(255) DEFAULT NULL
                     , `geslacht` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `NatuurlijkPersoon` (`NatuurlijkPersoon` ,`strafrechtsketennummer` ,`gbaBSN` ,`geboortedatum` ,`geboorteplaats` ,`geboorteland` ,`woonplaats` ,`geslacht` )
                VALUES ('13', NULL, '45896310', '03-05-1980', '\'s-Gravenhage', 'Nederland', 'Thorbeckelaan 342, 2564BZ \'s-Gravenhage', 'Man')
                      , ('17', NULL, '49876337', '15-02-1989', 'Heerenveen', 'Nederland', 'Hooizolder 386, 9205CW Drachten', 'Man')
                      , ('14', NULL, '35497763', '10-12-1968', 'Zenderen', 'Nederland', 'Erve Kokenberg 1, 7625NH Zenderen', 'Man')
                      , ('15', '004995', '79823438', '27-11-1976', 'Almelo', 'Nederland', 'Bornsestraat 28, 7556BG Hengelo ov', 'Man')
                      , ('16', NULL, '46936557', '30-06-1984', 'Ittersum', 'Nederland', 'Zeedijken 42, 9919BM Loppersum', 'Man')
                      , ('12', NULL, '63254896', '25-04-1975', 'Zwijndrecht', 'Nederland', 'Heimerstein 91, 3328MH Dordrecht', 'Man')
                      , ('10', NULL, '45031741', '30-12-1955', 'Utrecht', 'Nederland', 'Zeedijken 42, 9919BM Loppersum', 'Vrouw')
                      , ('18', NULL, '78974651', '26-05-1980', 'Almelo', 'Nederland', 'Westhavenkade 98, 3133AV Vlaardingen', 'Vrouw')
                      , ('1', NULL, '23587435', '12-10-1967', 'Middelburg', 'Nederland', 'Noordbolwerk 33, 4331SH Middelburg', 'Man')
                      , ('2', '007487', '56327491', '06-07-1980', 'Veghel', 'Nederland', 'Westhavenkade 98, 3133AV Vlaardingen', 'Man')
                      , ('3', NULL, '78954566', '31-02-1970', 'Stockholm', 'Zweden', 'Koornbeursweg 132, 8442DJ Heerenveen', 'Man')
                      , ('4', NULL, '14676455', '25-03-1962', 'Amsterdam', 'Nederland', 'Johannes Verhulststraat 55/HS, 1071MS Amsterdam', 'Man')
                      , ('5', NULL, '58974564', '01-05-1982', 'Tilburg', 'Nederland', 'Kruisherenstraat 56, 3078GT Rotterdam', 'Man')
                      , ('6', NULL, '15876456', '16-07-1976', 'Spijkenisse', 'Nederland', 'Gezichtslaan 52, 3723GG Bilthoven', 'Vrouw')
                      , ('7', NULL, '45896541', '12-11-1981', 'Haps', 'Nederland', 'Kalkhofseweg 25, 5443NB Haps', 'Vrouw')
                      , ('8', NULL, '56975633', '12-01-1959', 'Enschede', 'Nederland', 'Weldammerbos 17, 7543GW Enschede', 'Man')
                      , ('9', NULL, '62096541', '25-02-1948', 'Heerenveen', 'Nederland', 'Koornbeursweg 132, 8442DJ Heerenveen', 'Man')
                      , ('11', NULL, '72896694', '04-07-1965', 'Arnhem', 'Nederland', 'Erve Kokenberg 1, 7625NH Zenderen', 'Man')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zitting                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * behandeling  [UNI]                   *
    * zittingszaal  [UNI]                  *
    * griffier  [UNI]                      *
    * geagendeerd  [UNI,TOT]               *
    * begintijd  [UNI]                     *
    * eindtijd  [UNI]                      *
    \**************************************/
    mysql_query("CREATE TABLE `Zitting`
                     ( `Zitting` VARCHAR(255) DEFAULT NULL
                     , `behandeling` VARCHAR(255) DEFAULT NULL
                     , `zittingszaal` VARCHAR(255) DEFAULT NULL
                     , `griffier` VARCHAR(255) DEFAULT NULL
                     , `geagendeerd` VARCHAR(255) DEFAULT NULL
                     , `begintijd` VARCHAR(255) DEFAULT NULL
                     , `eindtijd` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zitting` (`Zitting` ,`behandeling` ,`zittingszaal` ,`griffier` ,`geagendeerd` ,`begintijd` ,`eindtijd` )
                VALUES ('Zitting RbLee 591', 'Behandeling 11/123458', 'Zaal 1', 'mr. G.M. Fondse', '03-12-2010', '15:00', NULL)
                      , ('Zitting RbsGr 35', 'Behandeling 10/569423', 'Zaal 1', 'mr. C.C. de Rijke-Maas', '23-05-2011', '15:15', NULL)
                      , ('Zitting RbAlm 68', 'Behandeling 11/489631', 'Zaal 2', 'mr. B.M. Hoek', '12-09-2011', '09:10', NULL)
                      , ('Zitting Hrlm 32', 'Behandeling 4', NULL, NULL, '15-04-2008', '16:00', NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijving                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * gerichtaan  [UNI,TOT]                *
    * inschrijvingseis  [UNI]              *
    * inschrijvingsstatus  [UNI,TOT]       *
    * isadvocaat  [UNI,TOT]                *
    * houdtkantoor  [UNI]                  *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijving`
                     ( `Inschrijving` VARCHAR(255) DEFAULT NULL
                     , `gerichtaan` VARCHAR(255) DEFAULT NULL
                     , `inschrijvingseis` VARCHAR(255) DEFAULT NULL
                     , `inschrijvingsstatus` VARCHAR(255) DEFAULT NULL
                     , `isadvocaat` VARCHAR(255) DEFAULT NULL
                     , `houdtkantoor` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijving` (`Inschrijving` ,`gerichtaan` ,`inschrijvingseis` ,`inschrijvingsstatus` ,`isadvocaat` ,`houdtkantoor` )
                VALUES ('Inschrijving 1', 'Rechtbank Amsterdam', 'voldoet', 'onvoorwaardelijk', '4', 'K52347')
                      , ('Inschrijving 2', 'Rechtbank Rotterdam', 'voldoet', 'voorwaardelijk', '5', 'K45317')
                      , ('Inschrijving 3', 'Rechtbank Utrecht', 'voldoet', 'onvoorwaardelijk', '6', 'K48933')
                      , ('Inschrijving 4', 'Rechtbank Utrecht', 'voldoet', 'onvoorwaardelijk', '7', 'K12493')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Vertegenwoordiging              *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * vertegenwoordiger  [UNI,TOT]         *
    * inzake  [UNI,TOT]                    *
    * vertegenwoordigt  [UNI,TOT]          *
    * machtiging  [UNI,TOT]                *
    \**************************************/
    mysql_query("CREATE TABLE `Vertegenwoordiging`
                     ( `Vertegenwoordiging` VARCHAR(255) DEFAULT NULL
                     , `vertegenwoordiger` VARCHAR(255) DEFAULT NULL
                     , `inzake` VARCHAR(255) DEFAULT NULL
                     , `vertegenwoordigt` VARCHAR(255) DEFAULT NULL
                     , `machtiging` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Beroepschrift                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * beroepschrift  [UNI,TOT]             *
    * dagtekening  [UNI,TOT]               *
    * omschrijvingberoep  [UNI,TOT]        *
    * grondenberoep  [UNI,TOT]             *
    \**************************************/
    mysql_query("CREATE TABLE `Beroepschrift`
                     ( `Beroepschrift0` VARCHAR(255) DEFAULT NULL
                     , `beroepschrift1` VARCHAR(255) DEFAULT NULL
                     , `dagtekening` VARCHAR(255) DEFAULT NULL
                     , `omschrijvingberoep` VARCHAR(255) DEFAULT NULL
                     , `grondenberoep` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Beroepschrift` (`Beroepschrift0` ,`beroepschrift1` ,`dagtekening` ,`omschrijvingberoep` ,`grondenberoep` )
                VALUES ('Beroepschrift 1', 'Beroep20120221', '20-02-2012', 'Ik ben het oneens met de beslissing genomen door de Gemeente Utrecht omtrent het verlenen van kapvergunning XXXX.', 'Art. XX lid Y Wm')
                      , ('Beroepschrift 2', 'Beroep20120115', '15-01-2012', 'Ik ben het oneens met de beslissing genomen door het UWV omtrent het uitstellen van mijn WW-uitkering.', 'Art. XX IWfsv')
                      , ('Beroepschrift 3', 'Beroep20120203', '03-02-2012', 'Ik ben het oneens met de beslissing tot ongegrondverklaring van het eerder ingediende bezwaarschrift met kenmerk XXXX.', 'Art. WVW1994')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Orgaan                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * Rechtbank~  [INJ,SUR,UNI]            *
    * Gerechtshof~  [INJ,SUR,UNI]          *
    * ressort  [UNI]                       *
    \**************************************/
    mysql_query("CREATE TABLE `Orgaan`
                     ( `Orgaan` VARCHAR(255) DEFAULT NULL
                     , `Rechtbank` VARCHAR(255) DEFAULT NULL
                     , `Gerechtshof` VARCHAR(255) DEFAULT NULL
                     , `ressort` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Orgaan` (`Orgaan` ,`Rechtbank` ,`Gerechtshof` ,`ressort` )
                VALUES ('Gerechtshof Amsterdam', NULL, 'Gerechtshof Amsterdam', 'Amsterdam')
                      , ('Gerechtshof Arnhem', NULL, 'Gerechtshof Arnhem', 'Arnhem')
                      , ('Gerechtshof \'s-Gravenhage', NULL, 'Gerechtshof \'s-Gravenhage', '\'s-Gravenhage')
                      , ('Gerechtshof \'s-Hertogenbosch', NULL, 'Gerechtshof \'s-Hertogenbosch', 'Den Bosch')
                      , ('Gerechtshof Leeuwarden', NULL, 'Gerechtshof Leeuwarden', 'Leeuwarden')
                      , ('Raad van State', NULL, 'Raad van State', 'Den Haag')
                      , ('Rechtbank Amsterdam', 'Rechtbank Amsterdam', NULL, NULL)
                      , ('Rechtbank Den Haag', 'Rechtbank Den Haag', NULL, NULL)
                      , ('Rechtbank Limburg', 'Rechtbank Limburg', NULL, NULL)
                      , ('Rechtbank Midden-Nederland', 'Rechtbank Midden-Nederland', NULL, NULL)
                      , ('Rechtbank Noord-Holland', 'Rechtbank Noord-Holland', NULL, NULL)
                      , ('Rechtbank Noord-Nederland', 'Rechtbank Noord-Nederland', NULL, NULL)
                      , ('Rechtbank Oost-Brabant', 'Rechtbank Oost-Brabant', NULL, NULL)
                      , ('Rechtbank Oost-Nederland', 'Rechtbank Oost-Nederland', NULL, NULL)
                      , ('Rechtbank Rotterdam', 'Rechtbank Rotterdam', NULL, NULL)
                      , ('Rechtbank Zeeland-West-Brabant', 'Rechtbank Zeeland-West-Brabant', NULL, NULL)
                      , ('Gerechtshof Den Haag', NULL, 'Gerechtshof Den Haag', NULL)
                      , ('Gerechtshof Arnhem-Leeuwarden', NULL, 'Gerechtshof Arnhem-Leeuwarden', NULL)
                      , ('Rechtbank Utrecht', 'Rechtbank Utrecht', NULL, NULL)
                      , ('Rechtbank Leeuwarden', 'Rechtbank Leeuwarden', NULL, NULL)
                      , ('Rechtbank Almelo', 'Rechtbank Almelo', NULL, NULL)
                      , ('Rechtbank Alkmaar', 'Rechtbank Alkmaar', NULL, NULL)
                      , ('Rechtbank Arnhem', 'Rechtbank Arnhem', NULL, NULL)
                      , ('Rechtbank Groningen', 'Rechtbank Groningen', NULL, NULL)
                      , ('Rechtbank Assen', 'Rechtbank Assen', NULL, NULL)
                      , ('Rechtbank Breda', 'Rechtbank Breda', NULL, NULL)
                      , ('Rechtbank Roermond', 'Rechtbank Roermond', NULL, NULL)
                      , ('Rechtbank \'s-Gravenhage', 'Rechtbank \'s-Gravenhage', NULL, NULL)
                      , ('Rechtbank Dordrecht', 'Rechtbank Dordrecht', NULL, NULL)
                      , ('Rechtbank Haarlem', 'Rechtbank Haarlem', NULL, NULL)
                      , ('Rechtbank Maastricht', 'Rechtbank Maastricht', NULL, NULL)
                      , ('Rechtbank Middelburg', 'Rechtbank Middelburg', NULL, NULL)
                      , ('Rechtbank Zutphen', 'Rechtbank Zutphen', NULL, NULL)
                      , ('Rechtbank Zwolle-Lelystad', 'Rechtbank Zwolle-Lelystad', NULL, NULL)
                      , ('Rechtbank \'s-Hertogenbosch', 'Rechtbank \'s-Hertogenbosch', NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaakid                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * zaakid  [UNI]                        *
    * soortrecht  [UNI]                    *
    * zaaksoort  [UNI]                     *
    \**************************************/
    mysql_query("CREATE TABLE `Zaakid`
                     ( `Zaakid0` VARCHAR(255) DEFAULT NULL
                     , `zaakid1` VARCHAR(255) DEFAULT NULL
                     , `soortrecht` VARCHAR(255) DEFAULT NULL
                     , `zaaksoort` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaakid` (`Zaakid0` ,`zaakid1` ,`soortrecht` ,`zaaksoort` )
                VALUES ('Zaak 4', '11/123458', 'Geldvordering', 'Kort geding')
                      , ('Zaak 5', '10/569423', 'Mulder beroep', 'Eerste aanleg')
                      , ('Zaak 6', '11/489631', 'Strabis verzet', 'Eerste aanleg')
                      , ('Zaak 7', '08/476197', NULL, NULL)
                      , ('Zaak 10', '09/565223', NULL, NULL)
                      , ('Zaak 11', '12/00431', NULL, NULL)
                      , ('Zaak 12', '11/100197', NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaak                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * volgnr  [UNI]                        *
    * zaaknr  [UNI]                        *
    * systeemcode  [UNI]                   *
    \**************************************/
    mysql_query("CREATE TABLE `Zaak`
                     ( `Zaak` VARCHAR(255) DEFAULT NULL
                     , `volgnr` VARCHAR(255) DEFAULT NULL
                     , `zaaknr` VARCHAR(255) DEFAULT NULL
                     , `systeemcode` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaak` (`Zaak` ,`volgnr` ,`zaaknr` ,`systeemcode` )
                VALUES ('11/123458', NULL, NULL, NULL)
                      , ('10/569423', NULL, NULL, NULL)
                      , ('11/489631', NULL, NULL, NULL)
                      , ('08/476197', NULL, NULL, NULL)
                      , ('09/565223', NULL, NULL, NULL)
                      , ('12/00431', NULL, NULL, NULL)
                      , ('11/100197', NULL, NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug SESSION                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * sessionGebruikersnaam  [UNI]         *
    * sessionWachtwoord  [UNI]             *
    \**************************************/
    mysql_query("CREATE TABLE `SESSION`
                     ( `SESSION` VARCHAR(255) DEFAULT NULL
                     , `sessionGebruikersnaam` VARCHAR(255) DEFAULT NULL
                     , `sessionWachtwoord` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Arrondissement                  *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * arrondisement  [UNI]                 *
    * ressorteert  [UNI]                   *
    \**************************************/
    mysql_query("CREATE TABLE `Arrondissement`
                     ( `Arrondissement` VARCHAR(255) DEFAULT NULL
                     , `arrondisement` VARCHAR(255) DEFAULT NULL
                     , `ressorteert` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Arrondissement` (`Arrondissement` ,`arrondisement` ,`ressorteert` )
                VALUES ('Alkmaar', 'Rechtbank Alkmaar', 'Amsterdam')
                      , ('Almelo', 'Rechtbank Almelo', 'Arnhem')
                      , ('Amsterdam', 'Rechtbank Amsterdam', 'Amsterdam')
                      , ('Arnhem', 'Rechtbank Arnhem', 'Arnhem')
                      , ('Groningen', 'Rechtbank Groningen', 'Leeuwarden')
                      , ('Assen', 'Rechtbank Assen', 'Leeuwarden')
                      , ('Breda', 'Rechtbank Breda', '\'s-Hertogenbosch')
                      , ('Roermond', 'Rechtbank Roermond', '\'s-Hertogenbosch')
                      , ('\'s-Gravenhage', 'Rechtbank \'s-Gravenhage', '\'s-Gravenhage')
                      , ('Dordrecht', 'Rechtbank Dordrecht', '\'s-Gravenhage')
                      , ('Haarlem', 'Rechtbank Haarlem', 'Amsterdam')
                      , ('Leeuwarden', 'Rechtbank Leeuwarden', 'Leeuwarden')
                      , ('Maastricht', 'Rechtbank Maastricht', '\'s-Hertogenbosch')
                      , ('Middelburg', 'Rechtbank Middelburg', '\'s-Gravenhage')
                      , ('Rotterdam', 'Rechtbank Rotterdam', '\'s-Gravenhage')
                      , ('Utrecht', 'Rechtbank Utrecht', 'Amsterdam')
                      , ('Zutphen', 'Rechtbank Zutphen', 'Arnhem')
                      , ('Zwolle', 'Rechtbank Zwolle-Lelystad', NULL)
                      , ('Lelystad', 'Rechtbank Zwolle-Lelystad', NULL)
                      , ('Zwolle-Lelystad', NULL, 'Leeuwarden')
                      , ('\'s-Hertogenbosch', NULL, '\'s-Hertogenbosch')
                      , ('Noord-Holland', NULL, NULL)
                      , ('Midden-Nederland', NULL, NULL)
                      , ('Oost-Nederland', NULL, NULL)
                      , ('Zeeland-West-Brabant', NULL, NULL)
                      , ('Noord-Nederland', NULL, NULL)
                      , ('Den Haag', NULL, NULL)
                      , ('Limburg', NULL, NULL)
                      , ('Oost-Brabant', NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug MondelingeBehandeling           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * procesverbaal  [UNI]                 *
    * gesloten  [UNI]                      *
    \**************************************/
    mysql_query("CREATE TABLE `MondelingeBehandeling`
                     ( `MondelingeBehandeling` VARCHAR(255) DEFAULT NULL
                     , `procesverbaal` VARCHAR(255) DEFAULT NULL
                     , `gesloten` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `MondelingeBehandeling` (`MondelingeBehandeling` ,`procesverbaal` ,`gesloten` )
                VALUES ('Behandeling 10/569423', 'Proc 11/123458', '14:15')
                      , ('Behandeling 11/123458', 'Proc 10/569423', '13:00')
                      , ('Behandeling 11/489631', 'Proc 11/489631', '12:13')
                      , ('Behandeling 4', NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kantoornummer                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * kantoornaam  [UNI,TOT]               *
    * kantooradres  [UNI,TOT]              *
    \**************************************/
    mysql_query("CREATE TABLE `Kantoornummer`
                     ( `Kantoornummer` VARCHAR(255) DEFAULT NULL
                     , `kantoornaam` VARCHAR(255) DEFAULT NULL
                     , `kantooradres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kantoornummer` (`Kantoornummer` ,`kantoornaam` ,`kantooradres` )
                VALUES ('K52347', 'Wieringa advocaten', 'Herengracht 425-429, 1017 BR, Amsterdam')
                      , ('K45317', 'Haulussy advocaten', 'Westblaak 5f, 3001 AC, Rotterdam')
                      , ('K48933', 'Kuipers, Jonkers, van den Berg', 'Mariahoek 4, 3511 LD, Utrecht')
                      , ('K12493', 'ATM Advocaten Utrecht', 'Herculesplein 213, 3584 AA, Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Document                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * verzoektotinschrijving  [UNI]        *
    * inschrijvingsverzoek  [UNI]          *
    \**************************************/
    mysql_query("CREATE TABLE `Document`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `verzoektotinschrijving` VARCHAR(255) DEFAULT NULL
                     , `inschrijvingsverzoek` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Document` (`Document` ,`verzoektotinschrijving` ,`inschrijvingsverzoek` )
                VALUES ('Vti1', '4', 'Inschrijving 1')
                      , ('Vti2', '5', 'Inschrijving 2')
                      , ('Vti3', '6', 'Inschrijving 3')
                      , ('Vti4', '7', 'Inschrijving 4')
                      , ('Proc 11/123458', NULL, NULL)
                      , ('Proc 10/569423', NULL, NULL)
                      , ('Proc 11/489631', NULL, NULL)
                      , ('Dag20120205', NULL, NULL)
                      , ('Dag20110513', NULL, NULL)
                      , ('Dag20110216', NULL, NULL)
                      , ('Strafblad 2684', NULL, NULL)
                      , ('Strafblad 8311', NULL, NULL)
                      , ('Conclusie20120319', NULL, NULL)
                      , ('Conclusie20110627', NULL, NULL)
                      , ('Conclusie20110330', NULL, NULL)
                      , ('Beroep20120221', NULL, NULL)
                      , ('Beroep20120115', NULL, NULL)
                      , ('Beroep20120203', NULL, NULL)
                      , ('Von11/123458', NULL, NULL)
                      , ('Von10/569423', NULL, NULL)
                      , ('Von11/489631', NULL, NULL)
                      , ('Verzoek tot schorsing 11/5', NULL, NULL)
                      , ('Verzoek tot opheffing schorsing 12/4', NULL, NULL)
                      , ('BR9826', NULL, NULL)
                      , ('BU9872', NULL, NULL)
                      , ('BU2372', NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Bformulier                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * door  [UNI,TOT]                      *
    \**************************************/
    mysql_query("CREATE TABLE `Bformulier`
                     ( `Bformulier` VARCHAR(255) DEFAULT NULL
                     , `door` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug SchriftelijkeUitspraak          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * motivering  [UNI]                    *
    \**************************************/
    mysql_query("CREATE TABLE `SchriftelijkeUitspraak`
                     ( `SchriftelijkeUitspraak` VARCHAR(255) DEFAULT NULL
                     , `motivering` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `SchriftelijkeUitspraak` (`SchriftelijkeUitspraak` ,`motivering` )
                VALUES ('Vonnis 1', NULL)
                      , ('Vonnis 2', NULL)
                      , ('Vonnis 3', NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Selectiecriterium               *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * tekst  [UNI,TOT]                     *
    \**************************************/
    mysql_query("CREATE TABLE `Selectiecriterium`
                     ( `Selectiecriterium` VARCHAR(255) DEFAULT NULL
                     , `tekst` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Selectiecriterium` (`Selectiecriterium` ,`tekst` )
                VALUES ('1', 'Handelingen die betrekking hebben op voorbereiding en bepaling van beleid op hoofdlijnen')
                      , ('2', 'Handelingen die betrekking hebben op evaluatie van beleid op hoofdlijnen')
                      , ('3', 'Handelingen die betrekking hebben op verantwoording van beleid op hoofdlijnen aan andere actoren')
                      , ('4', 'Handelingen die betrekking hebben op (her)inrichting van organisaties belast met beleid op hoofdlijnen')
                      , ('5', 'Handelingen die bepalend zijn voor de wijze waarop beleidsuitvoering op hoofdlijnen plaatsvindt')
                      , ('6', 'Handelingen die betrekking hebben op beleidsuitvoering op hoofdlijnen en direct zijn gerelateerd aan of direct voortvloeien uit voor het Koninkrijk der Nederlanden bijzondere tijdsomstandigheden en incidenten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Anummer                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * gba  [UNI]                           *
    \**************************************/
    mysql_query("CREATE TABLE `Anummer`
                     ( `Anummer` VARCHAR(255) DEFAULT NULL
                     , `gba` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Anummer` (`Anummer` ,`gba` )
                VALUES ('A1567845614', '1')
                      , ('A4587623462', '2')
                      , ('A3265123987', '3')
                      , ('A2598776542', '4')
                      , ('A5687765231', '5')
                      , ('A1002546886', '6')
                      , ('A6740656461', '7')
                      , ('A6547890374', '8')
                      , ('A1149890396', '9')
                      , ('A6539590322', '10')
                      , ('A3211890374', '11')
                      , ('A6565119819', '12')
                      , ('A5216056127', '13')
                      , ('A6131546842', '14')
                      , ('A1551215379', '15')
                      , ('A1168773213', '16')
                      , ('A1447945463', '7')
                      , ('A8374764583', '18')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Plaats                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * neven  [UNI]                         *
    \**************************************/
    mysql_query("CREATE TABLE `Plaats`
                     ( `Plaats` VARCHAR(255) DEFAULT NULL
                     , `neven` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Plaats` (`Plaats` ,`neven` )
                VALUES ('Hoorn', 'Rechtbank Alkmaar')
                      , ('Enschede', 'Rechtbank Almelo')
                      , ('Hilversum', 'Rechtbank Amsterdam')
                      , ('Tiel', 'Rechtbank Arnhem')
                      , ('Nijmegen', 'Rechtbank Arnhem')
                      , ('Emmen', 'Rechtbank Assen')
                      , ('Tilburg', 'Rechtbank Breda')
                      , ('Bergen op Zoom', 'Rechtbank Breda')
                      , ('Delft', 'Rechtbank \'s-Gravenhage')
                      , ('Leiden', 'Rechtbank \'s-Gravenhage')
                      , ('Gouda', 'Rechtbank \'s-Gravenhage')
                      , ('Alphen aan den Rijn', 'Rechtbank \'s-Gravenhage')
                      , ('Haarlemmermeer', 'Rechtbank Haarlem')
                      , ('Zaanstad', 'Rechtbank Haarlem')
                      , ('Eindhoven', 'Rechtbank \'s-Hertogenbosch')
                      , ('Helmond', 'Rechtbank \'s-Hertogenbosch')
                      , ('Boxmeer', 'Rechtbank \'s-Hertogenbosch')
                      , ('Heerenveen', 'Rechtbank Leeuwarden')
                      , ('Heerlen', 'Rechtbank Maastricht')
                      , ('Sittard-Geleen', 'Rechtbank Maastricht')
                      , ('Terneuzen', 'Rechtbank Middelburg')
                      , ('Venlo', 'Rechtbank Roermond')
                      , ('Brielle', 'Rechtbank Rotterdam')
                      , ('Amersfoort', 'Rechtbank Utrecht')
                      , ('Apeldoorn', 'Rechtbank Zutphen')
                      , ('Deventer', 'Rechtbank Zwolle-Lelystad')
                      , ('Lelystad', 'Rechtbank Zwolle-Lelystad')
                      , ('Middelburg', NULL)
                      , ('Veghel', NULL)
                      , ('Stockholm', NULL)
                      , ('Amsterdam', NULL)
                      , ('Spijkenisse', NULL)
                      , ('Haps', NULL)
                      , ('Utrecht', NULL)
                      , ('Arnhem', NULL)
                      , ('Zwijndrecht', NULL)
                      , ('\'s-Gravenhage', NULL)
                      , ('Zenderen', NULL)
                      , ('Almelo', NULL)
                      , ('Ittersum', NULL)
                      , ('Leeuwarden', NULL)
                      , ('Groningen', NULL)
                      , ('Rotterdam', NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Griffier                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * griffiertekent  [UNI]                *
    \**************************************/
    mysql_query("CREATE TABLE `Griffier`
                     ( `Griffier` VARCHAR(255) DEFAULT NULL
                     , `griffiertekent` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Griffier` (`Griffier` ,`griffiertekent` )
                VALUES ('mr. G.M. Fondse', 'Proc 11/123458')
                      , ('mr. C.C. de Rijke-Maas', 'Proc 10/569423')
                      , ('mr. B.M. Hoek', 'Proc 11/489631')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaalnaam                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * zaalnaam  [UNI,TOT]                  *
    \**************************************/
    mysql_query("CREATE TABLE `Zaalnaam`
                     ( `Zaalnaam0` VARCHAR(255) DEFAULT NULL
                     , `zaalnaam1` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaalnaam` (`Zaalnaam0` ,`zaalnaam1` )
                VALUES ('14', 'Zaal 1')
                      , ('A', 'Zaal 2')
                      , ('Kleine zaal', 'Zaal 3')
                      , ('Grote zaal', 'Zaal 4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Barnummer                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * barnummer  [UNI,TOT]                 *
    \**************************************/
    mysql_query("CREATE TABLE `Barnummer`
                     ( `Barnummer0` VARCHAR(255) DEFAULT NULL
                     , `barnummer1` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Barnummer` (`Barnummer0` ,`barnummer1` )
                VALUES ('A23968', 'Inschrijving 1')
                      , ('A26815', 'Inschrijving 2')
                      , ('A16378', 'Inschrijving 3')
                      , ('A24763', 'Inschrijving 4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Wachtwoord1                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Wachtwoord1`
                     ( `Wachtwoord` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Wachtwoord1` (`Wachtwoord` )
                VALUES ('de')
                      , ('vv')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug wachtwoord2                 *
    *                                  *
    * fields:                          *
    * I/\wachtwoord;wachtwoord~  [ASY] *
    * wachtwoord  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `wachtwoord2`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                     , `Wachtwoord` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `wachtwoord2` (`Rechter` ,`Wachtwoord` )
                VALUES ('Rechter 10', 'de')
                      , ('Rechter 9', 'vv')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Beslissing1                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Beslissing1`
                     ( `Beslissing` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Beslissing1` (`Beslissing` )
                VALUES ('Schuldig bevonden aan feit')
                      , ('Beslissing 2')
                      , ('Beslissing 3')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug beslissing2                 *
    *                                  *
    * fields:                          *
    * I/\beslissing;beslissing~  [ASY] *
    * beslissing  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `beslissing2`
                     ( `SchriftelijkeUitspraak` VARCHAR(255) DEFAULT NULL
                     , `Beslissing` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `beslissing2` (`SchriftelijkeUitspraak` ,`Beslissing` )
                VALUES ('Vonnis 1', 'Schuldig bevonden aan feit')
                      , ('Vonnis 2', 'Beslissing 2')
                      , ('Vonnis 3', 'Beslissing 3')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Waardering1                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Waardering1`
                     ( `Waardering` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Waardering1` (`Waardering` )
                VALUES ('B')
                      , ('V')
                      , ('B1')
                      , ('Vn')
                      , ('Va')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug waardering2                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * waardering  [TOT]                    *
    \**************************************/
    mysql_query("CREATE TABLE `waardering2`
                     ( `Handeling` VARCHAR(255) DEFAULT NULL
                     , `Waardering` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `waardering2` (`Handeling` ,`Waardering` )
                VALUES ('1', 'B')
                      , ('4', 'V')
                      , ('5', 'V')
                      , ('6', 'B1')
                      , ('7', 'B')
                      , ('8', 'V')
                      , ('9', 'B1')
                      , ('10', 'B')
                      , ('11', 'Vn')
                      , ('13', 'V')
                      , ('14', 'B')
                      , ('15', 'B')
                      , ('16', 'V')
                      , ('17', 'B1')
                      , ('58', 'B')
                      , ('18', 'V')
                      , ('19', 'V')
                      , ('20', 'V')
                      , ('21', 'V')
                      , ('22', 'V')
                      , ('23', 'V')
                      , ('24', 'V')
                      , ('25', 'V')
                      , ('26', 'V')
                      , ('27', 'Va')
                      , ('28', 'B')
                      , ('29', 'B')
                      , ('30', 'V')
                      , ('31', 'V')
                      , ('32', 'V')
                      , ('33', 'V')
                      , ('34', 'V')
                      , ('35', 'V')
                      , ('36', 'B')
                      , ('37', 'B')
                      , ('38', 'V')
                      , ('39', 'V')
                      , ('40', 'B')
                      , ('41', 'V')
                      , ('42', 'B')
                      , ('43', 'V')
                      , ('44', 'B')
                      , ('45', 'B')
                      , ('59', 'B')
                      , ('60', 'B')
                      , ('61', 'V')
                      , ('62', 'V')
                      , ('63', 'V')
                      , ('64', 'V')
                      , ('46', 'V')
                      , ('47', 'V')
                      , ('48', 'V')
                      , ('49', 'V')
                      , ('50', 'V')
                      , ('51', 'V')
                      , ('52', 'B')
                      , ('53', 'V')
                      , ('54', 'V')
                      , ('55', 'V')
                      , ('56', 'V')
                      , ('57', 'V')
                      , ('65', 'B1')
                      , ('66', 'V')
                      , ('2', 'B')
                      , ('3', 'B1')
                      , ('67', 'V')
                      , ('68', 'V')
                      , ('69', 'V')
                      , ('70', 'B')
                      , ('71', 'V')
                      , ('72', 'B')
                      , ('73', 'B')
                      , ('74', 'B')
                      , ('75', 'B')
                      , ('76', 'V')
                      , ('77', 'V')
                      , ('78', 'V')
                      , ('12', 'V')
                      , ('79', 'B')
                      , ('80', 'V')
                      , ('81', 'B1')
                      , ('82', 'B1')
                      , ('83', 'V')
                      , ('84', 'B')
                      , ('85', 'B')
                      , ('86', 'B')
                      , ('87', 'B')
                      , ('88', 'V')
                      , ('89', 'B')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Actor                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Actor`
                     ( `Actor` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Actor` (`Actor` )
                VALUES ('Minister van Justitie')
                      , ('Rechterlijke Organisatie')
                      , ('Commissie of Raad')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Categorie                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Categorie`
                     ( `Categorie` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Categorie` (`Categorie` )
                VALUES ('Beleidsontwikkeling en algemene zaken')
                      , ('Regelgeving en juridische zaken')
                      , ('Personeel')
                      , ('Organisatie')
                      , ('Financiën')
                      , ('Documentatie en informatie')
                      , ('Huisvesting en materieel')
                      , ('Klachten')
                      , ('Onderzoek')
                      , ('Overleg')
                      , ('Beleid')
                      , ('Advies')
                      , ('Verantwoording en voorlichting')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Vernietigingstermijn            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Vernietigingstermijn`
                     ( `Vernietigingstermijn` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Vernietigingstermijn` (`Vernietigingstermijn` )
                VALUES ('10')
                      , ('2')
                      , ('7')
                      , ('70, of 1 jaar na aftreden')
                      , ('15')
                      , ('5')
                      , ('1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug RIO handeling                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `RIO handeling`
                     ( `RIO handeling` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `RIO handeling` (`RIO handeling` )
                VALUES ('6')
                      , ('8')
                      , ('9')
                      , ('16')
                      , ('17')
                      , ('18')
                      , ('22')
                      , ('24')
                      , ('25')
                      , ('27')
                      , ('51')
                      , ('57')
                      , ('69')
                      , ('71')
                      , ('74')
                      , ('37')
                      , ('39')
                      , ('60')
                      , ('67')
                      , ('73')
                      , ('11')
                      , ('15')
                      , ('21')
                      , ('23')
                      , ('49')
                      , ('32')
                      , ('101')
                      , ('102')
                      , ('4')
                      , ('14')
                      , ('20')
                      , ('48a')
                      , ('53')
                      , ('55')
                      , ('43')
                      , ('46')
                      , ('48')
                      , ('(48a)')
                      , ('50')
                      , ('56')
                      , ('98')
                      , ('7')
                      , ('54')
                      , ('97')
                      , ('84')
                      , ('1')
                      , ('10')
                      , ('3')
                      , ('81')
                      , ('45')
                      , ('42')
                      , ('86')
                      , ('89')
                      , ('103')
                      , ('104')
                      , ('13')
                      , ('31')
                      , ('100')
                      , ('99')
                      , ('2')
                      , ('44')
                      , ('47')
                      , ('72')
                      , ('75')
                      , ('26')
                      , ('12')
                      , ('28')
                      , ('52')
                      , ('64')
                      , ('19')
                      , ('109')
                      , ('83')
                      , ('108')
                      , ('110')
                      , ('70')
                      , ('76')
                      , ('80')
                      , ('35')
                      , ('78')
                      , ('96')
                      , ('105')
                      , ('91')
                      , ('85')
                      , ('92')
                      , ('93')
                      , ('41')
                      , ('59')
                      , ('61')
                      , ('63')
                      , ('65')
                      , ('66')
                      , ('68')
                      , ('62')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Object                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Object`
                     ( `Object` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Object` (`Object` )
                VALUES ('Obj739920')
                      , ('Obj930023')
                      , ('Obj456188')
                      , ('Obj484188')
                      , ('Obj786188')
                      , ('Obj989657')
                      , ('Obj954751')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaakstuktype                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Zaakstuktype`
                     ( `Zaakstuktype` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaakstuktype` (`Zaakstuktype` )
                VALUES ('Proces Verbaal')
                      , ('Dagvaarding')
                      , ('Verzoek tot inschrijving als advocaat')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Dossier                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Dossier`
                     ( `Dossier` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Dossier` (`Dossier` )
                VALUES ('Dossier 10/569423')
                      , ('Dossier 11/123458')
                      , ('Dossier 11/489631')
                      , ('Dossier 08/476197')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Nationaliteit1                  *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Nationaliteit1`
                     ( `Nationaliteit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Nationaliteit1` (`Nationaliteit` )
                VALUES ('Nederlandse')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug nationaliteit2                    *
    *                                        *
    * fields:                                *
    * I/\nationaliteit;nationaliteit~  [ASY] *
    * nationaliteit  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `nationaliteit2`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Nationaliteit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `nationaliteit2` (`NatuurlijkPersoon` ,`Nationaliteit` )
                VALUES ('1', 'Nederlandse')
                      , ('6', 'Nederlandse')
                      , ('2', 'Nederlandse')
                      , ('3', 'Nederlandse')
                      , ('4', 'Nederlandse')
                      , ('5', 'Nederlandse')
                      , ('7', 'Nederlandse')
                      , ('8', 'Nederlandse')
                      , ('9', 'Nederlandse')
                      , ('10', 'Nederlandse')
                      , ('11', 'Nederlandse')
                      , ('12', 'Nederlandse')
                      , ('13', 'Nederlandse')
                      , ('14', 'Nederlandse')
                      , ('15', 'Nederlandse')
                      , ('16', 'Nederlandse')
                      , ('17', 'Nederlandse')
                      , ('18', 'Nederlandse')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Geslacht                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Geslacht`
                     ( `Geslacht` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Geslacht` (`Geslacht` )
                VALUES ('Man')
                      , ('Vrouw')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Land                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Land`
                     ( `Land` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Land` (`Land` )
                VALUES ('Nederland')
                      , ('Zweden')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Titel                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Titel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Titel` (`Titel` )
                VALUES ('Baron')
                      , ('mr')
                      , ('drs')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug BurgerServiceNummer             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `BurgerServiceNummer`
                     ( `BurgerServiceNummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `BurgerServiceNummer` (`BurgerServiceNummer` )
                VALUES ('23587435')
                      , ('56327491')
                      , ('78954566')
                      , ('14676455')
                      , ('58974564')
                      , ('15876456')
                      , ('45896541')
                      , ('56975633')
                      , ('62096541')
                      , ('45031741')
                      , ('72896694')
                      , ('63254896')
                      , ('45896310')
                      , ('35497763')
                      , ('79823438')
                      , ('46936557')
                      , ('49876337')
                      , ('78974651')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Geslachtsnaam                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Geslachtsnaam`
                     ( `Geslachtsnaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Geslachtsnaam` (`Geslachtsnaam` )
                VALUES ('Jansen')
                      , ('Pietersen')
                      , ('Sigursson')
                      , ('Levelt')
                      , ('van Driel')
                      , ('Dekkers')
                      , ('Cox')
                      , ('Guillaume')
                      , ('van de Meene')
                      , ('Wiltschut')
                      , ('Dijkstra')
                      , ('Audeur')
                      , ('Stolen')
                      , ('Elicht')
                      , ('Eul')
                      , ('Sjesdief')
                      , ('Angereden')
                      , ('Verhoeven')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Voornamen                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Voornamen`
                     ( `Voornamen` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Voornamen` (`Voornamen` )
                VALUES ('Peter')
                      , ('Eman')
                      , ('Ola')
                      , ('Sebastiaan')
                      , ('Ilja')
                      , ('Anne')
                      , ('Lonneke')
                      , ('Sascha')
                      , ('Hendrik Pieter Cornelis')
                      , ('Sandra Anne')
                      , ('Roeland Petrus')
                      , ('Frits')
                      , ('Bert')
                      , ('Olaf')
                      , ('Barend')
                      , ('Tomas')
                      , ('Andre')
                      , ('Sanne')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Ressort                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Ressort`
                     ( `Ressort` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Ressort` (`Ressort` )
                VALUES ('Amsterdam')
                      , ('Arnhem')
                      , ('Leeuwarden')
                      , ('\'s-Gravenhage')
                      , ('\'s-Hertogenbosch')
                      , ('Den Bosch')
                      , ('Den Haag')
                      , ('Arnhem-Leeuwarden')
                      , ('s-Hertogenbosch')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Rechternaam                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Rechternaam`
                     ( `Rechternaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Rechternaam` (`Rechternaam` )
                VALUES ('mr. T.M.A. van Löben Sels')
                      , ('mr. G.M.P. Brouns')
                      , ('mr. N.M. van Waterschoot')
                      , ('mr. J.H.B. van der Meer')
                      , ('mr. Ph.Q. van Otterloo-Pannerden')
                      , ('mr. H.P. Kijlstra')
                      , ('mr. A.M. Rikken')
                      , ('mr. B.M. Hoek')
                      , ('mr. J.A.A.M. van Veen')
                      , ('mr. H.J.Deuring')
                      , ('mr. J. Hielkema')
                      , ('mr. E.M. Dil-Stork')
                      , ('mr. G. Harten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaal                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Zaal`
                     ( `Zaal` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaal` (`Zaal` )
                VALUES ('Zaal 1')
                      , ('Zaal 2')
                      , ('Zaal 3')
                      , ('Zaal 4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Appointeringsvoorstel1          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Appointeringsvoorstel1`
                     ( `Appointeringsvoorstel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************************\
    * Plug appointeringsvoorstel2                            *
    *                                                        *
    * fields:                                                *
    * I/\appointeringsvoorstel;appointeringsvoorstel~  [ASY] *
    * appointeringsvoorstel  []                              *
    \********************************************************/
    mysql_query("CREATE TABLE `appointeringsvoorstel2`
                     ( `Appointeringsvoorstel` VARCHAR(255) DEFAULT NULL
                     , `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Termijndatum                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Termijndatum`
                     ( `Termijndatum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Termijndatum` (`Termijndatum` )
                VALUES ('20-03-2012')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Eis                             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Eis`
                     ( `Eis` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Advocaat                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Advocaat`
                     ( `Advocaat` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Advocaat` (`Advocaat` )
                VALUES ('mr. S. Levelt')
                      , ('mr. L.L.A. Cox')
                      , ('mr. A. Dekkers')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kantoordeurwaarder              *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Kantoordeurwaarder`
                     ( `Kantoordeurwaarder` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kantoordeurwaarder` (`Kantoordeurwaarder` )
                VALUES ('H.J. Jansen BV')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Aantal                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Aantal`
                     ( `Aantal` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Aantal` (`Aantal` )
                VALUES ('5')
                      , ('2')
                      , ('6')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Tekst                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Tekst`
                     ( `Tekst` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Tekst` (`Tekst` )
                VALUES ('Zware mishandeling met voorbedachte rade')
                      , ('Valsmunterij')
                      , ('Ik ben het oneens met de beslissing genomen door de Gemeente Utrecht omtrent het verlenen van kapvergunning XXXX.')
                      , ('Ik ben het oneens met de beslissing genomen door het UWV omtrent het uitstellen van mijn WW-uitkering.')
                      , ('Ik ben het oneens met de beslissing tot ongegrondverklaring van het eerder ingediende bezwaarschrift met kenmerk XXXX.')
                      , ('Art. XX lid Y Wm')
                      , ('Art. XX IWfsv')
                      , ('Art. WVW1994')
                      , ('Het voorbereiden, mede-vaststellen, evalueren en coördineren van het strategische en het operationele beleid met betrekking tot (elementen van) de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke organisatie')
                      , ('Het (periodiek) doorlichten, op basis van enquêtes of anderszins verzameld statistisch materiaal, van het functioneren van de (administratieve diensten van) de gerechten')
                      , ('Het adviseren en ondersteunen van de hoofden van dienst van (de administratieve diensten bij) de gerechten inzake de uitvoering van de onderdelen van het beleid waarmee zij zijn belast en het ondersteunen van de Rechterlijke Organisaties bij de implementatie van beleid inzake de bedrijfsvoering')
                      , ('Het opstellen van periodieke verslagen omtrent ontwikkelingen met betrekking tot de organisatie van de rechtspleging en de (uitvoering van) bedrijfsvoering van de rechterlijke macht')
                      , ('Het beantwoorden van Kamervragen en het anderszins informeren van leden van of commissies uit de Kamers der Staten-Generaal inzake aangelegenheden met betrekking tot de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht')
                      , ('Het beantwoorden van vragen van individuele burgers, bedrijven en instellingen met betrekking tot de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht')
                      , ('Het ontwikkelen en verspreiden van voorlichtingsmateriaal met betrekking tot de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht')
                      , ('Het instellen van commissies of raden en het vaststellen van hun taken betreffende de bedrijfsvoering van de rechterlijke macht en op het terrein van de rechterlijke organisatie')
                      , ('Het benoemen van de leden van commissies of raden op het terrein van de (advisering over het beleid en wet- en regelgeving betreffende de) rechterlijke organisatie en de bedrijfsvoering van de rechterlijke macht en het voorzien in administratieve ondersteuning en financieel beheer')
                      , ('Het administratief ondersteunen en/of financieel beheren van instellingen die actief zijn op het gebied van de organisatie van de rechtspleging')
                      , ('Het voorbereiden van de totstandkoming, wijziging of intrekking van wet- en regelgeving met betrekking tot de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke organisatie')
                      , ('Het voorbereiden van de totstandkoming, wijziging of intrekking van administratieve en organisatorische (uitvoerings)voorschriften en richtlijnen met betrekking tot de organisatie van de rechtspleging')
                      , ('Het behandelen van bezwaar- en beroepschriften naar aanleiding van beschikkingen met betrekking tot de organisatie van de rechtspleging alsmede het voeren van verweer voor rechterlijke instanties in beroepsprocedures ter zake')
                      , ('Het geven van voorlichting en advies omtrent de juridische interpretatie en toepassing van wet- en regelgeving met betrekking tot de organisatie van de rechtspleging')
                      , ('Het adviseren van de regering, de Staten-Generaal en de rechtspraak in andere landen betreffende het beleidsterrein rechtspleging')
                      , ('Het (jaarlijks) vaststellen van de kwantitatieve en kwalitatieve (rechtsgeleerde) personeelsformatie bij de burgerlijke gerechten')
                      , ('Het systematisch vastleggen van de personeelsgegevens met betrekking tot de burgerlijke gerechten')
                      , ('Het voorbereiden van de KB\'s met betrekking tot de personele bezetting van de zittende magistratuur')
                      , ('Het voorbereiden van de KB\'s met betrekking tot de personele bezetting van posten in rechterlijke colleges, bestemd voor niet tot de rechterlijke macht behorende deskundigen')
                      , ('Het nemen van besluiten met betrekking tot de verdere personele bezetting van de zittende magistratuur')
                      , ('Het voorbereiden van de KB\'s met betrekking tot de personele bezetting van het Openbaar Ministerie')
                      , ('Het nemen van besluiten met betrekking tot de verdere personele bezetting van het Openbaar Ministerie')
                      , ('Het voorbereiden van de KB\'s met betrekking tot de rechtsgeleerde personele bezetting van de griffies van de burgerlijke gerechten')
                      , ('Het nemen van besluiten met betrekking tot de rechtsgeleerde personele bezetting van de griffies van de burgerlijke gerechten')
                      , ('Het nemen van besluiten met betrekking tot de personele bezetting van de administratieve diensten van (de griffies van) de burgerlijke gerechten')
                      , ('Het ontwikkelen van plannen en programma\'s betreffende de werving, selectie en opleiding van personen met het oog de vervulling van functies in de magistratuur of kaderfuncties in de administratieve diensten bij de gerechten')
                      , ('Het ontwikkelen van plannen en programma\'s betreffende de werving, selectie en opleiding van personen met het oog de vervulling van lagere functies in de administratieve diensten bij de gerechten')
                      , ('Het (doen) organiseren van voorlichtingsbijeenkomsten en wervingsacties gericht op (juridische) studenten, alsmede het (doen) geven van voorlichting op scholen en aan individuele gegadigden over een loopbaan of beroep bij de burgerlijke gerechten')
                      , ('Het besluiten omtrent toelating van personen tot opleidingen voor het vervullen van een functie in de magistratuur of kaderfuncties in de administratieve diensten bij de gerechten')
                      , ('Het plaatsen van stagiaire(s) en het aanstellen (in tijdelijke, resp. vaste dienst) van personen in opleiding voor het vervullen van een functie in de magistratuur of kaderfunctie in de administratieve diensten bij de gerechten')
                      , ('Het (doen) beoordelen (door tentamens, examens, ambtsberichten, etc.) van personen in opleiding voor het vervullen van een functie in de magistratuur of kaderfunctie in de administratieve diensten bij de gerechten en het eventueel besluiten tot tussentijdse beëindiging')
                      , ('Het besluiten omtrent dispensatieverzoeken, programmawijzigingen en rechtspositionele aangelegenheden met betrekking tot stagiaire(s) en (overige) personen in opleiding voor het vervullen van een functie in de magistratuur of kaderfunctie in de administratieve diensten bij de gerechten')
                      , ('Het besluiten of personen hun opleiding voor het vervullen van een functie in de magistratuur of kaderfunctie in de administratieve diensten bij de gerechten met goed gevolg hebben voltooid')
                      , ('Het instellen en medebesturen van de Stichting opleiding rechterlijke ambtenaren')
                      , ('Het al dan niet accorderen van besluiten van de Stichting opleiding rechterlijke ambtenaren inzake het opleidingsreglement en de samenstelling van het personele kader van de opleiding')
                      , ('Het uitvoeren van de praktische organisatie van opleidingen voor functies bij de burgerlijke gerechten')
                      , ('Het verzorgen van cursussen, studie- en vormingsbijeenkomsten in het kader van opleidingen tot griffier en kaderfuncties bij de administratieve diensten van de burgerlijke gerechten')
                      , ('Het voorbereiden van de KB\'s waarbij wordt uitgemaakt of een bepaalde openbare nevenfunctie toelaatbaar is voor een voor het leven benoemde rechterlijke ambtenaar')
                      , ('Het doen van voorstellen in verband met de toekenning van koninklijke onderscheidingen aan rechterlijke ambtenaren')
                      , ('Het voorbereiden van de KB\'s ter goedkeuring van (wijzigingen van) de reglementen van de gerechten')
                      , ('Het bevorderen van de unificatie van formulieren, registers, handleidingen en overige administratieve bescheiden van (de administratieve diensten bij) de gerechten')
                      , ('Het ontwerpen en doorvoeren van (nieuwe) taakverdelingspatronen, werkprocedures en -methoden, alsmede administratievormen bij de griffies en parketten')
                      , ('Het toezien op de naleving van voorschriften en de administratieve gang van zaken bij de griffies van en de parketten bij de gerechten')
                      , ('Het vaststellen en verdelen van het rechtsgebied en de zetels der Rechterlijke Organisaties')
                      , ('Het vormen van enkelvoudige en meervoudige kamers voor het behandelen en beslissen van zaken')
                      , ('Het verdelen van de behandeling van rechtzaken over hoofd-, nevenvestiging- en nevenzittingsplaatsen')
                      , ('Het houden van bijzondere zittingen')
                      , ('Het (inzake de aard of anderszins) overdragen van rechtzaken aan andere gerechten')
                      , ('Het (laten) onderhouden en beheren van gegevensbestanden met betrekking tot het behandelen en beslissen van rechtszaken')
                      , ('Het ontwikkelen van systemen en procedures met betrekking tot het financieel-economisch beheer van de rechterlijke organisatie')
                      , ('Het ramen van de begrotingsgelden voor de onderscheidene soorten kosten van de rechterlijke organisatie en het daaruit samenstellen van een begroting voor de gehele sector')
                      , ('Het (al dan niet) toewijzen van kredieten en voorschotten aan de rekenplichtigen voor de (administratieve diensten bij) de gerechten')
                      , ('Het toepassen van de voorschriften inzake gerechtskosten in straf- en burgerlijke zaken en overige sectorspecifieke financiële regelingen')
                      , ('Het toezien op de besteding van de bij begroting toegewezen bedragen aan (de administratieve diensten bij) de gerechten en uitvoering van de formatie- en begrotingsbewaking')
                      , ('Het door middel van een planning- en controlesystematiek uitvoeren van het financieel-economisch beheer van de rechterlijke organisatie')
                      , ('Het toezien op het beheer en de overbrenging van de gerechtelijke en de burgerlijke stand-archieven, alsmede het zorgen voor de eventuele vervanging en de beveiliging van de burgerlijke stand-archieven')
                      , ('Het (her)inrichten van gerechtsgebouwen')
                      , ('Het (doen) uitvoeren van de verhuizing van gerechten en hun administratieve diensten')
                      , ('Het treffen van materiële voorzieningen betreffende de huishoudelijke en de administratieve diensten der gerechten')
                      , ('Het zorgdragen voor de bewaking en het schoonhouden van de gerechtsgebouwen')
                      , ('Het zorgdragen voor de bedrijfsvoering van de kantines in de gerechtsgebouwen')
                      , ('Het ontwikkelen, vaststellen en wijzigen van een klachtenregeling betreffende de bedrijfsvoering van de rechterlijke organisatie')
                      , ('Het behandelen van klachten van burgers over hun behandeling tijdens rechtszaken')
                      , ('Het vaststellen van een opdracht en resultaat van onderzoek naar het beleid en de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht')
                      , ('Het (mede-)voorbereiden en begeleiden van (wetenschappelijke) studies en onderzoeken met betrekking tot de organisatie van de rechtspleging')
                      , ('Het verzamelen en bewerken van gegevens ten behoeve van (wetenschappelijk) onderzoek betreffende de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht')
                      , ('Het financieren van (wetenschappelijk) onderzoek betreffende de organisatie van de rechtspleging en de bedrijfsvoering van de rechterlijke macht')
                      , ('Het (doen) uitvoeren van onderzoeken betreffende efficiëntie, effectiviteit en kwaliteit van de eigen bedrijfsvoering')
                      , ('Het deelnemen aan advies- of overlegcommissies en werkgroepen inzake de bedrijfsvoering van de rechterlijke macht waarvan het secretariaat bij het ministerie berust')
                      , ('Het deelnemen aan advies- of overlegcommissies en werkgroepen inzake de bedrijfsvoering van de rechterlijke macht waarvan het secretariaat niet bij het ministerie berust')
                      , ('Het (adviseren inzake) voorbereiden, vaststellen en evalueren van het beleid betreffende de bedrijfsvoering van de rechterlijke organisatie')
                      , ('Het adviseren over (verbetering van) de wijze waarop recht wordt toegepast')
                      , ('Het adviseren van de minister van Justitie betreffende het beleidsterrein rechtspleging')
                      , ('Het inplannen van bijzondere zittingen')
                      , ('Het opstellen van verslagen betreffende het beleid inzake de bedrijfsvoering van de rechterlijke macht en de uitvoering daarvan')
                      , ('Het beantwoorden van vragen van individuele burgers, bedrijven en instellingen betreffende de bedrijfsvoering van de rechterlijke macht')
                      , ('Het uitvoeren van voorlichtingsactiviteiten op het terrein van de bedrijfsvoering van de rechterlijke macht (brochures, artikelen, films, enz.)')
                      , ('Het vaststellen van de opdracht en het eindproduct van een intern of extern (wetenschappelijk) onderzoek betreffende de bedrijfsvoering van de rechterlijke macht')
                      , ('Het (laten) uitvoeren van onderzoeken naar de kwaliteit van de rechterlijke organisatie, het rechterlijke functioneren en uniforme rechtstoepassing')
                      , ('Het (doen) uitvoeren van onderzoeken betreffende de efficiëntie, effectiviteit en kwaliteit van de eigen bedrijfsvoering')
                      , ('Het deelnemen aan advies- of overlegcommissies en werkgroepen inzake de bedrijfsvoering van de rechterlijke macht waarvan het secretariaat bij de eigen organisatie berust')
                      , ('Het deelnemen aan advies- of overlegcommissies en werkgroepen inzake de bedrijfsvoering van de rechterlijke macht waarvan het secretariaat niet bij de eigen organisatie berust')
                      , ('Het adviseren van de Minister van Justitie inzake de rechterlijke organisatie')
                      , ('Organisatiebesluiten ministerie van Justitie; Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)')
                      , ('Organisatiebesluiten ministerie van Justitie')
                      , ('Organisatiebesluiten ministerie van Justitie, Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)')
                      , ('Organisatiebesluiten ministerie van Justitie.')
                      , ('Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555, art. 17 e.v.: RAIO-selectiecommissie); RIO Bijlage 4: deze betreft echter veel ambtelijke of gemengde commissies en werkgroepen, die hier niet zijn bedoeld).')
                      , ('Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555, art. 17 e.v.: RAIO-selectiecommissie)')
                      , ('Organisatiebesluiten ministerie van Justitie. Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)')
                      , ('Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)')
                      , ('Wet RO, passim; organisatiebesluiten ministerie van Justitie. Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet Bestuursrechtspraak Bedrijfsorganisatie (1954-) (Stb. 1954, 416), Beroepswet (1955-) (Stb. 1955, 47), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463), Wet op de Raad van State (Stb. 1994, 2), Wet voltooiing 1e fase Herziening Rechterlijke Organisatie (Stb. 1993, 650)')
                      , ('Wet RO, art. 72 en 73; organisatiebesluiten ministerie van Justitie')
                      , ('Wet RO passim; organisatiebesluiten ministerie van Justitie')
                      , ('Organisatiebesluiten ministerie van justitie')
                      , ('Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555).')
                      , ('Wet- en regelgeving (bijv. Besluit opleiding rechterlijke ambtenaren, Stb. 1985, 555); organisatiebesluiten ministerie van Justitie')
                      , ('Wet- en regelgeving (bijv. Besluit opleiding verkeersschouten, Stb. 1974, 44).')
                      , ('Wet- en regelgeving (bijv. Opleidingsreglement verkeersschouten, Stcrt. 1974, 249).')
                      , ('Besluit opleiding rechterlijke ambtenaren (Stb. 1985, 555) art. 9 en 10')
                      , ('Besluit opleiding rechterlijke ambtenaren (Stb. 1985, 555) art. 11 en 12.')
                      , ('Wet RO art. 8, lid 3.')
                      , ('Reglement I (Stb. 1838, 36), zoals sindsdien gewijzigd.')
                      , ('Wet op de Zamenstelling der Rechterlijke Magt en het Beleid der Justitie (1838-1972) (Stb. 1827, 20), Wet Bestuursrechtspraak Bedrijfsorganisatie (1954-) (Stb. 1954, 416), Beroepswet (1955-) (Stb. 1955, 47), Wet op de Rechterlijke Organisatie (1972-) (Stb. 1972, 463)')
                      , ('De handeling betreft de vormgeving op lange en middellange termijn van enerzijds de beheersmatige inbedding van de RO (apparaatszorg) en anderzijds de inwendige structuur van de RO (bijv. territoriale indeling, werkwijzen, formatie). De handeling omvat zowel de algemene beleidsontwikkeling als het beleid ten aanzien van specifieke elementen (bijv. materieel beheer, automatisering, personeelszaken) dat binnen het algemene kader wordt ontwikkeld.')
                      , ('De neerslag van de handeling wordt veelal verwerkt in (periodieke) verslagen. Zie handeling 6.')
                      , ('Betreft bijv. kwesties van algemeen management, maar ook specifieke aangelegenheden, zoals inrichting en beheer van gerechtsbibliotheken, de automatisering, personeelsbeleid. Deze handeling kan geschieden in het kader van projecten. Betreft ook coördinatie, afstemming en advisering inzake het bewaken en verbeteren van de kwaliteit, uniformiteit en het doelmatig functioneren van de rechterlijke macht als geheel.')
                      , ('De handeling betreft veelal (deels) een presentatie en analyse van verzamelde statistieken, uitkomsten van gehouden enquêtes of managementrapportages (zie handeling 4).')
                      , ('Betreft bijv. ook het informeren van de Commissies voor de Verzoekschriften en andere tot het onderzoeken van klachten bevoegde commissies uit de Kamers der Staten-Generaal.')
                      , ('Betreft bijv. het Studiecentrum Rechtspleging.')
                      , ('Voor een overzicht van wetten zie RIO, Bijlage 3. De handeling betreft voorts de daarop gebaseerde amvb\'s en ministeriële regelingen.')
                      , ('De handeling betreft voorschriften en richtlijnen betreffende de administratieve organisatie, het materiële beheer, de werving en selectie van personeel, het archiefbeheer, etc.')
                      , ('Onder andere in landelijk overleg')
                      , ('Betreft adviezen over: het te voeren beleid, voornamelijk inzake strategie en toekomstvisie; wet- en regelgeving inzake de rechtspraak; wet- en regelgeving die niet direct gerelateerd is aan de rechtspraak, maar waarvan de uitvoering wel gevolgen heeft voor de rechtspraak. Wat betreft de (vertegenwoordigers van) de rechtspraak in andere landen betreft het naast de overzeese gebiedsdelen en Suriname ook bijvoorbeeld het -op verzoek van de EU- adviseren van andere landen')
                      , ('Betreft benoeming, ontslagverlening, onbetaald buitengewoon verlof, deeltijdaanstelling, etc. Tot de zittende magistratuur behoren naast de rechtsprekende rechterlijke ambtenaren ook de (senior)gerechtsauditeurs in vaste dienst. Bijvoorbeeld: de leden van enkelvoudige en meervoudige kamers voor het behandelen en beslissen van bestuurs-, civiel- en strafrechtelijke zaken, de belasting- , ondernemings- , grond- en pachtkamers, de kamer voor het kwekersrecht etc., de verkeersschouten en hun vervangers. Hieronder vallen ook de Hoge Raad, de Colleges van Beroep, de Centrale Raad van Beroep en de Raad van State.')
                      , ('Betreft benoeming, herbenoeming, ontslag, etc. van de deskundigen die als (plaatsvervangende) raden zitting hebben in de ondernemingskamer van het gerechtshof te Amsterdam en de bijzondere kamer van het gerechtshof te Arnhem.')
                      , ('Betreft benoeming, ontslag, etc. van gerechtsauditeurs in tijdelijke dienst, alsmede de aanwijzing van magistraten in waarnemende functies.')
                      , ('Betreft benoeming, ontslagverlening, onbetaald buitengewoon verlof, deeltijdaanstelling, aanstelling in buitengewone dienst, etc.')
                      , ('Betreft benoeming, ontslag, etc. van plaatsvervangende officieren van justitie en parketsecretarissen, alsmede de aanwijzing van leden van het OM in waarnemende functies.')
                      , ('Betreft benoeming, ontslag, etc. van griffiers en substituut-griffiers.')
                      , ('Betreft benoeming, ontslag, etc. van waarnemend griffiers en gerechtssecretarissen')
                      , ('De handeling betreft dispensatieverzoeken')
                      , ('De stichting is het instituut voor de RAIO-opleiding en wordt door Justitie gefinancierd. Het bestuur bestaat grotendeels uit personen aangewezen door de Nederlandse Vereniging voor Rechtspraak.')
                      , ('Zie opsomming van activiteiten bij RIO handeling nr. 100')
                      , ('Deze handeling geschiedt alleen in bijzondere twijfelgevallen.')
                      , ('De handeling betreft in voorkomende gevallen mede het beslissen inzake de werkwijze van gerechten als bedoeld in art. 63a, 63b en 73 van Reglement I.')
                      , ('Bijvoorbeeld: in arrondissementen en kantons.')
                      , ('Onder andere bestuurs-, civiel- en strafrechterlijke zaken of zaken aangaande belasting')
                      , ('Betreft reguliere werkverdeling binnen een arrondissement.')
                      , ('Onder andere het inplannen van de zittingen. Voor de behandeling van een bepaalde zaak kan, in verband met omstandigheden, afgeweken worden van de in het reglement opgenomen dagen, tijdstippen en plaatsen.')
                      , ('Een zaak kan worden overgedragen wanneer er sprake zou kunnen zijn van (schijn van) belangenverstrengeling. Ook bij megastrafzaken die naar verwachting 30 uur of meer in beslag nemen, kan een afwijkende zittingsplaats worden aangewezen. De Minister van Justitie kan, na overleg met het gerechtsbestuur besluiten om een rechtszaak op een andere locatie plaats te laten vinden in verband met veiligheidsoverwegingen. Handeling is niet van toepassing op de CRvB.')
                      , ('Betreft bijv. de planning- & controlsystematiek.')
                      , ('Betreft mede de financieel-economische onderbouwing van beleidsplannen en -voornemens')
                      , ('Betreft mede het aangeven van compensatievoorstellen bij dreigende overschrijding van de sectorale begroting.')
                      , ('Deze handeling geschiedt in samenwerking met de Rijks Gebouwen Dienst')
                      , ('Betreft het afsluiten van contracten en toezicht op de naleving daarvan')
                      , ('Betreft alle klachten die niet rechtstreeks betrekking hebben op een zaak, bijvoorbeeld klachten tegen bejegening door gerechtsambtenaren, niet tijdig beantwoorden van brieven, etc.')
                      , ('Het kan hierbij gaan om juridische studies, organisatie-onderzoeken, financieel-economische analyses, arbeidsmarktonderzoek, etc. vanuit een bijzondere vraagstelling. De vraag kan betrekking hebben op het rechterlijke functioneren, uniforme rechtstoepassing en (de kwaliteit van) de organisatie van de rechtspleging in het algemeen, of op een afzonderlijk element (informatievoorziening, beveiliging, loopbaanontwikkeling, etc.). Voor (periodieke) enquêtes en statistieken betreffende het functioneren van de gerechten en hun diensten zie handeling 4')
                      , ('Betreft adviezen over: het te voeren beleid, voornamelijk inzake strategie en toekomstvisie; wet- en regelgeving inzake de rechtspraak; wet- en regelgeving die niet direct gerelateerd is aan de rechtspraak, maar waarvan de uitvoering wel gevolgen heeft voor de rechtspraak.')
                      , ('Onder andere bestuurs-, civiel- en strafrechtelijke zaken of zaken aangaande belasting')
                      , ('Betreft reguliere werkverdeling binnen een arrondissement')
                      , ('Voor de behandeling van een bepaalde zaak kan, in verband met omstandigheden, afgeweken worden van de in het reglement opgenomen dagen, tijdstippen en plaatsen')
                      , ('Betreft alle klachten die niet rechtstreeks betrekking hebben op een zaak, bijv. klachten tegen bejegening door gerechtsambtenaren, niet tijdig beantwoorden van brieven, etc.')
                      , ('Notities, nota\'s, rapporten, evaluaties')
                      , ('(Jaar)verslag')
                      , ('Brochures, artikelen, films, enz.')
                      , ('Notities, nota\'s, rapporten, wetten, regelingen, reglementen')
                      , ('Koninklijk Besluit, benoeming')
                      , ('Offerte, brief, rapport, contract')
                      , ('Notitie, notulen, brief')
                      , ('Rekening, declaratie')
                      , ('Handelingen die betrekking hebben op voorbereiding en bepaling van beleid op hoofdlijnen')
                      , ('Handelingen die betrekking hebben op evaluatie van beleid op hoofdlijnen')
                      , ('Handelingen die betrekking hebben op verantwoording van beleid op hoofdlijnen aan andere actoren')
                      , ('Handelingen die betrekking hebben op (her)inrichting van organisaties belast met beleid op hoofdlijnen')
                      , ('Handelingen die bepalend zijn voor de wijze waarop beleidsuitvoering op hoofdlijnen plaatsvindt')
                      , ('Handelingen die betrekking hebben op beleidsuitvoering op hoofdlijnen en direct zijn gerelateerd aan of direct voortvloeien uit voor het Koninkrijk der Nederlanden bijzondere tijdsomstandigheden en incidenten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Artikel                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Artikel`
                     ( `Artikel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Artikel` (`Artikel` )
                VALUES ('Art. 315 Sr')
                      , ('Art. 208 Sr')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Tijdstip1                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Tijdstip1`
                     ( `Tijdstip` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Tijdstip1` (`Tijdstip` )
                VALUES ('18:15')
                      , ('15:00')
                      , ('15:15')
                      , ('09:10')
                      , ('16:00')
                      , ('13:00')
                      , ('14:15')
                      , ('12:13')
                      , ('16:33')
                      , ('15:30')
                      , ('17:02')
                      , ('10:15')
                      , ('17:33')
                      , ('17:17')
                      , ('10:30')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug tijdstip2               *
    *                              *
    * fields:                      *
    * I/\tijdstip;tijdstip~  [ASY] *
    * tijdstip  []                 *
    \******************************/
    mysql_query("CREATE TABLE `tijdstip2`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Tijdstip` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Feit1                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Feit1`
                     ( `Feit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Feit1` (`Feit` )
                VALUES ('Feit 1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************\
    * Plug feit2           *
    *                      *
    * fields:              *
    * I/\feit;feit~  [ASY] *
    * feit  []             *
    \**********************/
    mysql_query("CREATE TABLE `feit2`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Feit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `feit2` (`Dagvaarding` ,`Feit` )
                VALUES ('Dagvaarding 1', 'Feit 1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Rechter1                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Rechter1`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Rechter1` (`Rechter` )
                VALUES ('Rechter 9')
                      , ('Rechter 12')
                      , ('Rechter 7')
                      , ('Rechter 1')
                      , ('Rechter 10')
                      , ('Rechter 2')
                      , ('Rechter 3')
                      , ('Rechter 4')
                      , ('Rechter 5')
                      , ('Rechter 6')
                      , ('Rechter 8')
                      , ('Rechter 11')
                      , ('Rechter 13')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************\
    * Plug rechter2              *
    *                            *
    * fields:                    *
    * I/\rechter;rechter~  [ASY] *
    * rechter  []                *
    \****************************/
    mysql_query("CREATE TABLE `rechter2`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                     , `Kamerid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `rechter2` (`Rechter` ,`Kamerid` )
                VALUES ('Rechter 9', 'Kamer 1')
                      , ('Rechter 10', 'Kamer 1')
                      , ('Rechter 12', 'Kamer 2')
                      , ('Rechter 7', 'Kamer 3')
                      , ('Rechter 13', 'Kamer 4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Partij                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Partij`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Partij` (`Partij` )
                VALUES ('Partij 1')
                      , ('Partij 2')
                      , ('Partij 3')
                      , ('Partij 7')
                      , ('Partij 8')
                      , ('Partij 4')
                      , ('Partij 5')
                      , ('Partij 6')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Samenstelling1                  *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Samenstelling1`
                     ( `Samenstelling` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Samenstelling1` (`Samenstelling` )
                VALUES ('Enkelvoudig')
                      , ('Meervoudig')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug samenstelling2                    *
    *                                        *
    * fields:                                *
    * I/\samenstelling;samenstelling~  [ASY] *
    * samenstelling  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `samenstelling2`
                     ( `Kamerid` VARCHAR(255) DEFAULT NULL
                     , `Samenstelling` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `samenstelling2` (`Kamerid` ,`Samenstelling` )
                VALUES ('Kamer 1', 'Enkelvoudig')
                      , ('Kamer 2', 'Enkelvoudig')
                      , ('Kamer 3', 'Enkelvoudig')
                      , ('Kamer 4', 'Meervoudig')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kamerid                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Kamerid`
                     ( `Kamerid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kamerid` (`Kamerid` )
                VALUES ('Kamer 1')
                      , ('Kamer 2')
                      , ('Kamer 3')
                      , ('Kamer 4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Griffierechtbetaald1            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Griffierechtbetaald1`
                     ( `Griffierechtbetaald` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Griffierechtbetaald1` (`Griffierechtbetaald` )
                VALUES ('voldaan')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug griffierechtbetaald2                          *
    *                                                    *
    * fields:                                            *
    * I/\griffierechtbetaald;griffierechtbetaald~  [ASY] *
    * griffierechtbetaald  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `griffierechtbetaald2`
                     ( `Zaakid` VARCHAR(255) DEFAULT NULL
                     , `Griffierechtbetaald` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `griffierechtbetaald2` (`Zaakid` ,`Griffierechtbetaald` )
                VALUES ('Zaak 4', 'voldaan')
                      , ('Zaak 5', 'voldaan')
                      , ('Zaak 6', 'voldaan')
                      , ('Zaak 7', 'voldaan')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaaktype                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Zaaktype`
                     ( `Zaaktype` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaaktype` (`Zaaktype` )
                VALUES ('Kort geding')
                      , ('Eerste aanleg')
                      , ('Cassatie')
                      , ('Hoger beroep')
                      , ('Beroep')
                      , ('Vovo')
                      , ('Bodemprocedure')
                      , ('Dagvaarding exploot')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Sector                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Sector`
                     ( `Sector` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gerecht                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Gerecht`
                     ( `Gerecht` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gerecht` (`Gerecht` )
                VALUES ('Rechtbank Leeuwarden')
                      , ('Rechtbank \'s-Gravenhage')
                      , ('Rechtbank Almelo')
                      , ('Rechtbank Haarlem')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Datum1                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Datum1`
                     ( `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Datum1` (`Datum` )
                VALUES ('20-11-2011')
                      , ('07-02-2012')
                      , ('20-02-2012')
                      , ('15-01-2012')
                      , ('03-02-2012')
                      , ('12-03-2012')
                      , ('13-03-2012')
                      , ('03-12-2010')
                      , ('23-05-2011')
                      , ('12-09-2011')
                      , ('15-04-2008')
                      , ('12-10-1967')
                      , ('06-07-1980')
                      , ('31-02-1970')
                      , ('25-03-1962')
                      , ('01-05-1982')
                      , ('16-07-1976')
                      , ('12-11-1981')
                      , ('12-01-1959')
                      , ('25-02-1948')
                      , ('30-12-1955')
                      , ('04-07-1965')
                      , ('25-04-1975')
                      , ('03-05-1980')
                      , ('10-12-1968')
                      , ('27-11-1976')
                      , ('30-06-1984')
                      , ('15-02-1989')
                      , ('26-05-1980')
                      , ('24-05-2011')
                      , ('06-12-2010')
                      , ('23-07-2011')
                      , ('12-12-2010')
                      , ('03-10-2011')
                      , ('25-08-1990')
                      , ('12-02-2009')
                      , ('06-10-2007')
                      , ('18-04-2009')
                      , ('30-05-2011')
                      , ('14-12-2010')
                      , ('26-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************\
    * Plug datum2            *
    *                        *
    * fields:                *
    * I/\datum;datum~  [ASY] *
    * datum  []              *
    \************************/
    mysql_query("CREATE TABLE `datum2`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `datum2` (`Gebeurtenis` ,`Datum` )
                VALUES ('Ev739920', '23-05-2011')
                      , ('Ev930023', '03-12-2010')
                      , ('Ev456188', '12-09-2011')
                      , ('Ev695', '24-05-2011')
                      , ('Ev426', '06-12-2010')
                      , ('Ev336', '12-09-2011')
                      , ('Ev732491', '23-07-2011')
                      , ('Ev993123', '12-12-2010')
                      , ('Ev476228', '03-10-2011')
                      , ('Zitting RbsGr 35', '23-05-2011')
                      , ('Zitting RbLee 591', '03-12-2010')
                      , ('Zitting RbAlm 68', '12-09-2011')
                      , ('Msg598', '24-05-2011')
                      , ('Msg449', '06-12-2010')
                      , ('Msg779', '12-09-2011')
                      , ('Be1', '25-08-1990')
                      , ('Be2', '12-02-2009')
                      , ('Be3', '06-10-2007')
                      , ('Be4', '18-04-2009')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Soort recht                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Soort recht`
                     ( `Soort recht` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Soort recht` (`Soort recht` )
                VALUES ('Geldvordering')
                      , ('Mulder beroep')
                      , ('Strabis verzet')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Systeemcode                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Systeemcode`
                     ( `Systeemcode` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaaknummer                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Zaaknummer`
                     ( `Zaaknummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Volgnummer                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Volgnummer`
                     ( `Volgnummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Jaar                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Jaar`
                     ( `Jaar` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Adres                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Adres`
                     ( `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Adres` (`Adres` )
                VALUES ('Herengracht 425-429, 1017 BR, Amsterdam')
                      , ('Westblaak 5f, 3001 AC, Rotterdam')
                      , ('Mariahoek 4, 3511 LD, Utrecht')
                      , ('Herculesplein 213, 3584 AA, Utrecht')
                      , ('Weldammerbos 17, 7543GW Enschede')
                      , ('Heimerstein 91, 3328MH Dordrecht')
                      , ('Bornsestraat 28, 7556BG Hengelo ov')
                      , ('Zeedijken 42, 9919BM Loppersum')
                      , ('Noordbolwerk 33, 4331SH Middelburg')
                      , ('Westhavenkade 98, 3133AV Vlaardingen')
                      , ('Koornbeursweg 132, 8442DJ Heerenveen')
                      , ('Johannes Verhulststraat 55/HS, 1071MS Amsterdam')
                      , ('Kruisherenstraat 56, 3078GT Rotterdam')
                      , ('Gezichtslaan 52, 3723GG Bilthoven')
                      , ('Kalkhofseweg 25, 5443NB Haps')
                      , ('Erve Kokenberg 1, 7625NH Zenderen')
                      , ('Thorbeckelaan 342, 2564BZ \'s-Gravenhage')
                      , ('Hooizolder 386, 9205CW Drachten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kantoor                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Kantoor`
                     ( `Kantoor` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kantoor` (`Kantoor` )
                VALUES ('Wieringa advocaten')
                      , ('Haulussy advocaten')
                      , ('Kuipers, Jonkers, van den Berg')
                      , ('ATM Advocaten Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijvingsstatus             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijvingsstatus`
                     ( `Inschrijvingsstatus` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijvingsstatus` (`Inschrijvingsstatus` )
                VALUES ('onvoorwaardelijk')
                      , ('voorwaardelijk')
                      , ('geschorst')
                      , ('geschrapt')
                      , ('geregistreerd')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijvingseis                *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijvingseis`
                     ( `Inschrijvingseis` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijvingseis` (`Inschrijvingseis` )
                VALUES ('voldoet')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Strafblad1                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Strafblad1`
                     ( `Strafblad` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Strafblad1` (`Strafblad` )
                VALUES ('Strafblad 1')
                      , ('Strafblad 2')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug strafblad2                *
    *                                *
    * fields:                        *
    * I/\strafblad;strafblad~  [ASY] *
    * strafblad  []                  *
    \********************************/
    mysql_query("CREATE TABLE `strafblad2`
                     ( `Strafblad` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `strafblad2` (`Strafblad` ,`Document` )
                VALUES ('Strafblad 1', 'Strafblad 2684')
                      , ('Strafblad 2', 'Strafblad 8311')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug hoortbij                *
    *                              *
    * fields:                      *
    * I/\hoortbij;hoortbij~  [ASY] *
    * hoortbij  []                 *
    \******************************/
    mysql_query("CREATE TABLE `hoortbij`
                     ( `Strafblad` VARCHAR(255) DEFAULT NULL
                     , `Strafrechtsketennummer` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `hoortbij` (`Strafblad` ,`Strafrechtsketennummer` )
                VALUES ('Strafblad 1', '004995')
                      , ('Strafblad 2', '007487')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug zaakreferentie                      *
    *                                          *
    * fields:                                  *
    * I/\zaakreferentie;zaakreferentie~  [ASY] *
    * zaakreferentie  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `zaakreferentie`
                     ( `sZaak` VARCHAR(255) DEFAULT NULL
                     , `tZaak` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug jaarAanleg                  *
    *                                  *
    * fields:                          *
    * I/\jaarAanleg;jaarAanleg~  [ASY] *
    * jaarAanleg  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `jaarAanleg`
                     ( `Zaak` VARCHAR(255) DEFAULT NULL
                     , `Jaar` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************\
    * Plug gedingdatum                   *
    *                                    *
    * fields:                            *
    * I/\gedingdatum;gedingdatum~  [ASY] *
    * gedingdatum  []                    *
    \************************************/
    mysql_query("CREATE TABLE `gedingdatum`
                     ( `Zaakid` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug behandelendgerecht                          *
    *                                                  *
    * fields:                                          *
    * I/\behandelendgerecht;behandelendgerecht~  [ASY] *
    * behandelendgerecht  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `behandelendgerecht`
                     ( `Zaakid` VARCHAR(255) DEFAULT NULL
                     , `Gerecht` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `behandelendgerecht` (`Zaakid` ,`Gerecht` )
                VALUES ('Zaak 4', 'Rechtbank Leeuwarden')
                      , ('Zaak 5', 'Rechtbank \'s-Gravenhage')
                      , ('Zaak 6', 'Rechtbank Almelo')
                      , ('Zaak 10', 'Rechtbank Haarlem')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug gegevenAan                  *
    *                                  *
    * fields:                          *
    * I/\gegevenAan;gegevenAan~  [ASY] *
    * gegevenAan  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `gegevenAan`
                     ( `Zaak` VARCHAR(255) DEFAULT NULL
                     , `Sector` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************\
    * Plug kamer             *
    *                        *
    * fields:                *
    * I/\kamer;kamer~  [ASY] *
    * kamer  []              *
    \************************/
    mysql_query("CREATE TABLE `kamer`
                     ( `Zaakid` VARCHAR(255) DEFAULT NULL
                     , `Kamerid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `kamer` (`Zaakid` ,`Kamerid` )
                VALUES ('Zaak 4', 'Kamer 1')
                      , ('Zaak 5', 'Kamer 2')
                      , ('Zaak 6', 'Kamer 3')
                      , ('Zaak 10', 'Kamer 4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug ispartij                *
    *                              *
    * fields:                      *
    * I/\ispartij;ispartij~  [ASY] *
    * ispartij  []                 *
    \******************************/
    mysql_query("CREATE TABLE `ispartij`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Partij` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `ispartij` (`NatuurlijkPersoon` ,`Partij` )
                VALUES ('13', 'Partij 1')
                      , ('17', 'Partij 2')
                      , ('14', 'Partij 3')
                      , ('15', 'Partij 4')
                      , ('16', 'Partij 5')
                      , ('12', 'Partij 6')
                      , ('10', 'Partij 7')
                      , ('18', 'Partij 8')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug deskundige                  *
    *                                  *
    * fields:                          *
    * I/\deskundige;deskundige~  [ASY] *
    * deskundige  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `deskundige`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `deskundige` (`NatuurlijkPersoon` ,`Zaakid` )
                VALUES ('18', 'Zaak 4')
                      , ('10', 'Zaak 5')
                      , ('12', 'Zaak 6')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug benadeeld                 *
    *                                *
    * fields:                        *
    * I/\benadeeld;benadeeld~  [ASY] *
    * benadeeld  []                  *
    \********************************/
    mysql_query("CREATE TABLE `benadeeld`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `benadeeld` (`Partij` ,`Zaakid` )
                VALUES ('Partij 1', 'Zaak 4')
                      , ('Partij 2', 'Zaak 5')
                      , ('Partij 3', 'Zaak 6')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug gevoegde                *
    *                              *
    * fields:                      *
    * I/\gevoegde;gevoegde~  [ASY] *
    * gevoegde  []                 *
    \******************************/
    mysql_query("CREATE TABLE `gevoegde`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gevoegde` (`Partij` ,`Zaakid` )
                VALUES ('Partij 7', 'Zaak 4')
                      , ('Partij 8', 'Zaak 5')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug klager              *
    *                          *
    * fields:                  *
    * I/\klager;klager~  [ASY] *
    * klager  []               *
    \**************************/
    mysql_query("CREATE TABLE `klager`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug gewraakte                 *
    *                                *
    * fields:                        *
    * I/\gewraakte;gewraakte~  [ASY] *
    * gewraakte  []                  *
    \********************************/
    mysql_query("CREATE TABLE `gewraakte`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug wraker              *
    *                          *
    * fields:                  *
    * I/\wraker;wraker~  [ASY] *
    * wraker  []               *
    \**************************/
    mysql_query("CREATE TABLE `wraker`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************\
    * Plug wrakingsverzoek                       *
    *                                            *
    * fields:                                    *
    * I/\wrakingsverzoek;wrakingsverzoek~  [ASY] *
    * wrakingsverzoek  []                        *
    \********************************************/
    mysql_query("CREATE TABLE `wrakingsverzoek`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug verschonende                    *
    *                                      *
    * fields:                              *
    * I/\verschonende;verschonende~  [ASY] *
    * verschonende  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `verschonende`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug verschoningsverzoek                           *
    *                                                    *
    * fields:                                            *
    * I/\verschoningsverzoek;verschoningsverzoek~  [ASY] *
    * verschoningsverzoek  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `verschoningsverzoek`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************\
    * Plug datumdelict                   *
    *                                    *
    * fields:                            *
    * I/\datumdelict;datumdelict~  [ASY] *
    * datumdelict  []                    *
    \************************************/
    mysql_query("CREATE TABLE `datumdelict`
                     ( `Feit` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `datumdelict` (`Feit` ,`Datum` )
                VALUES ('Feit 1', '20-11-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug tijdstipdelict                      *
    *                                          *
    * fields:                                  *
    * I/\tijdstipdelict;tijdstipdelict~  [ASY] *
    * tijdstipdelict  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `tijdstipdelict`
                     ( `Feit` VARCHAR(255) DEFAULT NULL
                     , `Tijdstip` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `tijdstipdelict` (`Feit` ,`Tijdstip` )
                VALUES ('Feit 1', '18:15')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug plaatsdelict                    *
    *                                      *
    * fields:                              *
    * I/\plaatsdelict;plaatsdelict~  [ASY] *
    * plaatsdelict  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `plaatsdelict`
                     ( `Feit` VARCHAR(255) DEFAULT NULL
                     , `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `plaatsdelict` (`Feit` ,`Adres` )
                VALUES ('Feit 1', 'Weldammerbos 17, 7543GW Enschede')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug artikelvoorschrift                          *
    *                                                  *
    * fields:                                          *
    * I/\artikelvoorschrift;artikelvoorschrift~  [ASY] *
    * artikelvoorschrift  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `artikelvoorschrift`
                     ( `Artikel` VARCHAR(255) DEFAULT NULL
                     , `Feit` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `artikelvoorschrift` (`Artikel` ,`Feit` )
                VALUES ('Art. 315 Sr', 'Feit 1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug omschrijvingartikel                           *
    *                                                    *
    * fields:                                            *
    * I/\omschrijvingartikel;omschrijvingartikel~  [ASY] *
    * omschrijvingartikel  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `omschrijvingartikel`
                     ( `Tekst` VARCHAR(255) DEFAULT NULL
                     , `Artikel` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `omschrijvingartikel` (`Tekst` ,`Artikel` )
                VALUES ('Zware mishandeling met voorbedachte rade', 'Art. 315 Sr')
                      , ('Valsmunterij', 'Art. 208 Sr')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug omstandigheden                      *
    *                                          *
    * fields:                                  *
    * I/\omstandigheden;omstandigheden~  [ASY] *
    * omstandigheden  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `omstandigheden`
                     ( `Feit` VARCHAR(255) DEFAULT NULL
                     , `Tekst` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug producties                  *
    *                                  *
    * fields:                          *
    * I/\producties;producties~  [ASY] *
    * producties  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `producties`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Aantal` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `producties` (`Dagvaarding` ,`Aantal` )
                VALUES ('Dagvaarding 1', '5')
                      , ('Dagvaarding 2', '2')
                      , ('Dagvaarding 3', '6')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************\
    * Plug deurwaarder                   *
    *                                    *
    * fields:                            *
    * I/\deurwaarder;deurwaarder~  [ASY] *
    * deurwaarder  []                    *
    \************************************/
    mysql_query("CREATE TABLE `deurwaarder`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `deurwaarder` (`Dagvaarding` ,`NatuurlijkPersoon` )
                VALUES ('Dagvaarding 1', '1')
                      , ('Dagvaarding 2', '2')
                      , ('Dagvaarding 3', '1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug afschrift                 *
    *                                *
    * fields:                        *
    * I/\afschrift;afschrift~  [ASY] *
    * afschrift  []                  *
    \********************************/
    mysql_query("CREATE TABLE `afschrift`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug adresafschrift                      *
    *                                          *
    * fields:                                  *
    * I/\adresafschrift;adresafschrift~  [ASY] *
    * adresafschrift  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `adresafschrift`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************************\
    * Plug gemachtigdecivielstraf                              *
    *                                                          *
    * fields:                                                  *
    * I/\gemachtigdecivielstraf;gemachtigdecivielstraf~  [ASY] *
    * gemachtigdecivielstraf  []                               *
    \**********************************************************/
    mysql_query("CREATE TABLE `gemachtigdecivielstraf`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     , `Advocaat` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gemachtigdecivielstraf` (`Partij` ,`Advocaat` )
                VALUES ('Partij 1', 'mr. S. Levelt')
                      , ('Partij 2', 'mr. L.L.A. Cox')
                      , ('Partij 3', 'mr. A. Dekkers')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************\
    * Plug gronden               *
    *                            *
    * fields:                    *
    * I/\gronden;gronden~  [ASY] *
    * gronden  []                *
    \****************************/
    mysql_query("CREATE TABLE `gronden`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Eis` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug behandelplaats                      *
    *                                          *
    * fields:                                  *
    * I/\behandelplaats;behandelplaats~  [ASY] *
    * behandelplaats  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `behandelplaats`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Orgaan` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `behandelplaats` (`Dagvaarding` ,`Orgaan` )
                VALUES ('Dagvaarding 1', 'Raad van State')
                      , ('Dagvaarding 2', 'Rechtbank Leeuwarden')
                      , ('Dagvaarding 3', 'Rechtbank Almelo')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug behandeladres                     *
    *                                        *
    * fields:                                *
    * I/\behandeladres;behandeladres~  [ASY] *
    * behandeladres  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `behandeladres`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************\
    * Plug adresvoorstukken                        *
    *                                              *
    * fields:                                      *
    * I/\adresvoorstukken;adresvoorstukken~  [ASY] *
    * adresvoorstukken  []                         *
    \**********************************************/
    mysql_query("CREATE TABLE `adresvoorstukken`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `Adres` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug verschijningswijze                          *
    *                                                  *
    * fields:                                          *
    * I/\verschijningswijze;verschijningswijze~  [ASY] *
    * verschijningswijze  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `verschijningswijze`
                     ( `Dagvaarding` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************************\
    * Plug conclusievanantwoord                            *
    *                                                      *
    * fields:                                              *
    * I/\conclusievanantwoord;conclusievanantwoord~  [ASY] *
    * conclusievanantwoord  []                             *
    \******************************************************/
    mysql_query("CREATE TABLE `conclusievanantwoord`
                     ( `Zaakid` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `conclusievanantwoord` (`Zaakid` ,`Document` )
                VALUES ('Zaak 4', 'Conclusie20120319')
                      , ('Zaak 5', 'Conclusie20110627')
                      , ('Zaak 6', 'Conclusie20110330')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug indiener                *
    *                              *
    * fields:                      *
    * I/\indiener;indiener~  [ASY] *
    * indiener  []                 *
    \******************************/
    mysql_query("CREATE TABLE `indiener`
                     ( `Beroepschrift` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `indiener` (`Beroepschrift` ,`NatuurlijkPersoon` )
                VALUES ('Beroepschrift 1', '10')
                      , ('Beroepschrift 2', '3')
                      , ('Beroepschrift 3', '6')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug gemachtigdebestuur                          *
    *                                                  *
    * fields:                                          *
    * I/\gemachtigdebestuur;gemachtigdebestuur~  [ASY] *
    * gemachtigdebestuur  []                           *
    \**************************************************/
    mysql_query("CREATE TABLE `gemachtigdebestuur`
                     ( `sNatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `tNatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug verweerder                  *
    *                                  *
    * fields:                          *
    * I/\verweerder;verweerder~  [ASY] *
    * verweerder  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `verweerder`
                     ( `Beroepschrift` VARCHAR(255) DEFAULT NULL
                     , `Orgaan` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************\
    * Plug aanhangigbestuur                        *
    *                                              *
    * fields:                                      *
    * I/\aanhangigbestuur;aanhangigbestuur~  [ASY] *
    * aanhangigbestuur  []                         *
    \**********************************************/
    mysql_query("CREATE TABLE `aanhangigbestuur`
                     ( `Beroepschrift` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `aanhangigbestuur` (`Beroepschrift` ,`Zaakid` )
                VALUES ('Beroepschrift 1', 'Zaak 10')
                      , ('Beroepschrift 2', 'Zaak 11')
                      , ('Beroepschrift 3', 'Zaak 12')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug behandeld                 *
    *                                *
    * fields:                        *
    * I/\behandeld;behandeld~  [ASY] *
    * behandeld  []                  *
    \********************************/
    mysql_query("CREATE TABLE `behandeld`
                     ( `Zaakid` VARCHAR(255) DEFAULT NULL
                     , `MondelingeBehandeling` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `behandeld` (`Zaakid` ,`MondelingeBehandeling` )
                VALUES ('Zaak 4', 'Behandeling 11/123458')
                      , ('Zaak 5', 'Behandeling 10/569423')
                      , ('Zaak 6', 'Behandeling 11/489631')
                      , ('Zaak 7', 'Behandeling 4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug rechtertekent                     *
    *                                        *
    * fields:                                *
    * I/\rechtertekent;rechtertekent~  [ASY] *
    * rechtertekent  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `rechtertekent`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `rechtertekent` (`Rechter` ,`Document` )
                VALUES ('Rechter 9', 'Proc 11/123458')
                      , ('Rechter 12', 'Proc 10/569423')
                      , ('Rechter 7', 'Proc 11/489631')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************\
    * Plug tolk            *
    *                      *
    * fields:              *
    * I/\tolk;tolk~  [ASY] *
    * tolk  []             *
    \**********************/
    mysql_query("CREATE TABLE `tolk`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `MondelingeBehandeling` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug bewijsstuk                  *
    *                                  *
    * fields:                          *
    * I/\bewijsstuk;bewijsstuk~  [ASY] *
    * bewijsstuk  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `bewijsstuk`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `MondelingeBehandeling` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************************\
    * Plug verhinderdatumrechter                             *
    *                                                        *
    * fields:                                                *
    * I/\verhinderdatumrechter;verhinderdatumrechter~  [ASY] *
    * verhinderdatumrechter  []                              *
    \********************************************************/
    mysql_query("CREATE TABLE `verhinderdatumrechter`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `verhinderdatumrechter` (`Rechter` ,`Datum` )
                VALUES ('Rechter 1', '12-03-2012')
                      , ('Rechter 1', '13-03-2012')
                      , ('Rechter 10', '13-03-2012')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************************\
    * Plug verhinderdatumpartij                            *
    *                                                      *
    * fields:                                              *
    * I/\verhinderdatumpartij;verhinderdatumpartij~  [ASY] *
    * verhinderdatumpartij  []                             *
    \******************************************************/
    mysql_query("CREATE TABLE `verhinderdatumpartij`
                     ( `Partij` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug geschorst                 *
    *                                *
    * fields:                        *
    * I/\geschorst;geschorst~  [ASY] *
    * geschorst  []                  *
    \********************************/
    mysql_query("CREATE TABLE `geschorst`
                     ( `MondelingeBehandeling` VARCHAR(255) DEFAULT NULL
                     , `Tijdstip` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `geschorst` (`MondelingeBehandeling` ,`Tijdstip` )
                VALUES ('Behandeling 11/123458', '16:33')
                      , ('Behandeling 11/123458', '15:30')
                      , ('Behandeling 10/569423', '17:02')
                      , ('Behandeling 11/489631', '10:15')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug hervat              *
    *                          *
    * fields:                  *
    * I/\hervat;hervat~  [ASY] *
    * hervat  []               *
    \**************************/
    mysql_query("CREATE TABLE `hervat`
                     ( `MondelingeBehandeling` VARCHAR(255) DEFAULT NULL
                     , `Tijdstip` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `hervat` (`MondelingeBehandeling` ,`Tijdstip` )
                VALUES ('Behandeling 11/123458', '17:33')
                      , ('Behandeling 11/123458', '16:00')
                      , ('Behandeling 10/569423', '17:17')
                      , ('Behandeling 11/489631', '10:30')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug zittinghouden                     *
    *                                        *
    * fields:                                *
    * I/\zittinghouden;zittinghouden~  [ASY] *
    * zittinghouden  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `zittinghouden`
                     ( `Kamerid` VARCHAR(255) DEFAULT NULL
                     , `Zitting` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `zittinghouden` (`Kamerid` ,`Zitting` )
                VALUES ('Kamer 1', 'Zitting RbLee 591')
                      , ('Kamer 2', 'Zitting RbsGr 35')
                      , ('Kamer 3', 'Zitting RbAlm 68')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************\
    * Plug naamrechter                   *
    *                                    *
    * fields:                            *
    * I/\naamrechter;naamrechter~  [ASY] *
    * naamrechter  []                    *
    \************************************/
    mysql_query("CREATE TABLE `naamrechter`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                     , `Rechternaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `naamrechter` (`Rechter` ,`Rechternaam` )
                VALUES ('Rechter 1', 'mr. T.M.A. van Löben Sels')
                      , ('Rechter 2', 'mr. G.M.P. Brouns')
                      , ('Rechter 3', 'mr. N.M. van Waterschoot')
                      , ('Rechter 4', 'mr. J.H.B. van der Meer')
                      , ('Rechter 5', 'mr. Ph.Q. van Otterloo-Pannerden')
                      , ('Rechter 6', 'mr. H.P. Kijlstra')
                      , ('Rechter 7', 'mr. A.M. Rikken')
                      , ('Rechter 8', 'mr. B.M. Hoek')
                      , ('Rechter 9', 'mr. J.A.A.M. van Veen')
                      , ('Rechter 10', 'mr. H.J.Deuring')
                      , ('Rechter 11', 'mr. J. Hielkema')
                      , ('Rechter 12', 'mr. E.M. Dil-Stork')
                      , ('Rechter 13', 'mr. G. Harten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug rechtsgebied1                   *
    *                                      *
    * fields:                              *
    * I/\rechtsgebied;rechtsgebied~  [ASY] *
    * rechtsgebied  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `rechtsgebied1`
                     ( `Rechtbank` VARCHAR(255) DEFAULT NULL
                     , `Arrondissement` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `rechtsgebied1` (`Rechtbank` ,`Arrondissement` )
                VALUES ('Rechtbank Amsterdam', 'Amsterdam')
                      , ('Rechtbank Den Haag', 'Den Haag')
                      , ('Rechtbank Limburg', 'Limburg')
                      , ('Rechtbank Midden-Nederland', 'Midden-Nederland')
                      , ('Rechtbank Noord-Holland', 'Noord-Holland')
                      , ('Rechtbank Noord-Nederland', 'Noord-Nederland')
                      , ('Rechtbank Oost-Brabant', 'Oost-Brabant')
                      , ('Rechtbank Oost-Nederland', 'Oost-Nederland')
                      , ('Rechtbank Rotterdam', 'Rotterdam')
                      , ('Rechtbank Zeeland-West-Brabant', 'Zeeland-West-Brabant')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug rechtsgebied2                   *
    *                                      *
    * fields:                              *
    * I/\rechtsgebied;rechtsgebied~  [ASY] *
    * rechtsgebied  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `rechtsgebied2`
                     ( `Gerechtshof` VARCHAR(255) DEFAULT NULL
                     , `Ressort` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `rechtsgebied2` (`Gerechtshof` ,`Ressort` )
                VALUES ('Gerechtshof Amsterdam', 'Amsterdam')
                      , ('Gerechtshof Den Haag', 'Den Haag')
                      , ('Gerechtshof Arnhem-Leeuwarden', 'Arnhem-Leeuwarden')
                      , ('Gerechtshof \'s-Hertogenbosch', '\'s-Hertogenbosch')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug ressorteertHGK                      *
    *                                          *
    * fields:                                  *
    * I/\ressorteertHGK;ressorteertHGK~  [ASY] *
    * ressorteertHGK  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `ressorteertHGK`
                     ( `Arrondissement` VARCHAR(255) DEFAULT NULL
                     , `Ressort` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `ressorteertHGK` (`Arrondissement` ,`Ressort` )
                VALUES ('Amsterdam', 'Amsterdam')
                      , ('Noord-Holland', 'Amsterdam')
                      , ('Midden-Nederland', 'Arnhem-Leeuwarden')
                      , ('Oost-Nederland', 'Arnhem-Leeuwarden')
                      , ('Zeeland-West-Brabant', 's-Hertogenbosch')
                      , ('Noord-Nederland', 'Arnhem-Leeuwarden')
                      , ('Den Haag', 'Den Haag')
                      , ('Rotterdam', 'Den Haag')
                      , ('Limburg', 's-Hertogenbosch')
                      , ('Oost-Brabant', 's-Hertogenbosch')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug gbaVoornamen                    *
    *                                      *
    * fields:                              *
    * I/\gbaVoornamen;gbaVoornamen~  [ASY] *
    * gbaVoornamen  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `gbaVoornamen`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Voornamen` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gbaVoornamen` (`NatuurlijkPersoon` ,`Voornamen` )
                VALUES ('1', 'Peter')
                      , ('2', 'Eman')
                      , ('3', 'Ola')
                      , ('4', 'Sebastiaan')
                      , ('5', 'Ilja')
                      , ('6', 'Anne')
                      , ('7', 'Lonneke')
                      , ('8', 'Sascha')
                      , ('9', 'Hendrik Pieter Cornelis')
                      , ('10', 'Sandra Anne')
                      , ('11', 'Roeland Petrus')
                      , ('12', 'Frits')
                      , ('13', 'Bert')
                      , ('14', 'Olaf')
                      , ('15', 'Barend')
                      , ('16', 'Tomas')
                      , ('17', 'Andre')
                      , ('18', 'Sanne')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************\
    * Plug gbaGeslachtsnaam                        *
    *                                              *
    * fields:                                      *
    * I/\gbaGeslachtsnaam;gbaGeslachtsnaam~  [ASY] *
    * gbaGeslachtsnaam  []                         *
    \**********************************************/
    mysql_query("CREATE TABLE `gbaGeslachtsnaam`
                     ( `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     , `Geslachtsnaam` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gbaGeslachtsnaam` (`NatuurlijkPersoon` ,`Geslachtsnaam` )
                VALUES ('1', 'Jansen')
                      , ('2', 'Pietersen')
                      , ('3', 'Sigursson')
                      , ('4', 'Levelt')
                      , ('5', 'van Driel')
                      , ('6', 'Dekkers')
                      , ('7', 'Cox')
                      , ('8', 'Guillaume')
                      , ('9', 'van de Meene')
                      , ('10', 'Wiltschut')
                      , ('11', 'Dijkstra')
                      , ('12', 'Audeur')
                      , ('13', 'Stolen')
                      , ('14', 'Elicht')
                      , ('15', 'Eul')
                      , ('16', 'Sjesdief')
                      , ('17', 'Angereden')
                      , ('18', 'Verhoeven')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug adelijketitel                     *
    *                                        *
    * fields:                                *
    * I/\adelijketitel;adelijketitel~  [ASY] *
    * adelijketitel  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `adelijketitel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `adelijketitel` (`Titel` ,`NatuurlijkPersoon` )
                VALUES ('Baron', '1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************\
    * Plug opleidingstitel                       *
    *                                            *
    * fields:                                    *
    * I/\opleidingstitel;opleidingstitel~  [ASY] *
    * opleidingstitel  []                        *
    \********************************************/
    mysql_query("CREATE TABLE `opleidingstitel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `opleidingstitel` (`Titel` ,`NatuurlijkPersoon` )
                VALUES ('mr', '4')
                      , ('mr', '5')
                      , ('mr', '6')
                      , ('mr', '7')
                      , ('mr', '8')
                      , ('drs', '18')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug zaaksdossier                    *
    *                                      *
    * fields:                              *
    * I/\zaaksdossier;zaaksdossier~  [ASY] *
    * zaaksdossier  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `zaaksdossier`
                     ( `Dossier` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `zaaksdossier` (`Dossier` ,`Zaakid` )
                VALUES ('Dossier 10/569423', 'Zaak 5')
                      , ('Dossier 11/123458', 'Zaak 4')
                      , ('Dossier 11/489631', 'Zaak 6')
                      , ('Dossier 08/476197', 'Zaak 7')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug zaakstuk                *
    *                              *
    * fields:                      *
    * I/\zaakstuk;zaakstuk~  [ASY] *
    * zaakstuk  []                 *
    \******************************/
    mysql_query("CREATE TABLE `zaakstuk`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Dossier` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `zaakstuk` (`Document` ,`Dossier` )
                VALUES ('Proc 11/123458', 'Dossier 11/123458')
                      , ('Proc 10/569423', 'Dossier 10/569423')
                      , ('Proc 11/489631', 'Dossier 11/489631')
                      , ('Dag20120205', 'Dossier 11/123458')
                      , ('Dag20110513', 'Dossier 10/569423')
                      , ('Dag20110216', 'Dossier 11/489631')
                      , ('Vti1', 'Dossier 08/476197')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug zaaksdocument                     *
    *                                        *
    * fields:                                *
    * I/\zaaksdocument;zaaksdocument~  [ASY] *
    * zaaksdocument  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `zaaksdocument`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `zaaksdocument` (`Document` ,`Zaakid` )
                VALUES ('Proc 11/123458', 'Zaak 4')
                      , ('Proc 10/569423', 'Zaak 5')
                      , ('Proc 11/489631', 'Zaak 6')
                      , ('Dag20120205', 'Zaak 4')
                      , ('Dag20110513', 'Zaak 5')
                      , ('Dag20110216', 'Zaak 6')
                      , ('Vti1', 'Zaak 7')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************\
    * Plug type            *
    *                      *
    * fields:              *
    * I/\type;type~  [ASY] *
    * type  []             *
    \**********************/
    mysql_query("CREATE TABLE `type`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Zaakstuktype` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `type` (`Document` ,`Zaakstuktype` )
                VALUES ('Proc 11/123458', 'Proces Verbaal')
                      , ('Proc 10/569423', 'Proces Verbaal')
                      , ('Proc 11/489631', 'Proces Verbaal')
                      , ('Dag20120205', 'Dagvaarding')
                      , ('Dag20110513', 'Dagvaarding')
                      , ('Dag20110216', 'Dagvaarding')
                      , ('Vti1', 'Verzoek tot inschrijving als advocaat')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug inhoud              *
    *                          *
    * fields:                  *
    * I/\inhoud;inhoud~  [ASY] *
    * inhoud  []               *
    \**************************/
    mysql_query("CREATE TABLE `inhoud`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Object` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `inhoud` (`Document` ,`Object` )
                VALUES ('Proc 11/123458', 'Obj739920')
                      , ('Proc 10/569423', 'Obj930023')
                      , ('Proc 11/489631', 'Obj456188')
                      , ('Dag20120205', 'Obj484188')
                      , ('Dag20110513', 'Obj786188')
                      , ('Dag20110216', 'Obj989657')
                      , ('Vti1', 'Obj954751')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug ontstaan                *
    *                              *
    * fields:                      *
    * I/\ontstaan;ontstaan~  [ASY] *
    * ontstaan  []                 *
    \******************************/
    mysql_query("CREATE TABLE `ontstaan`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `ontstaan` (`Document` ,`Gebeurtenis` )
                VALUES ('Proc 11/123458', 'Ev739920')
                      , ('Proc 10/569423', 'Ev930023')
                      , ('Proc 11/489631', 'Ev456188')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug zorgdrager                  *
    *                                  *
    * fields:                          *
    * I/\zorgdrager;zorgdrager~  [ASY] *
    * zorgdrager  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `zorgdrager`
                     ( `Dossier` VARCHAR(255) DEFAULT NULL
                     , `Orgaan` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `zorgdrager` (`Dossier` ,`Orgaan` )
                VALUES ('Dossier 11/123458', 'Rechtbank \'s-Gravenhage')
                      , ('Dossier 10/569423', 'Rechtbank Leeuwarden')
                      , ('Dossier 11/489631', 'Rechtbank Almelo')
                      , ('Dossier 08/476197', 'Rechtbank Amsterdam')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug ingevoegd                 *
    *                                *
    * fields:                        *
    * I/\ingevoegd;ingevoegd~  [ASY] *
    * ingevoegd  []                  *
    \********************************/
    mysql_query("CREATE TABLE `ingevoegd`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `ingevoegd` (`Gebeurtenis` ,`Document` )
                VALUES ('Ev695', 'Proc 11/123458')
                      , ('Ev426', 'Proc 10/569423')
                      , ('Ev336', 'Proc 11/489631')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug afgedrukt                 *
    *                                *
    * fields:                        *
    * I/\afgedrukt;afgedrukt~  [ASY] *
    * afgedrukt  []                  *
    \********************************/
    mysql_query("CREATE TABLE `afgedrukt`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `afgedrukt` (`Document` ,`Gebeurtenis` )
                VALUES ('Proc 11/123458', 'Ev732491')
                      , ('Proc 10/569423', 'Ev993123')
                      , ('Proc 11/489631', 'Ev476228')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************\
    * Plug over            *
    *                      *
    * fields:              *
    * I/\over;over~  [ASY] *
    * over  []             *
    \**********************/
    mysql_query("CREATE TABLE `over`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `NatuurlijkPersoon` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `over` (`Document` ,`NatuurlijkPersoon` )
                VALUES ('Proc 11/123458', '12')
                      , ('Proc 10/569423', '16')
                      , ('Proc 11/489631', '15')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug neerslag                *
    *                              *
    * fields:                      *
    * I/\neerslag;neerslag~  [ASY] *
    * neerslag  []                 *
    \******************************/
    mysql_query("CREATE TABLE `neerslag`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `neerslag` (`Document` ,`Gebeurtenis` )
                VALUES ('Proc 11/123458', 'Zitting RbsGr 35')
                      , ('Proc 10/569423', 'Zitting RbLee 591')
                      , ('Proc 11/489631', 'Zitting RbAlm 68')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug rIOhandeling                    *
    *                                      *
    * fields:                              *
    * I/\rIOhandeling;rIOhandeling~  [ASY] *
    * rIOhandeling  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `rIOhandeling`
                     ( `Handeling` VARCHAR(255) DEFAULT NULL
                     , `RIO handeling` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `rIOhandeling` (`Handeling` ,`RIO handeling` )
                VALUES ('1', '6')
                      , ('1', '8')
                      , ('1', '9')
                      , ('1', '16')
                      , ('1', '17')
                      , ('1', '18')
                      , ('1', '22')
                      , ('1', '24')
                      , ('1', '25')
                      , ('1', '27')
                      , ('1', '51')
                      , ('1', '57')
                      , ('1', '69')
                      , ('1', '71')
                      , ('1', '74')
                      , ('4', '37')
                      , ('4', '39')
                      , ('4', '60')
                      , ('4', '67')
                      , ('4', '73')
                      , ('5', '11')
                      , ('5', '15')
                      , ('5', '21')
                      , ('5', '23')
                      , ('5', '49')
                      , ('10', '32')
                      , ('10', '101')
                      , ('11', '102')
                      , ('13', '32')
                      , ('13', '101')
                      , ('14', '4')
                      , ('14', '14')
                      , ('14', '20')
                      , ('14', '48a')
                      , ('14', '53')
                      , ('14', '55')
                      , ('15', '4')
                      , ('15', '20')
                      , ('15', '43')
                      , ('15', '46')
                      , ('15', '48')
                      , ('15', '(48a)')
                      , ('15', '50')
                      , ('15', '56')
                      , ('15', '98')
                      , ('16', '7')
                      , ('18', '54')
                      , ('18', '97')
                      , ('19', '20')
                      , ('20', '84')
                      , ('20', '1')
                      , ('21', '84')
                      , ('21', '1')
                      , ('22', '1')
                      , ('22', '10')
                      , ('22', '84')
                      , ('23', '1')
                      , ('23', '10')
                      , ('23', '84')
                      , ('24', '1')
                      , ('24', '10')
                      , ('24', '84')
                      , ('25', '1')
                      , ('25', '84')
                      , ('26', '1')
                      , ('26', '10')
                      , ('26', '84')
                      , ('27', '3')
                      , ('27', '10')
                      , ('27', '81')
                      , ('28', '45')
                      , ('29', '42')
                      , ('30', '86')
                      , ('30', '89')
                      , ('30', '98')
                      , ('30', '103')
                      , ('30', '104')
                      , ('32', '13')
                      , ('32', '31')
                      , ('32', '89')
                      , ('33', '13')
                      , ('33', '89')
                      , ('38', '86')
                      , ('38', '89')
                      , ('38', '100')
                      , ('39', '99')
                      , ('41', '2')
                      , ('43', '44')
                      , ('44', '47')
                      , ('44', '98')
                      , ('45', '72')
                      , ('45', '75')
                      , ('46', '26')
                      , ('47', '12')
                      , ('47', '28')
                      , ('47', '52')
                      , ('47', '64')
                      , ('48', '19')
                      , ('48', '109')
                      , ('49', '83')
                      , ('49', '108')
                      , ('49', '110')
                      , ('50', '70')
                      , ('50', '76')
                      , ('50', '80')
                      , ('51', '35')
                      , ('52', '78')
                      , ('52', '96')
                      , ('53', '105')
                      , ('54', '91')
                      , ('55', '85')
                      , ('56', '92')
                      , ('57', '93')
                      , ('2', '41')
                      , ('2', '59')
                      , ('2', '61')
                      , ('2', '63')
                      , ('2', '65')
                      , ('2', '66')
                      , ('2', '68')
                      , ('3', '62')
                      , ('3', '65')
                      , ('89', '102')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug criterium                 *
    *                                *
    * fields:                        *
    * I/\criterium;criterium~  [ASY] *
    * criterium  []                  *
    \********************************/
    mysql_query("CREATE TABLE `criterium`
                     ( `Handeling` VARCHAR(255) DEFAULT NULL
                     , `Selectiecriterium` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `criterium` (`Handeling` ,`Selectiecriterium` )
                VALUES ('1', '1')
                      , ('1', '2')
                      , ('6', '3')
                      , ('7', '2')
                      , ('7', '3')
                      , ('9', '5')
                      , ('10', '4')
                      , ('14', '1')
                      , ('15', '5')
                      , ('17', '5')
                      , ('58', '1')
                      , ('58', '5')
                      , ('28', '5')
                      , ('29', '5')
                      , ('36', '4')
                      , ('37', '5')
                      , ('40', '5')
                      , ('42', '1')
                      , ('44', '5')
                      , ('45', '5')
                      , ('59', '1')
                      , ('59', '4')
                      , ('60', '1')
                      , ('60', '4')
                      , ('52', '5')
                      , ('65', '5')
                      , ('2', '1')
                      , ('3', '5')
                      , ('70', '5')
                      , ('72', '1')
                      , ('72', '2')
                      , ('73', '1')
                      , ('73', '5')
                      , ('74', '1')
                      , ('74', '5')
                      , ('75', '1')
                      , ('75', '4')
                      , ('79', '3')
                      , ('81', '5')
                      , ('82', '5')
                      , ('84', '1')
                      , ('85', '5')
                      , ('86', '2')
                      , ('87', '5')
                      , ('89', '1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************\
    * Plug locatie               *
    *                            *
    * fields:                    *
    * I/\locatie;locatie~  [ASY] *
    * locatie  []                *
    \****************************/
    mysql_query("CREATE TABLE `locatie`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Plaats` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `locatie` (`Gebeurtenis` ,`Plaats` )
                VALUES ('Ev739920', '\'s-Gravenhage')
                      , ('Ev930023', 'Leeuwarden')
                      , ('Ev456188', 'Almelo')
                      , ('Ev695', '\'s-Gravenhage')
                      , ('Ev426', 'Leeuwarden')
                      , ('Ev336', 'Almelo')
                      , ('Ev732491', '\'s-Gravenhage')
                      , ('Ev993123', 'Groningen')
                      , ('Ev476228', 'Enschede')
                      , ('Zitting RbsGr 35', '\'s-Gravenhage')
                      , ('Zitting RbLee 591', 'Leeuwarden')
                      , ('Zitting RbAlm 68', 'Almelo')
                      , ('Msg598', '\'s-Gravenhage')
                      , ('Msg449', 'Leeuwarden')
                      , ('Msg779', 'Almelo')
                      , ('Be1', 'Amsterdam')
                      , ('Be2', 'Rotterdam')
                      , ('Be3', 'Utrecht')
                      , ('Be4', 'Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************\
    * Plug ouder             *
    *                        *
    * fields:                *
    * I/\ouder;ouder~  [ASY] *
    * ouder  [TRN,ASY]       *
    \************************/
    mysql_query("CREATE TABLE `ouder`
                     ( `sGebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `tGebeurtenis` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug plandatum                 *
    *                                *
    * fields:                        *
    * I/\plandatum;plandatum~  [ASY] *
    * plandatum  []                  *
    \********************************/
    mysql_query("CREATE TABLE `plandatum`
                     ( `SchriftelijkeUitspraak` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `plandatum` (`SchriftelijkeUitspraak` ,`Datum` )
                VALUES ('Vonnis 1', '30-05-2011')
                      , ('Vonnis 2', '14-12-2010')
                      , ('Vonnis 3', '26-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug eindbeslissing                      *
    *                                          *
    * fields:                                  *
    * I/\eindbeslissing;eindbeslissing~  [ASY] *
    * eindbeslissing  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `eindbeslissing`
                     ( `SchriftelijkeUitspraak` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `eindbeslissing` (`SchriftelijkeUitspraak` ,`Document` )
                VALUES ('Vonnis 1', 'BR9826')
                      , ('Vonnis 2', 'BU9872')
                      , ('Vonnis 3', 'BU2372')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug vonnis              *
    *                          *
    * fields:                  *
    * I/\vonnis;vonnis~  [ASY] *
    * vonnis  []               *
    \**************************/
    mysql_query("CREATE TABLE `vonnis`
                     ( `SchriftelijkeUitspraak` VARCHAR(255) DEFAULT NULL
                     , `Zaakid` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `vonnis` (`SchriftelijkeUitspraak` ,`Zaakid` )
                VALUES ('Vonnis 1', 'Zaak 4')
                      , ('Vonnis 2', 'Zaak 5')
                      , ('Vonnis 3', 'Zaak 6')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug wijzen              *
    *                          *
    * fields:                  *
    * I/\wijzen;wijzen~  [ASY] *
    * wijzen  []               *
    \**************************/
    mysql_query("CREATE TABLE `wijzen`
                     ( `SchriftelijkeUitspraak` VARCHAR(255) DEFAULT NULL
                     , `Rechter` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `wijzen` (`SchriftelijkeUitspraak` ,`Rechter` )
                VALUES ('Vonnis 1', 'Rechter 9')
                      , ('Vonnis 2', 'Rechter 12')
                      , ('Vonnis 3', 'Rechter 7')
                      , ('Vonnis 1', 'Rechter 10')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug wijsdatum                 *
    *                                *
    * fields:                        *
    * I/\wijsdatum;wijsdatum~  [ASY] *
    * wijsdatum  []                  *
    \********************************/
    mysql_query("CREATE TABLE `wijsdatum`
                     ( `SchriftelijkeUitspraak` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `wijsdatum` (`SchriftelijkeUitspraak` ,`Datum` )
                VALUES ('Vonnis 1', '30-05-2011')
                      , ('Vonnis 2', '14-12-2010')
                      , ('Vonnis 3', '26-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo '<div id="ResetSuccess"/>The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "Generics.php";
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT DemoZaakgegevens\n");
      fwrite($dumpfile, dumprel("strafblad[Strafblad*Document]","SELECT DISTINCT `Strafblad`, `Document` FROM `strafblad2` WHERE `Strafblad` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hoortbij[Strafblad*Strafrechtsketennummer]","SELECT DISTINCT `Strafblad`, `Strafrechtsketennummer` FROM `hoortbij` WHERE `Strafblad` IS NOT NULL AND `Strafrechtsketennummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verzoektotinschrijving[Document*NatuurlijkPersoon]","SELECT DISTINCT `Document`, `verzoektotinschrijving` FROM `Document` WHERE `Document` IS NOT NULL AND `verzoektotinschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsverzoek[Document*Inschrijving]","SELECT DISTINCT `Document`, `inschrijvingsverzoek` FROM `Document` WHERE `Document` IS NOT NULL AND `inschrijvingsverzoek` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gerichtaan[Inschrijving*Rechtbank]","SELECT DISTINCT `Inschrijving`, `gerichtaan` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `gerichtaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingseis[Inschrijving*Inschrijvingseis]","SELECT DISTINCT `Inschrijving`, `inschrijvingseis` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `inschrijvingseis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsstatus[Inschrijving*Inschrijvingsstatus]","SELECT DISTINCT `Inschrijving`, `inschrijvingsstatus` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `inschrijvingsstatus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beëdigd[Beëdiging*Inschrijving]","SELECT DISTINCT `Beëdiging`, `beëdigd` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `beëdigd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatieBeëdiging[Beëdiging*Rechtbank]","SELECT DISTINCT `Beëdiging`, `locatieBeëdiging` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `locatieBeëdiging` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isadvocaat[Inschrijving*NatuurlijkPersoon]","SELECT DISTINCT `Inschrijving`, `isadvocaat` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `isadvocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("houdtkantoor[Inschrijving*Kantoornummer]","SELECT DISTINCT `Inschrijving`, `houdtkantoor` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `houdtkantoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("barnummer[Barnummer*Inschrijving]","SELECT DISTINCT `Barnummer0`, `barnummer1` FROM `Barnummer` WHERE `Barnummer0` IS NOT NULL AND `barnummer1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingvan[Bericht*Inschrijving]","SELECT DISTINCT `Bericht`, `schrappingvan` FROM `Gebeurtenis` WHERE `Bericht` IS NOT NULL AND `schrappingvan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsingvan[Bericht*Inschrijving]","SELECT DISTINCT `Bericht`, `schorsingvan` FROM `Gebeurtenis` WHERE `Bericht` IS NOT NULL AND `schorsingvan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsingopheffen[Bericht*Inschrijving]","SELECT DISTINCT `Bericht`, `schorsingopheffen` FROM `Gebeurtenis` WHERE `Bericht` IS NOT NULL AND `schorsingopheffen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoornaam[Kantoornummer*Kantoor]","SELECT DISTINCT `Kantoornummer`, `kantoornaam` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoornaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantooradres[Kantoornummer*Adres]","SELECT DISTINCT `Kantoornummer`, `kantooradres` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantooradres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaakreferentie[Zaak]","SELECT DISTINCT `sZaak`, `tZaak` FROM `zaakreferentie` WHERE `sZaak` IS NOT NULL AND `tZaak` IS NOT NULL"));
      fwrite($dumpfile, dumprel("jaarAanleg[Zaak*Jaar]","SELECT DISTINCT `Zaak`, `Jaar` FROM `jaarAanleg` WHERE `Zaak` IS NOT NULL AND `Jaar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("volgnr[Zaak*Volgnummer]","SELECT DISTINCT `Zaak`, `volgnr` FROM `Zaak` WHERE `Zaak` IS NOT NULL AND `volgnr` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaaknr[Zaak*Zaaknummer]","SELECT DISTINCT `Zaak`, `zaaknr` FROM `Zaak` WHERE `Zaak` IS NOT NULL AND `zaaknr` IS NOT NULL"));
      fwrite($dumpfile, dumprel("systeemcode[Zaak*Systeemcode]","SELECT DISTINCT `Zaak`, `systeemcode` FROM `Zaak` WHERE `Zaak` IS NOT NULL AND `systeemcode` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaakid[Zaakid*Zaak]","SELECT DISTINCT `Zaakid0`, `zaakid1` FROM `Zaakid` WHERE `Zaakid0` IS NOT NULL AND `zaakid1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("soortrecht[Zaakid*Soort recht]","SELECT DISTINCT `Zaakid0`, `soortrecht` FROM `Zaakid` WHERE `Zaakid0` IS NOT NULL AND `soortrecht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gedingdatum[Zaakid*Datum]","SELECT DISTINCT `Zaakid`, `Datum` FROM `gedingdatum` WHERE `Zaakid` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("behandelendgerecht[Zaakid*Gerecht]","SELECT DISTINCT `Zaakid`, `Gerecht` FROM `behandelendgerecht` WHERE `Zaakid` IS NOT NULL AND `Gerecht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gegevenAan[Zaak*Sector]","SELECT DISTINCT `Zaak`, `Sector` FROM `gegevenAan` WHERE `Zaak` IS NOT NULL AND `Sector` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaaksoort[Zaakid*Zaaktype]","SELECT DISTINCT `Zaakid0`, `zaaksoort` FROM `Zaakid` WHERE `Zaakid0` IS NOT NULL AND `zaaksoort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("griffierechtbetaald[Zaakid*Griffierechtbetaald]","SELECT DISTINCT `Zaakid`, `Griffierechtbetaald` FROM `griffierechtbetaald2` WHERE `Zaakid` IS NOT NULL AND `Griffierechtbetaald` IS NOT NULL"));
      fwrite($dumpfile, dumprel("samenstelling[Kamerid*Samenstelling]","SELECT DISTINCT `Kamerid`, `Samenstelling` FROM `samenstelling2` WHERE `Kamerid` IS NOT NULL AND `Samenstelling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kamer[Zaakid*Kamerid]","SELECT DISTINCT `Zaakid`, `Kamerid` FROM `kamer` WHERE `Zaakid` IS NOT NULL AND `Kamerid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ispartij[NatuurlijkPersoon*Partij]","SELECT DISTINCT `NatuurlijkPersoon`, `Partij` FROM `ispartij` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Partij` IS NOT NULL"));
      fwrite($dumpfile, dumprel("deskundige[NatuurlijkPersoon*Zaakid]","SELECT DISTINCT `NatuurlijkPersoon`, `Zaakid` FROM `deskundige` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("benadeeld[Partij*Zaakid]","SELECT DISTINCT `Partij`, `Zaakid` FROM `benadeeld` WHERE `Partij` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gevoegde[Partij*Zaakid]","SELECT DISTINCT `Partij`, `Zaakid` FROM `gevoegde` WHERE `Partij` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("klager[Partij*Zaakid]","SELECT DISTINCT `Partij`, `Zaakid` FROM `klager` WHERE `Partij` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gewraakte[Rechter*Document]","SELECT DISTINCT `Rechter`, `Document` FROM `gewraakte` WHERE `Rechter` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("wraker[Partij*Document]","SELECT DISTINCT `Partij`, `Document` FROM `wraker` WHERE `Partij` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("wrakingsverzoek[Document*Zaakid]","SELECT DISTINCT `Document`, `Zaakid` FROM `wrakingsverzoek` WHERE `Document` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verschonende[Rechter*Document]","SELECT DISTINCT `Rechter`, `Document` FROM `verschonende` WHERE `Rechter` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verschoningsverzoek[Document*Zaakid]","SELECT DISTINCT `Document`, `Zaakid` FROM `verschoningsverzoek` WHERE `Document` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("dagvaarding[Dagvaarding*Document]","SELECT DISTINCT `Dagvaarding0`, `dagvaarding1` FROM `Dagvaarding` WHERE `Dagvaarding0` IS NOT NULL AND `dagvaarding1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanhangig[Dagvaarding*Zaakid]","SELECT DISTINCT `Dagvaarding0`, `aanhangig` FROM `Dagvaarding` WHERE `Dagvaarding0` IS NOT NULL AND `aanhangig` IS NOT NULL"));
      fwrite($dumpfile, dumprel("datumdelict[Feit*Datum]","SELECT DISTINCT `Feit`, `Datum` FROM `datumdelict` WHERE `Feit` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tijdstipdelict[Feit*Tijdstip]","SELECT DISTINCT `Feit`, `Tijdstip` FROM `tijdstipdelict` WHERE `Feit` IS NOT NULL AND `Tijdstip` IS NOT NULL"));
      fwrite($dumpfile, dumprel("plaatsdelict[Feit*Adres]","SELECT DISTINCT `Feit`, `Adres` FROM `plaatsdelict` WHERE `Feit` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("feit[Dagvaarding*Feit]","SELECT DISTINCT `Dagvaarding`, `Feit` FROM `feit2` WHERE `Dagvaarding` IS NOT NULL AND `Feit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("artikelvoorschrift[Artikel*Feit]","SELECT DISTINCT `Artikel`, `Feit` FROM `artikelvoorschrift` WHERE `Artikel` IS NOT NULL AND `Feit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omschrijvingartikel[Tekst*Artikel]","SELECT DISTINCT `Tekst`, `Artikel` FROM `omschrijvingartikel` WHERE `Tekst` IS NOT NULL AND `Artikel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omstandigheden[Feit*Tekst]","SELECT DISTINCT `Feit`, `Tekst` FROM `omstandigheden` WHERE `Feit` IS NOT NULL AND `Tekst` IS NOT NULL"));
      fwrite($dumpfile, dumprel("datumbetekening[Dagvaarding*Datum]","SELECT DISTINCT `Dagvaarding0`, `datumbetekening` FROM `Dagvaarding` WHERE `Dagvaarding0` IS NOT NULL AND `datumbetekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("eiser[Dagvaarding*NatuurlijkPersoon]","SELECT DISTINCT `Dagvaarding0`, `eiser` FROM `Dagvaarding` WHERE `Dagvaarding0` IS NOT NULL AND `eiser` IS NOT NULL"));
      fwrite($dumpfile, dumprel("producties[Dagvaarding*Aantal]","SELECT DISTINCT `Dagvaarding`, `Aantal` FROM `producties` WHERE `Dagvaarding` IS NOT NULL AND `Aantal` IS NOT NULL"));
      fwrite($dumpfile, dumprel("deurwaarder[Dagvaarding*NatuurlijkPersoon]","SELECT DISTINCT `Dagvaarding`, `NatuurlijkPersoon` FROM `deurwaarder` WHERE `Dagvaarding` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoordeurwaarder[Dagvaarding*Kantoordeurwaarder]","SELECT DISTINCT `Dagvaarding0`, `kantoordeurwaarder` FROM `Dagvaarding` WHERE `Dagvaarding0` IS NOT NULL AND `kantoordeurwaarder` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ontvanger[Dagvaarding*NatuurlijkPersoon]","SELECT DISTINCT `Dagvaarding0`, `ontvanger` FROM `Dagvaarding` WHERE `Dagvaarding0` IS NOT NULL AND `ontvanger` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaatsontvanger[Dagvaarding*Adres]","SELECT DISTINCT `Dagvaarding0`, `woonplaatsontvanger` FROM `Dagvaarding` WHERE `Dagvaarding0` IS NOT NULL AND `woonplaatsontvanger` IS NOT NULL"));
      fwrite($dumpfile, dumprel("afschrift[Dagvaarding*NatuurlijkPersoon]","SELECT DISTINCT `Dagvaarding`, `NatuurlijkPersoon` FROM `afschrift` WHERE `Dagvaarding` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adresafschrift[Dagvaarding*Adres]","SELECT DISTINCT `Dagvaarding`, `Adres` FROM `adresafschrift` WHERE `Dagvaarding` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemachtigdecivielstraf[Partij*Advocaat]","SELECT DISTINCT `Partij`, `Advocaat` FROM `gemachtigdecivielstraf` WHERE `Partij` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gronden[Dagvaarding*Eis]","SELECT DISTINCT `Dagvaarding`, `Eis` FROM `gronden` WHERE `Dagvaarding` IS NOT NULL AND `Eis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("behandelplaats[Dagvaarding*Orgaan]","SELECT DISTINCT `Dagvaarding`, `Orgaan` FROM `behandelplaats` WHERE `Dagvaarding` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("behandeladres[Dagvaarding*Adres]","SELECT DISTINCT `Dagvaarding`, `Adres` FROM `behandeladres` WHERE `Dagvaarding` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adresvoorstukken[Dagvaarding*Adres]","SELECT DISTINCT `Dagvaarding`, `Adres` FROM `adresvoorstukken` WHERE `Dagvaarding` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("roldatum[Dagvaarding*Termijndatum]","SELECT DISTINCT `Dagvaarding0`, `roldatum` FROM `Dagvaarding` WHERE `Dagvaarding0` IS NOT NULL AND `roldatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tijdstip[Dagvaarding*Tijdstip]","SELECT DISTINCT `Dagvaarding`, `Tijdstip` FROM `tijdstip2` WHERE `Dagvaarding` IS NOT NULL AND `Tijdstip` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verschijningswijze[Dagvaarding*NatuurlijkPersoon]","SELECT DISTINCT `Dagvaarding`, `NatuurlijkPersoon` FROM `verschijningswijze` WHERE `Dagvaarding` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("conclusievanantwoord[Zaakid*Document]","SELECT DISTINCT `Zaakid`, `Document` FROM `conclusievanantwoord` WHERE `Zaakid` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beroepschrift[Beroepschrift*Document]","SELECT DISTINCT `Beroepschrift0`, `beroepschrift1` FROM `Beroepschrift` WHERE `Beroepschrift0` IS NOT NULL AND `beroepschrift1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("indiener[Beroepschrift*NatuurlijkPersoon]","SELECT DISTINCT `Beroepschrift`, `NatuurlijkPersoon` FROM `indiener` WHERE `Beroepschrift` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemachtigdebestuur[NatuurlijkPersoon]","SELECT DISTINCT `sNatuurlijkPersoon`, `tNatuurlijkPersoon` FROM `gemachtigdebestuur` WHERE `sNatuurlijkPersoon` IS NOT NULL AND `tNatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("dagtekening[Beroepschrift*Datum]","SELECT DISTINCT `Beroepschrift0`, `dagtekening` FROM `Beroepschrift` WHERE `Beroepschrift0` IS NOT NULL AND `dagtekening` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verweerder[Beroepschrift*Orgaan]","SELECT DISTINCT `Beroepschrift`, `Orgaan` FROM `verweerder` WHERE `Beroepschrift` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omschrijvingberoep[Beroepschrift*Tekst]","SELECT DISTINCT `Beroepschrift0`, `omschrijvingberoep` FROM `Beroepschrift` WHERE `Beroepschrift0` IS NOT NULL AND `omschrijvingberoep` IS NOT NULL"));
      fwrite($dumpfile, dumprel("grondenberoep[Beroepschrift*Tekst]","SELECT DISTINCT `Beroepschrift0`, `grondenberoep` FROM `Beroepschrift` WHERE `Beroepschrift0` IS NOT NULL AND `grondenberoep` IS NOT NULL"));
      fwrite($dumpfile, dumprel("aanhangigbestuur[Beroepschrift*Zaakid]","SELECT DISTINCT `Beroepschrift`, `Zaakid` FROM `aanhangigbestuur` WHERE `Beroepschrift` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("appointeringsvoorstel[Appointeringsvoorstel*Dagvaarding]","SELECT DISTINCT `Appointeringsvoorstel`, `Dagvaarding` FROM `appointeringsvoorstel2` WHERE `Appointeringsvoorstel` IS NOT NULL AND `Dagvaarding` IS NOT NULL"));
      fwrite($dumpfile, dumprel("strafrechtsketennummer[Strafrechtsketennummer*NatuurlijkPersoon]","SELECT DISTINCT `strafrechtsketennummer`, `NatuurlijkPersoon` FROM `NatuurlijkPersoon` WHERE `strafrechtsketennummer` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("behandeling[Zitting*MondelingeBehandeling]","SELECT DISTINCT `Zitting`, `behandeling` FROM `Zitting` WHERE `Zitting` IS NOT NULL AND `behandeling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zittingszaal[Zitting*Zaal]","SELECT DISTINCT `Zitting`, `zittingszaal` FROM `Zitting` WHERE `Zitting` IS NOT NULL AND `zittingszaal` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaalnaam[Zaalnaam*Zaal]","SELECT DISTINCT `Zaalnaam0`, `zaalnaam1` FROM `Zaalnaam` WHERE `Zaalnaam0` IS NOT NULL AND `zaalnaam1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("behandeld[Zaakid*MondelingeBehandeling]","SELECT DISTINCT `Zaakid`, `MondelingeBehandeling` FROM `behandeld` WHERE `Zaakid` IS NOT NULL AND `MondelingeBehandeling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("procesverbaal[MondelingeBehandeling*Document]","SELECT DISTINCT `MondelingeBehandeling`, `procesverbaal` FROM `MondelingeBehandeling` WHERE `MondelingeBehandeling` IS NOT NULL AND `procesverbaal` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechtertekent[Rechter*Document]","SELECT DISTINCT `Rechter`, `Document` FROM `rechtertekent` WHERE `Rechter` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("griffiertekent[Griffier*Document]","SELECT DISTINCT `Griffier`, `griffiertekent` FROM `Griffier` WHERE `Griffier` IS NOT NULL AND `griffiertekent` IS NOT NULL"));
      fwrite($dumpfile, dumprel("griffier[Zitting*Griffier]","SELECT DISTINCT `Zitting`, `griffier` FROM `Zitting` WHERE `Zitting` IS NOT NULL AND `griffier` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tolk[NatuurlijkPersoon*MondelingeBehandeling]","SELECT DISTINCT `NatuurlijkPersoon`, `MondelingeBehandeling` FROM `tolk` WHERE `NatuurlijkPersoon` IS NOT NULL AND `MondelingeBehandeling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bewijsstuk[Document*MondelingeBehandeling]","SELECT DISTINCT `Document`, `MondelingeBehandeling` FROM `bewijsstuk` WHERE `Document` IS NOT NULL AND `MondelingeBehandeling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verhinderdatumrechter[Rechter*Datum]","SELECT DISTINCT `Rechter`, `Datum` FROM `verhinderdatumrechter` WHERE `Rechter` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verhinderdatumpartij[Partij*Datum]","SELECT DISTINCT `Partij`, `Datum` FROM `verhinderdatumpartij` WHERE `Partij` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geagendeerd[Zitting*Datum]","SELECT DISTINCT `Zitting`, `geagendeerd` FROM `Zitting` WHERE `Zitting` IS NOT NULL AND `geagendeerd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("begintijd[Zitting*Tijdstip]","SELECT DISTINCT `Zitting`, `begintijd` FROM `Zitting` WHERE `Zitting` IS NOT NULL AND `begintijd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("eindtijd[Zitting*Tijdstip]","SELECT DISTINCT `Zitting`, `eindtijd` FROM `Zitting` WHERE `Zitting` IS NOT NULL AND `eindtijd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gesloten[MondelingeBehandeling*Tijdstip]","SELECT DISTINCT `MondelingeBehandeling`, `gesloten` FROM `MondelingeBehandeling` WHERE `MondelingeBehandeling` IS NOT NULL AND `gesloten` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geschorst[MondelingeBehandeling*Tijdstip]","SELECT DISTINCT `MondelingeBehandeling`, `Tijdstip` FROM `geschorst` WHERE `MondelingeBehandeling` IS NOT NULL AND `Tijdstip` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hervat[MondelingeBehandeling*Tijdstip]","SELECT DISTINCT `MondelingeBehandeling`, `Tijdstip` FROM `hervat` WHERE `MondelingeBehandeling` IS NOT NULL AND `Tijdstip` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zittinghouden[Kamerid*Zitting]","SELECT DISTINCT `Kamerid`, `Zitting` FROM `zittinghouden` WHERE `Kamerid` IS NOT NULL AND `Zitting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("naamrechter[Rechter*Rechternaam]","SELECT DISTINCT `Rechter`, `Rechternaam` FROM `naamrechter` WHERE `Rechter` IS NOT NULL AND `Rechternaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechter[Rechter*Kamerid]","SELECT DISTINCT `Rechter`, `Kamerid` FROM `rechter2` WHERE `Rechter` IS NOT NULL AND `Kamerid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("arrondisement[Arrondissement*Rechtbank]","SELECT DISTINCT `Arrondissement`, `arrondisement` FROM `Arrondissement` WHERE `Arrondissement` IS NOT NULL AND `arrondisement` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ressorteert[Arrondissement*Ressort]","SELECT DISTINCT `Arrondissement`, `ressorteert` FROM `Arrondissement` WHERE `Arrondissement` IS NOT NULL AND `ressorteert` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ressort[Gerechtshof*Ressort]","SELECT DISTINCT `Gerechtshof`, `ressort` FROM `Orgaan` WHERE `Gerechtshof` IS NOT NULL AND `ressort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("neven[Plaats*Rechtbank]","SELECT DISTINCT `Plaats`, `neven` FROM `Plaats` WHERE `Plaats` IS NOT NULL AND `neven` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechtsgebied[Rechtbank*Arrondissement]","SELECT DISTINCT `Rechtbank`, `Arrondissement` FROM `rechtsgebied1` WHERE `Rechtbank` IS NOT NULL AND `Arrondissement` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechtsgebied[Gerechtshof*Ressort]","SELECT DISTINCT `Gerechtshof`, `Ressort` FROM `rechtsgebied2` WHERE `Gerechtshof` IS NOT NULL AND `Ressort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ressorteertHGK[Arrondissement*Ressort]","SELECT DISTINCT `Arrondissement`, `Ressort` FROM `ressorteertHGK` WHERE `Arrondissement` IS NOT NULL AND `Ressort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaVoornamen[NatuurlijkPersoon*Voornamen]","SELECT DISTINCT `NatuurlijkPersoon`, `Voornamen` FROM `gbaVoornamen` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Voornamen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaGeslachtsnaam[NatuurlijkPersoon*Geslachtsnaam]","SELECT DISTINCT `NatuurlijkPersoon`, `Geslachtsnaam` FROM `gbaGeslachtsnaam` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Geslachtsnaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gbaBSN[NatuurlijkPersoon*BurgerServiceNummer]","SELECT DISTINCT `NatuurlijkPersoon`, `gbaBSN` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `gbaBSN` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adelijketitel[Titel*NatuurlijkPersoon]","SELECT DISTINCT `Titel`, `NatuurlijkPersoon` FROM `adelijketitel` WHERE `Titel` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("opleidingstitel[Titel*NatuurlijkPersoon]","SELECT DISTINCT `Titel`, `NatuurlijkPersoon` FROM `opleidingstitel` WHERE `Titel` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboortedatum[NatuurlijkPersoon*Datum]","SELECT DISTINCT `NatuurlijkPersoon`, `geboortedatum` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `geboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteplaats[NatuurlijkPersoon*Plaats]","SELECT DISTINCT `NatuurlijkPersoon`, `geboorteplaats` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `geboorteplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteland[NatuurlijkPersoon*Land]","SELECT DISTINCT `NatuurlijkPersoon`, `geboorteland` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `geboorteland` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaats[NatuurlijkPersoon*Adres]","SELECT DISTINCT `NatuurlijkPersoon`, `woonplaats` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `woonplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geslacht[NatuurlijkPersoon*Geslacht]","SELECT DISTINCT `NatuurlijkPersoon`, `geslacht` FROM `NatuurlijkPersoon` WHERE `NatuurlijkPersoon` IS NOT NULL AND `geslacht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gba[Anummer*NatuurlijkPersoon]","SELECT DISTINCT `Anummer`, `gba` FROM `Anummer` WHERE `Anummer` IS NOT NULL AND `gba` IS NOT NULL"));
      fwrite($dumpfile, dumprel("nationaliteit[NatuurlijkPersoon*Nationaliteit]","SELECT DISTINCT `NatuurlijkPersoon`, `Nationaliteit` FROM `nationaliteit2` WHERE `NatuurlijkPersoon` IS NOT NULL AND `Nationaliteit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaaksdossier[Dossier*Zaakid]","SELECT DISTINCT `Dossier`, `Zaakid` FROM `zaaksdossier` WHERE `Dossier` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaakstuk[Document*Dossier]","SELECT DISTINCT `Document`, `Dossier` FROM `zaakstuk` WHERE `Document` IS NOT NULL AND `Dossier` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaaksdocument[Document*Zaakid]","SELECT DISTINCT `Document`, `Zaakid` FROM `zaaksdocument` WHERE `Document` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("type[Document*Zaakstuktype]","SELECT DISTINCT `Document`, `Zaakstuktype` FROM `type` WHERE `Document` IS NOT NULL AND `Zaakstuktype` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inhoud[Document*Object]","SELECT DISTINCT `Document`, `Object` FROM `inhoud` WHERE `Document` IS NOT NULL AND `Object` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ontstaan[Document*Gebeurtenis]","SELECT DISTINCT `Document`, `Gebeurtenis` FROM `ontstaan` WHERE `Document` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zorgdrager[Dossier*Orgaan]","SELECT DISTINCT `Dossier`, `Orgaan` FROM `zorgdrager` WHERE `Dossier` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("doc[Bericht*Document]","SELECT DISTINCT `Bericht`, `doc` FROM `Gebeurtenis` WHERE `Bericht` IS NOT NULL AND `doc` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ingevoegd[Gebeurtenis*Document]","SELECT DISTINCT `Gebeurtenis`, `Document` FROM `ingevoegd` WHERE `Gebeurtenis` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("afgedrukt[Document*Gebeurtenis]","SELECT DISTINCT `Document`, `Gebeurtenis` FROM `afgedrukt` WHERE `Document` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("over[Document*NatuurlijkPersoon]","SELECT DISTINCT `Document`, `NatuurlijkPersoon` FROM `over` WHERE `Document` IS NOT NULL AND `NatuurlijkPersoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("neerslag[Document*Gebeurtenis]","SELECT DISTINCT `Document`, `Gebeurtenis` FROM `neerslag` WHERE `Document` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("handeling[Gebeurtenis*Handeling]","SELECT DISTINCT `Gebeurtenis`, `handeling` FROM `Gebeurtenis` WHERE `Gebeurtenis` IS NOT NULL AND `handeling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omschrijving[Handeling*Tekst]","SELECT DISTINCT `Handeling`, `omschrijving` FROM `Handeling` WHERE `Handeling` IS NOT NULL AND `omschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bron[Handeling*Tekst]","SELECT DISTINCT `Handeling`, `bron` FROM `Handeling` WHERE `Handeling` IS NOT NULL AND `bron` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rIOhandeling[Handeling*RIO handeling]","SELECT DISTINCT `Handeling`, `RIO handeling` FROM `rIOhandeling` WHERE `Handeling` IS NOT NULL AND `RIO handeling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("opmerking[Handeling*Tekst]","SELECT DISTINCT `Handeling`, `opmerking` FROM `Handeling` WHERE `Handeling` IS NOT NULL AND `opmerking` IS NOT NULL"));
      fwrite($dumpfile, dumprel("product[Handeling*Tekst]","SELECT DISTINCT `Handeling`, `product` FROM `Handeling` WHERE `Handeling` IS NOT NULL AND `product` IS NOT NULL"));
      fwrite($dumpfile, dumprel("criterium[Handeling*Selectiecriterium]","SELECT DISTINCT `Handeling`, `Selectiecriterium` FROM `criterium` WHERE `Handeling` IS NOT NULL AND `Selectiecriterium` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tekst[Selectiecriterium*Tekst]","SELECT DISTINCT `Selectiecriterium`, `tekst` FROM `Selectiecriterium` WHERE `Selectiecriterium` IS NOT NULL AND `tekst` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vernietigingstermijn[Handeling*Vernietigingstermijn]","SELECT DISTINCT `Handeling`, `vernietigingstermijn` FROM `Handeling` WHERE `Handeling` IS NOT NULL AND `vernietigingstermijn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("categorie[Handeling*Categorie]","SELECT DISTINCT `Handeling`, `categorie` FROM `Handeling` WHERE `Handeling` IS NOT NULL AND `categorie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("actor[Handeling*Actor]","SELECT DISTINCT `Handeling`, `actor` FROM `Handeling` WHERE `Handeling` IS NOT NULL AND `actor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("waardering[Handeling*Waardering]","SELECT DISTINCT `Handeling`, `Waardering` FROM `waardering2` WHERE `Handeling` IS NOT NULL AND `Waardering` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatie[Gebeurtenis*Plaats]","SELECT DISTINCT `Gebeurtenis`, `Plaats` FROM `locatie` WHERE `Gebeurtenis` IS NOT NULL AND `Plaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("datum[Gebeurtenis*Datum]","SELECT DISTINCT `Gebeurtenis`, `Datum` FROM `datum2` WHERE `Gebeurtenis` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ouder[Gebeurtenis]","SELECT DISTINCT `sGebeurtenis`, `tGebeurtenis` FROM `ouder` WHERE `sGebeurtenis` IS NOT NULL AND `tGebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("motivering[SchriftelijkeUitspraak*Tekst]","SELECT DISTINCT `SchriftelijkeUitspraak`, `motivering` FROM `SchriftelijkeUitspraak` WHERE `SchriftelijkeUitspraak` IS NOT NULL AND `motivering` IS NOT NULL"));
      fwrite($dumpfile, dumprel("plandatum[SchriftelijkeUitspraak*Datum]","SELECT DISTINCT `SchriftelijkeUitspraak`, `Datum` FROM `plandatum` WHERE `SchriftelijkeUitspraak` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("eindbeslissing[SchriftelijkeUitspraak*Document]","SELECT DISTINCT `SchriftelijkeUitspraak`, `Document` FROM `eindbeslissing` WHERE `SchriftelijkeUitspraak` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vonnis[SchriftelijkeUitspraak*Zaakid]","SELECT DISTINCT `SchriftelijkeUitspraak`, `Zaakid` FROM `vonnis` WHERE `SchriftelijkeUitspraak` IS NOT NULL AND `Zaakid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beslissing[SchriftelijkeUitspraak*Beslissing]","SELECT DISTINCT `SchriftelijkeUitspraak`, `Beslissing` FROM `beslissing2` WHERE `SchriftelijkeUitspraak` IS NOT NULL AND `Beslissing` IS NOT NULL"));
      fwrite($dumpfile, dumprel("wijzen[SchriftelijkeUitspraak*Rechter]","SELECT DISTINCT `SchriftelijkeUitspraak`, `Rechter` FROM `wijzen` WHERE `SchriftelijkeUitspraak` IS NOT NULL AND `Rechter` IS NOT NULL"));
      fwrite($dumpfile, dumprel("wijsdatum[SchriftelijkeUitspraak*Datum]","SELECT DISTINCT `SchriftelijkeUitspraak`, `Datum` FROM `wijsdatum` WHERE `SchriftelijkeUitspraak` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vertegenwoordiger[Vertegenwoordiging*Advocaat]","SELECT DISTINCT `Vertegenwoordiging`, `vertegenwoordiger` FROM `Vertegenwoordiging` WHERE `Vertegenwoordiging` IS NOT NULL AND `vertegenwoordiger` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inzake[Vertegenwoordiging*Zaak]","SELECT DISTINCT `Vertegenwoordiging`, `inzake` FROM `Vertegenwoordiging` WHERE `Vertegenwoordiging` IS NOT NULL AND `inzake` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vertegenwoordigt[Vertegenwoordiging*NatuurlijkPersoon]","SELECT DISTINCT `Vertegenwoordiging`, `vertegenwoordigt` FROM `Vertegenwoordiging` WHERE `Vertegenwoordiging` IS NOT NULL AND `vertegenwoordigt` IS NOT NULL"));
      fwrite($dumpfile, dumprel("machtiging[Vertegenwoordiging*Bformulier]","SELECT DISTINCT `Vertegenwoordiging`, `machtiging` FROM `Vertegenwoordiging` WHERE `Vertegenwoordiging` IS NOT NULL AND `machtiging` IS NOT NULL"));
      fwrite($dumpfile, dumprel("door[Bformulier*Advocaat]","SELECT DISTINCT `Bformulier`, `door` FROM `Bformulier` WHERE `Bformulier` IS NOT NULL AND `door` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionGebruikersnaam[SESSION*Rechternaam]","SELECT DISTINCT `SESSION`, `sessionGebruikersnaam` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionGebruikersnaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionWachtwoord[SESSION*Wachtwoord]","SELECT DISTINCT `SESSION`, `sessionWachtwoord` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionWachtwoord` IS NOT NULL"));
      fwrite($dumpfile, dumprel("wachtwoord[Rechter*Wachtwoord]","SELECT DISTINCT `Rechter`, `Wachtwoord` FROM `wachtwoord2` WHERE `Rechter` IS NOT NULL AND `Wachtwoord` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer($quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
