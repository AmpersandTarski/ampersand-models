
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT PersoonsgegevensDemo\n");
      fwrite($dumpfile, dumprel("naam[Persoon*Naam]","SELECT DISTINCT `naam1`, `Naam0` FROM `Naam` WHERE `naam1` IS NOT NULL AND `Naam0` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bsn[Persoon*Burgerservicenummer]","SELECT DISTINCT `naam1`, `bsn` FROM `Naam` WHERE `naam1` IS NOT NULL AND `bsn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adelijketitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `adelijketitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("opleidingstitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `opleidingstitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboortedatum[Persoon*Datum]","SELECT DISTINCT `naam1`, `geboortedatum` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteplaats[Persoon*Plaats]","SELECT DISTINCT `naam1`, `geboorteplaats` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboorteplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteland[Persoon*Land]","SELECT DISTINCT `naam1`, `geboorteland` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboorteland` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaats[Persoon*Adres]","SELECT DISTINCT `naam1`, `woonplaats` FROM `Naam` WHERE `naam1` IS NOT NULL AND `woonplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geslacht[Persoon*Geslacht]","SELECT DISTINCT `naam1`, `geslacht` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geslacht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gba[Gbanummer*Persoon]","SELECT DISTINCT `Gbanummer`, `gba` FROM `Gbanummer` WHERE `Gbanummer` IS NOT NULL AND `gba` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("persoonsgegevensdemo", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\"",$str); }
      ?>