<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass elsewhere
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('persoonsgegevensdemo')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `persoonsgegevensdemo` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('persoonsgegevensdemo');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'persoonsgegevensdemo'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
      }
      mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                          ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 11
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `Naam`")){
        mysql_query("DROP TABLE `Naam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gbanummer`")){
        mysql_query("DROP TABLE `Gbanummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Geslacht`")){
        mysql_query("DROP TABLE `Geslacht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Adres`")){
        mysql_query("DROP TABLE `Adres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Land`")){
        mysql_query("DROP TABLE `Land`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Plaats`")){
        mysql_query("DROP TABLE `Plaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Datum`")){
        mysql_query("DROP TABLE `Datum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Titel`")){
        mysql_query("DROP TABLE `Titel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Burgerservicenummer`")){
        mysql_query("DROP TABLE `Burgerservicenummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `adelijketitel`")){
        mysql_query("DROP TABLE `adelijketitel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `opleidingstitel`")){
        mysql_query("DROP TABLE `opleidingstitel`");
      }
    }
    /**************************************\
    * Plug Naam                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * naam~  [UNI,INJ,SUR]                 *
    * bsn  [UNI,TOT]                       *
    * geboortedatum  [TOT,UNI]             *
    * geboorteplaats  [TOT,UNI]            *
    * geboorteland  [TOT,UNI]              *
    * woonplaats  [TOT,UNI]                *
    * geslacht  [TOT,UNI]                  *
    \**************************************/
    mysql_query("CREATE TABLE `Naam`
                     ( `Naam0` VARCHAR(255) DEFAULT NULL
                     , `naam1` VARCHAR(255) DEFAULT NULL
                     , `bsn` VARCHAR(255) DEFAULT NULL
                     , `geboortedatum` VARCHAR(255) DEFAULT NULL
                     , `geboorteplaats` VARCHAR(255) DEFAULT NULL
                     , `geboorteland` VARCHAR(255) DEFAULT NULL
                     , `woonplaats` VARCHAR(255) DEFAULT NULL
                     , `geslacht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Naam` (`Naam0` ,`naam1` ,`bsn` ,`geboortedatum` ,`geboorteplaats` ,`geboorteland` ,`woonplaats` ,`geslacht` )
                VALUES ('Peter Jansen', '1', '23587435', '12-10-1967', 'Middelburg', 'Nederland', 'Noordbolwerk 33, 4331SH Middelburg', 'Man')
                      , ('Eman Pietersen', '2', '56327491', '06-07-1980', 'Veghel', 'Nederland', 'Westhavenkade 98, 3133AV Vlaardingen', 'Man')
                      , ('Ola Sigursson', '3', '78954566', '31-02-1970', 'Stockholm', 'Zweden', 'Koornbeursweg 132, 8442DJ Heerenveen', 'Man')
                      , ('Sebastiaan Levelt', '4', '14676455', '25-03-1962', 'Amsterdam', 'Nederland', 'Johannes Verhulststraat 55/HS, 1071MS Amsterdam', 'Man')
                      , ('Ilja van Driel', '5', '58974564', '01-05-1982', 'Tilburg', 'Nederland', 'Kruisherenstraat 56, 3078GT Rotterdam', 'Man')
                      , ('Anne Dekkers', '6', '15876456', '16-07-1976', 'Spijkenisse', 'Nederland', 'Gezichtslaan 52, 3723GG Bilthoven', 'Vrouw')
                      , ('Lonneke Cox', '7', '45896541', '12-11-1981', 'Haps', 'Nederland', 'Kalkhofseweg 25, 5443NB Haps', 'Vrouw')
                      , ('Sascha Guillaume', '8', '56975633', '12-01-1959', 'Enschede', 'Nederland', 'Weldammerbos 17, 7543GW Enschede', 'Man')
                      , ('Hendrik Pieter Cornelis van de Meene', '9', '62096541', '25-02-1948', 'Heerenveen', 'Nederland', 'Koornbeursweg 132, 8442DJ Heerenveen', 'Man')
                      , ('Sandra Anne Wiltschut', '10', '45031741', '30-12-1955', 'Utrecht', 'Nederland', 'Zeedijken 42, 9919BM Loppersum', 'Vrouw')
                      , ('Roeland Petrus Dijkstra', '11', '72896694', '04-07-1965', 'Arnhem', 'Nederland', 'Erve Kokenberg 1, 7625NH Zenderen', 'Man')
                      , ('Frits Audeur', '12', '63254896', '25-04-1975', 'Zwijndrecht', 'Nederland', 'Heimerstein 91, 3328MH Dordrecht', 'Man')
                      , ('Bert Stolen', '13', '45896310', '03-05-1980', '\'s-Gravenhage', 'Nederland', 'Thorbeckelaan 342, 2564BZ \'s-Gravenhage', 'Man')
                      , ('Olaf Elicht', '14', '35497763', '10-12-1968', 'Zenderen', 'Nederland', 'Erve Kokenberg 1, 7625NH Zenderen', 'Man')
                      , ('Barend Eul', '15', '79823438', '27-11-1976', 'Almelo', 'Nederland', 'Bornsestraat 28, 7556BG Hengelo ov', 'Man')
                      , ('Tomas Sjesdief', '16', '46936557', '30-06-1984', 'Ittersum', 'Nederland', 'Zeedijken 42, 9919BM Loppersum', 'Man')
                      , ('Andre Angereden', '17', '49876337', '15-02-1989', 'Heerenveen', 'Nederland', 'Hooizolder 386, 9205CW Drachten', 'Man')
                      , ('Sanne Verhoeven', '18', '78974651', '26-05-1980', 'Almelo', 'Nederland', 'Westhavenkade 98, 3133AV Vlaardingen', 'Vrouw')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gbanummer                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * gba  [UNI,TOT]                       *
    \**************************************/
    mysql_query("CREATE TABLE `Gbanummer`
                     ( `Gbanummer` VARCHAR(255) DEFAULT NULL
                     , `gba` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gbanummer` (`Gbanummer` ,`gba` )
                VALUES ('A1567845614', '1')
                      , ('A4587623462', '2')
                      , ('A3265123987', '3')
                      , ('A2598776542', '4')
                      , ('A5687765231', '5')
                      , ('A1002546886', '6')
                      , ('A6740656461', '7')
                      , ('A6547890374', '8')
                      , ('A1149890396', '9')
                      , ('A6539590322', '10')
                      , ('A3211890374', '11')
                      , ('A6565119819', '12')
                      , ('A5216056127', '13')
                      , ('A6131546842', '14')
                      , ('A1551215379', '15')
                      , ('A1168773213', '16')
                      , ('A1447945463', '7')
                      , ('A8374764583', '18')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Geslacht                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Geslacht`
                     ( `Geslacht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Geslacht` (`Geslacht` )
                VALUES ('Man')
                      , ('Vrouw')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Adres                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Adres`
                     ( `Adres` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Adres` (`Adres` )
                VALUES ('Noordbolwerk 33, 4331SH Middelburg')
                      , ('Westhavenkade 98, 3133AV Vlaardingen')
                      , ('Koornbeursweg 132, 8442DJ Heerenveen')
                      , ('Johannes Verhulststraat 55/HS, 1071MS Amsterdam')
                      , ('Kruisherenstraat 56, 3078GT Rotterdam')
                      , ('Gezichtslaan 52, 3723GG Bilthoven')
                      , ('Kalkhofseweg 25, 5443NB Haps')
                      , ('Weldammerbos 17, 7543GW Enschede')
                      , ('Zeedijken 42, 9919BM Loppersum')
                      , ('Erve Kokenberg 1, 7625NH Zenderen')
                      , ('Heimerstein 91, 3328MH Dordrecht')
                      , ('Thorbeckelaan 342, 2564BZ \'s-Gravenhage')
                      , ('Bornsestraat 28, 7556BG Hengelo ov')
                      , ('Hooizolder 386, 9205CW Drachten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Land                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Land`
                     ( `Land` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Land` (`Land` )
                VALUES ('Nederland')
                      , ('Zweden')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Plaats                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Plaats`
                     ( `Plaats` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Plaats` (`Plaats` )
                VALUES ('Middelburg')
                      , ('Veghel')
                      , ('Stockholm')
                      , ('Amsterdam')
                      , ('Tilburg')
                      , ('Spijkenisse')
                      , ('Haps')
                      , ('Enschede')
                      , ('Heerenveen')
                      , ('Utrecht')
                      , ('Arnhem')
                      , ('Zwijndrecht')
                      , ('\'s-Gravenhage')
                      , ('Zenderen')
                      , ('Almelo')
                      , ('Ittersum')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Datum                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Datum`
                     ( `Datum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Datum` (`Datum` )
                VALUES ('12-10-1967')
                      , ('06-07-1980')
                      , ('31-02-1970')
                      , ('25-03-1962')
                      , ('01-05-1982')
                      , ('16-07-1976')
                      , ('12-11-1981')
                      , ('12-01-1959')
                      , ('25-02-1948')
                      , ('30-12-1955')
                      , ('04-07-1965')
                      , ('25-04-1975')
                      , ('03-05-1980')
                      , ('10-12-1968')
                      , ('27-11-1976')
                      , ('30-06-1984')
                      , ('15-02-1989')
                      , ('26-05-1980')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Titel                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Titel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Titel` (`Titel` )
                VALUES ('Baron')
                      , ('mr')
                      , ('drs')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Burgerservicenummer             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Burgerservicenummer`
                     ( `Burgerservicenummer` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Burgerservicenummer` (`Burgerservicenummer` )
                VALUES ('23587435')
                      , ('56327491')
                      , ('78954566')
                      , ('14676455')
                      , ('58974564')
                      , ('15876456')
                      , ('45896541')
                      , ('56975633')
                      , ('62096541')
                      , ('45031741')
                      , ('72896694')
                      , ('63254896')
                      , ('45896310')
                      , ('35497763')
                      , ('79823438')
                      , ('46936557')
                      , ('49876337')
                      , ('78974651')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug adelijketitel                     *
    *                                        *
    * fields:                                *
    * I/\adelijketitel;adelijketitel~  [ASY] *
    * adelijketitel  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `adelijketitel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `adelijketitel` (`Titel` ,`Persoon` )
                VALUES ('Baron', '1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************\
    * Plug opleidingstitel                       *
    *                                            *
    * fields:                                    *
    * I/\opleidingstitel;opleidingstitel~  [ASY] *
    * opleidingstitel  []                        *
    \********************************************/
    mysql_query("CREATE TABLE `opleidingstitel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `opleidingstitel` (`Titel` ,`Persoon` )
                VALUES ('mr', '4')
                      , ('mr', '5')
                      , ('mr', '6')
                      , ('mr', '7')
                      , ('mr', '8')
                      , ('drs', '18')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo 'The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT PersoonsgegevensDemo\n");
      fwrite($dumpfile, dumprel("naam[Persoon*Naam]","SELECT DISTINCT `naam1`, `Naam0` FROM `Naam` WHERE `naam1` IS NOT NULL AND `Naam0` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bsn[Persoon*Burgerservicenummer]","SELECT DISTINCT `naam1`, `bsn` FROM `Naam` WHERE `naam1` IS NOT NULL AND `bsn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adelijketitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `adelijketitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("opleidingstitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `opleidingstitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboortedatum[Persoon*Datum]","SELECT DISTINCT `naam1`, `geboortedatum` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteplaats[Persoon*Plaats]","SELECT DISTINCT `naam1`, `geboorteplaats` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboorteplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteland[Persoon*Land]","SELECT DISTINCT `naam1`, `geboorteland` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboorteland` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaats[Persoon*Adres]","SELECT DISTINCT `naam1`, `woonplaats` FROM `Naam` WHERE `naam1` IS NOT NULL AND `woonplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geslacht[Persoon*Geslacht]","SELECT DISTINCT `naam1`, `geslacht` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geslacht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gba[Gbanummer*Persoon]","SELECT DISTINCT `Gbanummer`, `gba` FROM `Gbanummer` WHERE `Gbanummer` IS NOT NULL AND `gba` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("persoonsgegevensdemo", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
