<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass elsewhere
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('registerdemo')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `registerdemo` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('registerdemo');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'registerdemo'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
      }
      mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                          ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 59
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `Gebeurtenis`")){
        mysql_query("DROP TABLE `Gebeurtenis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Naam`")){
        mysql_query("DROP TABLE `Naam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kamer`")){
        mysql_query("DROP TABLE `Kamer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kantoornummer`")){
        mysql_query("DROP TABLE `Kantoornummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `behandeling`")){
        mysql_query("DROP TABLE `behandeling`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gerecht`")){
        mysql_query("DROP TABLE `Gerecht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zaak`")){
        mysql_query("DROP TABLE `Zaak`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gbanummer`")){
        mysql_query("DROP TABLE `Gbanummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Plaats`")){
        mysql_query("DROP TABLE `Plaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Rechtbank`")){
        mysql_query("DROP TABLE `Rechtbank`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijvingsverzoek`")){
        mysql_query("DROP TABLE `Inschrijvingsverzoek`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Sector`")){
        mysql_query("DROP TABLE `Sector`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Sluiting`")){
        mysql_query("DROP TABLE `Sluiting`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schorsing1`")){
        mysql_query("DROP TABLE `schorsing1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Schorsing2`")){
        mysql_query("DROP TABLE `Schorsing2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schorsing3`")){
        mysql_query("DROP TABLE `schorsing3`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Tot`")){
        mysql_query("DROP TABLE `Tot`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Van`")){
        mysql_query("DROP TABLE `Van`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Griffier`")){
        mysql_query("DROP TABLE `Griffier`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Rechter1`")){
        mysql_query("DROP TABLE `Rechter1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `rechter2`")){
        mysql_query("DROP TABLE `rechter2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Document`")){
        mysql_query("DROP TABLE `Document`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Rolzitting1`")){
        mysql_query("DROP TABLE `Rolzitting1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `rolzitting2`")){
        mysql_query("DROP TABLE `rolzitting2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Geslacht`")){
        mysql_query("DROP TABLE `Geslacht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Land`")){
        mysql_query("DROP TABLE `Land`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Datum`")){
        mysql_query("DROP TABLE `Datum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Titel`")){
        mysql_query("DROP TABLE `Titel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Burgerservicenummer`")){
        mysql_query("DROP TABLE `Burgerservicenummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zoek`")){
        mysql_query("DROP TABLE `Zoek`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Adres`")){
        mysql_query("DROP TABLE `Adres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kantoor`")){
        mysql_query("DROP TABLE `Kantoor`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Orgaan`")){
        mysql_query("DROP TABLE `Orgaan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Schrapping`")){
        mysql_query("DROP TABLE `Schrapping`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijvingseis1`")){
        mysql_query("DROP TABLE `Inschrijvingseis1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `inschrijvingseis2`")){
        mysql_query("DROP TABLE `inschrijvingseis2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Barnummer`")){
        mysql_query("DROP TABLE `Barnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijvingsstatus1`")){
        mysql_query("DROP TABLE `Inschrijvingsstatus1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `inschrijvingsstatus2`")){
        mysql_query("DROP TABLE `inschrijvingsstatus2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `kantoorVerzoek`")){
        mysql_query("DROP TABLE `kantoorVerzoek`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `isVerstuurdDoor`")){
        mysql_query("DROP TABLE `isVerstuurdDoor`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schrappingDoor1`")){
        mysql_query("DROP TABLE `schrappingDoor1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schrappingDoor2`")){
        mysql_query("DROP TABLE `schrappingDoor2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schrappingVan`")){
        mysql_query("DROP TABLE `schrappingVan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `houdtkantoor`")){
        mysql_query("DROP TABLE `houdtkantoor`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schorsingVan`")){
        mysql_query("DROP TABLE `schorsingVan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zoeken`")){
        mysql_query("DROP TABLE `zoeken`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zoekOpNaam`")){
        mysql_query("DROP TABLE `zoekOpNaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zoekOpBAR`")){
        mysql_query("DROP TABLE `zoekOpBAR`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `adelijketitel`")){
        mysql_query("DROP TABLE `adelijketitel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `opleidingstitel`")){
        mysql_query("DROP TABLE `opleidingstitel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ouder`")){
        mysql_query("DROP TABLE `ouder`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `tolk`")){
        mysql_query("DROP TABLE `tolk`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `getuige`")){
        mysql_query("DROP TABLE `getuige`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `bewijsstuk`")){
        mysql_query("DROP TABLE `bewijsstuk`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `geschorst`")){
        mysql_query("DROP TABLE `geschorst`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `gesloten`")){
        mysql_query("DROP TABLE `gesloten`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `bevoegd`")){
        mysql_query("DROP TABLE `bevoegd`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `hoofdplaatsrechtbank`")){
        mysql_query("DROP TABLE `hoofdplaatsrechtbank`");
      }
    }
    /**************************************\
    * Plug Gebeurtenis                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * Beëdiging~  [INJ,SUR,UNI]            *
    * Zitting~  [INJ,SUR,UNI]              *
    * isBeëdigd  [TOT,UNI]                 *
    * locatieBeëdiging  [TOT,UNI]          *
    * locatie  [UNI,TOT]                   *
    * datum  [UNI,TOT]                     *
    * kamer  [UNI,TOT]                     *
    * griffier  [TOT,UNI]                  *
    * geagendeerd  [UNI,TOT]               *
    * rechtbankhoudt  [UNI,TOT]            *
    * behoortBij~  [TOT,UNI]               *
    \**************************************/
    mysql_query("CREATE TABLE `Gebeurtenis`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Beëdiging` VARCHAR(255) DEFAULT NULL
                     , `Zitting` VARCHAR(255) DEFAULT NULL
                     , `isBeëdigd` VARCHAR(255) DEFAULT NULL
                     , `locatieBeëdiging` VARCHAR(255) DEFAULT NULL
                     , `locatie` VARCHAR(255) DEFAULT NULL
                     , `datum` VARCHAR(255) DEFAULT NULL
                     , `kamer` VARCHAR(255) DEFAULT NULL
                     , `griffier` VARCHAR(255) DEFAULT NULL
                     , `geagendeerd` VARCHAR(255) DEFAULT NULL
                     , `rechtbankhoudt` VARCHAR(255) DEFAULT NULL
                     , `behoortBij` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gebeurtenis` (`Gebeurtenis` ,`Beëdiging` ,`Zitting` ,`isBeëdigd` ,`locatieBeëdiging` ,`locatie` ,`datum` ,`kamer` ,`griffier` ,`geagendeerd` ,`rechtbankhoudt` ,`behoortBij` )
                VALUES ('Be1', 'Be1', NULL, '4', 'Rechtbank Amsterdam', 'Amsterdam', '25-08-1990', NULL, NULL, NULL, NULL, 'Vvi1')
                      , ('Be2', 'Be2', NULL, '5', 'Rechtbank Rotterdam', 'Rotterdam', '12-02-2009', NULL, NULL, NULL, NULL, 'Vvi2')
                      , ('Be3', 'Be3', NULL, '6', 'Rechtbank Utrecht', 'Utrecht', '06-10-2007', NULL, NULL, NULL, NULL, 'Vvi3')
                      , ('Be4', 'Be4', NULL, '7', 'Rechtbank Utrecht', 'Utrecht', '18-04-2009', NULL, NULL, NULL, NULL, 'Vvi4')
                      , ('Ev739920', NULL, NULL, NULL, NULL, '\'s-Gravenhage', '23-05-2011', NULL, NULL, NULL, NULL, NULL)
                      , ('Ev930023', NULL, NULL, NULL, NULL, 'Leeuwarden', '03-12-2010', NULL, NULL, NULL, NULL, NULL)
                      , ('Ev456188', NULL, NULL, NULL, NULL, 'Almelo', '12-09-2011', NULL, NULL, NULL, NULL, NULL)
                      , ('Ev695', NULL, NULL, NULL, NULL, '\'s-Gravenhage', '24-05-2011', NULL, NULL, NULL, NULL, NULL)
                      , ('Ev426', NULL, NULL, NULL, NULL, 'Leeuwarden', '06-12-2010', NULL, NULL, NULL, NULL, NULL)
                      , ('Ev336', NULL, NULL, NULL, NULL, 'Almelo', '12-09-2011', NULL, NULL, NULL, NULL, NULL)
                      , ('Ev732491', NULL, NULL, NULL, NULL, '\'s-Gravenhage', '23-07-2011', NULL, NULL, NULL, NULL, NULL)
                      , ('Ev993123', NULL, NULL, NULL, NULL, 'Groningen', '12-12-2010', NULL, NULL, NULL, NULL, NULL)
                      , ('Ev476228', NULL, NULL, NULL, NULL, 'Enschede', '03-10-2011', NULL, NULL, NULL, NULL, NULL)
                      , ('Zitting RbsGr 35', NULL, 'Zitting RbsGr 35', NULL, NULL, '\'s-Gravenhage', '23-05-2011', 'Enkelvoudige kamer van de sector Civiel Recht van de Rechtbank \'s-Gravenhage', 'mr. C.C. de Rijke-Maas', '23-05-2011', 'Rechtbank \'s-Gravenhage', NULL)
                      , ('Zitting RbLee 591', NULL, 'Zitting RbLee 591', NULL, NULL, 'Leeuwarden', '03-12-2010', 'Meervoudige kamer van de sector Strafrecht van de Rechtbank Leeuwarden', 'mr. G.M. Fondse', '03-12-2010', 'Rechtbank Leeuwarden', NULL)
                      , ('Zitting RbAlm 68', NULL, 'Zitting RbAlm 68', NULL, NULL, 'Almelo', '12-09-2011', 'Enkelvoudige kamer van de sector Strafrecht van de Rechtbank Almelo', 'mr. B.M. Hoek', '12-09-2011', 'Rechtbank Almelo', NULL)
                      , ('Msg598', NULL, NULL, NULL, NULL, '\'s-Gravenhage', '24-05-2011', NULL, NULL, NULL, NULL, NULL)
                      , ('Msg449', NULL, NULL, NULL, NULL, 'Leeuwarden', '06-12-2010', NULL, NULL, NULL, NULL, NULL)
                      , ('Msg779', NULL, NULL, NULL, NULL, 'Almelo', '12-09-2011', NULL, NULL, NULL, NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Naam                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * naam~  [UNI,INJ,SUR]                 *
    * advocaatnaam~  [SUR,INJ,UNI]         *
    * barnummer  [UNI,TOT]                 *
    * bsn  [UNI,TOT]                       *
    * geboortedatum  [TOT,UNI]             *
    * geboorteplaats  [TOT,UNI]            *
    * geboorteland  [TOT,UNI]              *
    * woonplaats  [TOT,UNI]                *
    * geslacht  [TOT,UNI]                  *
    \**************************************/
    mysql_query("CREATE TABLE `Naam`
                     ( `Naam0` VARCHAR(255) DEFAULT NULL
                     , `naam1` VARCHAR(255) DEFAULT NULL
                     , `advocaatnaam` VARCHAR(255) DEFAULT NULL
                     , `barnummer` VARCHAR(255) DEFAULT NULL
                     , `bsn` VARCHAR(255) DEFAULT NULL
                     , `geboortedatum` VARCHAR(255) DEFAULT NULL
                     , `geboorteplaats` VARCHAR(255) DEFAULT NULL
                     , `geboorteland` VARCHAR(255) DEFAULT NULL
                     , `woonplaats` VARCHAR(255) DEFAULT NULL
                     , `geslacht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Naam` (`Naam0` ,`naam1` ,`advocaatnaam` ,`barnummer` ,`bsn` ,`geboortedatum` ,`geboorteplaats` ,`geboorteland` ,`woonplaats` ,`geslacht` )
                VALUES ('Peter Jansen', '1', NULL, NULL, '23587435', '12-10-1967', 'Middelburg', 'Nederland', 'Noordbolwerk 33, 4331SH Middelburg', 'Man')
                      , ('Eman Pietersen', '2', NULL, NULL, '56327491', '06-07-1980', 'Veghel', 'Nederland', 'Westhavenkade 98, 3133AV Vlaardingen', 'Man')
                      , ('Ola Sigursson', '3', NULL, NULL, '78954566', '31-02-1970', 'Stockholm', 'Zweden', 'Koornbeursweg 132, 8442DJ Heerenveen', 'Man')
                      , ('Sebastiaan Levelt', '4', '23968', 'A23968', '14676455', '25-03-1962', 'Amsterdam', 'Nederland', 'Johannes Verhulststraat 55/HS, 1071MS Amsterdam', 'Man')
                      , ('Ilja van Driel', '5', '26815', 'A26815', '58974564', '01-05-1982', 'Tilburg', 'Nederland', 'Kruisherenstraat 56, 3078GT Rotterdam', 'Man')
                      , ('Anne Dekkers', '6', '16378', 'A16378', '15876456', '16-07-1976', 'Spijkenisse', 'Nederland', 'Gezichtslaan 52, 3723GG Bilthoven', 'Vrouw')
                      , ('Lonneke Cox', '7', '24763', 'A24763', '45896541', '12-11-1981', 'Haps', 'Nederland', 'Kalkhofseweg 25, 5443NB Haps', 'Vrouw')
                      , ('Sascha Guillaume', '8', NULL, NULL, '56975633', '12-01-1959', 'Enschede', 'Nederland', 'Weldammerbos 17, 7543GW Enschede', 'Man')
                      , ('Hendrik Pieter Cornelis van de Meene', '9', NULL, NULL, '62096541', '25-02-1948', 'Heerenveen', 'Nederland', 'Koornbeursweg 132, 8442DJ Heerenveen', 'Man')
                      , ('Sandra Anne Wiltschut', '10', NULL, NULL, '45031741', '30-12-1955', 'Utrecht', 'Nederland', 'Zeedijken 42, 9919BM Loppersum', 'Vrouw')
                      , ('Roeland Petrus Dijkstra', '11', NULL, NULL, '72896694', '04-07-1965', 'Arnhem', 'Nederland', 'Erve Kokenberg 1, 7625NH Zenderen', 'Man')
                      , ('Frits Audeur', '12', NULL, NULL, '63254896', '25-04-1975', 'Zwijndrecht', 'Nederland', 'Heimerstein 91, 3328MH Dordrecht', 'Man')
                      , ('Bert Stolen', '13', NULL, NULL, '45896310', '03-05-1980', '\'s-Gravenhage', 'Nederland', 'Thorbeckelaan 342, 2564BZ \'s-Gravenhage', 'Man')
                      , ('Olaf Elicht', '14', NULL, NULL, '35497763', '10-12-1968', 'Zenderen', 'Nederland', 'Erve Kokenberg 1, 7625NH Zenderen', 'Man')
                      , ('Barend Eul', '15', NULL, NULL, '79823438', '27-11-1976', 'Almelo', 'Nederland', 'Bornsestraat 28, 7556BG Hengelo ov', 'Man')
                      , ('Tomas Sjesdief', '16', NULL, NULL, '46936557', '30-06-1984', 'Ittersum', 'Nederland', 'Zeedijken 42, 9919BM Loppersum', 'Man')
                      , ('Andre Angereden', '17', NULL, NULL, '49876337', '15-02-1989', 'Heerenveen', 'Nederland', 'Hooizolder 386, 9205CW Drachten', 'Man')
                      , ('Sanne Verhoeven', '18', NULL, NULL, '78974651', '26-05-1980', 'Almelo', 'Nederland', 'Westhavenkade 98, 3133AV Vlaardingen', 'Vrouw')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kamer                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * rechtbank  [UNI,TOT]                 *
    * gerecht  [UNI,TOT]                   *
    * sector  [UNI,TOT]                    *
    \**************************************/
    mysql_query("CREATE TABLE `Kamer`
                     ( `Kamer` VARCHAR(255) DEFAULT NULL
                     , `rechtbank` VARCHAR(255) DEFAULT NULL
                     , `gerecht` VARCHAR(255) DEFAULT NULL
                     , `sector` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kamer` (`Kamer` ,`rechtbank` ,`gerecht` ,`sector` )
                VALUES ('Vierde enkelvoudige kamer van de Rechtbank Amsterdam, sector Kanton', 'Rechtbank Amsterdam', 'Gerechtshof Amsterdam', 'Kanton')
                      , ('Enkelvoudige kamer van de Rechtbank Roermond, sector Kanton', 'Rechtbank Roermond', 'Gerechtshof \'s-Hertogenbosch', 'Kanton')
                      , ('Enkelvoudige kamer van de sector Bestuursrecht Algemeen van de Rechtbank Amsterdam', 'Rechtbank Amsterdam', 'Gerechtshof Amsterdam', 'Bestuursrecht')
                      , ('Kamer 2 afdeling bestuursrechtspraak van de Raad van State', 'Raad van State', 'Raad van State', 'Bestuursrecht')
                      , ('Enkelvoudige kamer van de sector Strafrecht van de Rechtbank Almelo', 'Rechtbank Almelo', 'Gerechtshof Arnhem', 'Straf')
                      , ('Meervoudige kamer van de sector Strafrecht van de Rechtbank Leeuwarden', 'Rechtbank Leeuwarden', 'Gerechtshof Leeuwarden', 'Straf')
                      , ('Enkelvoudige kamer van de sector Civiel Recht van de Rechtbank \'s-Gravenhage', 'Rechtbank \'s-Gravenhage', 'Gerechtshof \'s-Gravenhage', 'Civiel')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kantoornummer                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * kantoor  [UNI]                       *
    * kantoornaam  [UNI,TOT]               *
    * kantooradres  [UNI,TOT]              *
    \**************************************/
    mysql_query("CREATE TABLE `Kantoornummer`
                     ( `Kantoornummer` VARCHAR(255) DEFAULT NULL
                     , `kantoor` VARCHAR(255) DEFAULT NULL
                     , `kantoornaam` VARCHAR(255) DEFAULT NULL
                     , `kantooradres` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kantoornummer` (`Kantoornummer` ,`kantoor` ,`kantoornaam` ,`kantooradres` )
                VALUES ('K52347', 'Rechtbank Amsterdam', 'Wieringa advocaten', 'Herengracht 425-429, 1017 BR, Amsterdam')
                      , ('K45317', 'Rechtbank Rotterdam', 'Haulussy advocaten', 'Westblaak 5f, 3001 AC, Rotterdam')
                      , ('K48933', 'Rechtbank Utrecht', 'Kuipers, Jonkers, van den Berg', 'Mariahoek 4, 3511 LD, Utrecht')
                      , ('K12493', 'Rechtbank Utrecht', 'ATM Advocaten Utrecht', 'Herculesplein 213, 3584 AA, Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug behandeling                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * zaak  [UNI,TOT]                      *
    * procesverbaal  [UNI,TOT]             *
    \**************************************/
    mysql_query("CREATE TABLE `behandeling`
                     ( `behandeling` VARCHAR(255) DEFAULT NULL
                     , `zaak` VARCHAR(255) DEFAULT NULL
                     , `procesverbaal` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `behandeling` (`behandeling` ,`zaak` ,`procesverbaal` )
                VALUES ('11/123458 Enkelvoudige kamer van de sector Civiel Recht van de Rechtbank \'s-Gravenhage', 'Zitting RbsGr 35', 'Proc 11/123458')
                      , ('10/569423 Meervoudige kamer van de sector Strafrecht van de Rechtbank Leeuwarden', 'Zitting RbLee 591', 'Proc 10/569423')
                      , ('11/489631 Enkelvoudige kamer van de sector Strafrecht van de Rechtbank Almelo', 'Zitting RbAlm 68', 'Proc 11/489631')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gerecht                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * hoofdplaats  [UNI,TOT]               *
    \**************************************/
    mysql_query("CREATE TABLE `Gerecht`
                     ( `Gerecht` VARCHAR(255) DEFAULT NULL
                     , `hoofdplaats` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gerecht` (`Gerecht` ,`hoofdplaats` )
                VALUES ('Gerechtshof Amsterdam', 'Amsterdam')
                      , ('Gerechtshof Arnhem', 'Arnhem')
                      , ('Gerechtshof \'s-Gravenhage', '\'s-Gravenhage')
                      , ('Gerechtshof \'s-Hertogenbosch', 'Den Bosch')
                      , ('Gerechtshof Leeuwarden', 'Leeuwarden')
                      , ('Raad van State', 'Den Haag')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zaak                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * dient  [UNI]                         *
    \**************************************/
    mysql_query("CREATE TABLE `Zaak`
                     ( `Zaak` VARCHAR(255) DEFAULT NULL
                     , `dient` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zaak` (`Zaak` ,`dient` )
                VALUES ('10/569423', 'Zitting RbLee 591')
                      , ('11/123458', 'Zitting RbsGr 35')
                      , ('11/489631', 'Zitting RbAlm 68')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gbanummer                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * gba  [UNI,TOT]                       *
    \**************************************/
    mysql_query("CREATE TABLE `Gbanummer`
                     ( `Gbanummer` VARCHAR(255) DEFAULT NULL
                     , `gba` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gbanummer` (`Gbanummer` ,`gba` )
                VALUES ('A1567845614', '1')
                      , ('A4587623462', '2')
                      , ('A3265123987', '3')
                      , ('A2598776542', '4')
                      , ('A5687765231', '5')
                      , ('A1002546886', '6')
                      , ('A6740656461', '7')
                      , ('A6547890374', '8')
                      , ('A1149890396', '9')
                      , ('A6539590322', '10')
                      , ('A3211890374', '11')
                      , ('A6565119819', '12')
                      , ('A5216056127', '13')
                      , ('A6131546842', '14')
                      , ('A1551215379', '15')
                      , ('A1168773213', '16')
                      , ('A1447945463', '7')
                      , ('A8374764583', '18')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Plaats                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * neven  [UNI]                         *
    \**************************************/
    mysql_query("CREATE TABLE `Plaats`
                     ( `Plaats` VARCHAR(255) DEFAULT NULL
                     , `neven` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Plaats` (`Plaats` ,`neven` )
                VALUES ('Alkmaar', NULL)
                      , ('Almelo', NULL)
                      , ('Amsterdam', NULL)
                      , ('Arnhem', NULL)
                      , ('Groningen', NULL)
                      , ('Assen', NULL)
                      , ('Breda', NULL)
                      , ('Roermond', NULL)
                      , ('\'s-Gravenhage', NULL)
                      , ('Dordrecht', NULL)
                      , ('Haarlem', NULL)
                      , ('Leeuwarden', NULL)
                      , ('Maastricht', NULL)
                      , ('Middelburg', NULL)
                      , ('Rotterdam', NULL)
                      , ('Utrecht', NULL)
                      , ('Zutphen', NULL)
                      , ('Zwolle', NULL)
                      , ('Lelystad', 'Rechtbank Zwolle-Lelystad')
                      , ('Hoorn', 'Rechtbank Alkmaar')
                      , ('Enschede', 'Rechtbank Almelo')
                      , ('Hilversum', 'Rechtbank Amsterdam')
                      , ('Tiel', 'Rechtbank Arnhem')
                      , ('Nijmegen', 'Rechtbank Arnhem')
                      , ('Emmen', 'Rechtbank Assen')
                      , ('Tilburg', 'Rechtbank Breda')
                      , ('Bergen op Zoom', 'Rechtbank Breda')
                      , ('Delft', 'Rechtbank \'s-Gravenhage')
                      , ('Leiden', 'Rechtbank \'s-Gravenhage')
                      , ('Gouda', 'Rechtbank \'s-Gravenhage')
                      , ('Alphen aan den Rijn', 'Rechtbank \'s-Gravenhage')
                      , ('Haarlemmermeer', 'Rechtbank Haarlem')
                      , ('Zaanstad', 'Rechtbank Haarlem')
                      , ('Eindhoven', 'Rechtbank \'s-Hertogenbosch')
                      , ('Helmond', 'Rechtbank \'s-Hertogenbosch')
                      , ('Boxmeer', 'Rechtbank \'s-Hertogenbosch')
                      , ('Heerenveen', 'Rechtbank Leeuwarden')
                      , ('Heerlen', 'Rechtbank Maastricht')
                      , ('Sittard-Geleen', 'Rechtbank Maastricht')
                      , ('Terneuzen', 'Rechtbank Middelburg')
                      , ('Venlo', 'Rechtbank Roermond')
                      , ('Brielle', 'Rechtbank Rotterdam')
                      , ('Amersfoort', 'Rechtbank Utrecht')
                      , ('Apeldoorn', 'Rechtbank Zutphen')
                      , ('Deventer', 'Rechtbank Zwolle-Lelystad')
                      , ('Veghel', NULL)
                      , ('Stockholm', NULL)
                      , ('Spijkenisse', NULL)
                      , ('Haps', NULL)
                      , ('Zwijndrecht', NULL)
                      , ('Zenderen', NULL)
                      , ('Ittersum', NULL)
                      , ('Den Bosch', NULL)
                      , ('Den Haag', NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Rechtbank                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * ressort  [UNI,TOT]                   *
    \**************************************/
    mysql_query("CREATE TABLE `Rechtbank`
                     ( `Rechtbank` VARCHAR(255) DEFAULT NULL
                     , `ressort` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Rechtbank` (`Rechtbank` ,`ressort` )
                VALUES ('Rechtbank Alkmaar', 'Gerechtshof Amsterdam')
                      , ('Rechtbank Amsterdam', 'Gerechtshof Amsterdam')
                      , ('Rechtbank Haarlem', 'Gerechtshof Amsterdam')
                      , ('Rechtbank Utrecht', 'Gerechtshof Amsterdam')
                      , ('Rechtbank Almelo', 'Gerechtshof Arnhem')
                      , ('Rechtbank Arnhem', 'Gerechtshof Arnhem')
                      , ('Rechtbank Zutphen', 'Gerechtshof Arnhem')
                      , ('Rechtbank Zwolle-Lelystad', 'Gerechtshof Leeuwarden')
                      , ('Rechtbank Dordrecht', 'Gerechtshof \'s-Gravenhage')
                      , ('Rechtbank \'s-Gravenhage', 'Gerechtshof \'s-Gravenhage')
                      , ('Rechtbank Middelburg', 'Gerechtshof \'s-Gravenhage')
                      , ('Rechtbank Rotterdam', 'Gerechtshof \'s-Gravenhage')
                      , ('Rechtbank Breda', 'Gerechtshof \'s-Hertogenbosch')
                      , ('Rechtbank \'s-Hertogenbosch', 'Gerechtshof \'s-Hertogenbosch')
                      , ('Rechtbank Maastricht', 'Gerechtshof \'s-Hertogenbosch')
                      , ('Rechtbank Roermond', 'Gerechtshof \'s-Hertogenbosch')
                      , ('Rechtbank Assen', 'Gerechtshof Leeuwarden')
                      , ('Rechtbank Groningen', 'Gerechtshof Leeuwarden')
                      , ('Rechtbank Leeuwarden', 'Gerechtshof Leeuwarden')
                      , ('Raad van State', 'Raad van State')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijvingsverzoek            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * isGerichtAan  [TOT,UNI]              *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijvingsverzoek`
                     ( `Inschrijvingsverzoek` VARCHAR(255) DEFAULT NULL
                     , `isGerichtAan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijvingsverzoek` (`Inschrijvingsverzoek` ,`isGerichtAan` )
                VALUES ('Vvi1', 'Rechtbank Amsterdam')
                      , ('Vvi2', 'Rechtbank Rotterdam')
                      , ('Vvi3', 'Rechtbank Utrecht')
                      , ('Vvi4', 'Rechtbank Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Sector                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Sector`
                     ( `Sector` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Sector` (`Sector` )
                VALUES ('Kanton')
                      , ('Bestuursrecht')
                      , ('Straf')
                      , ('Civiel')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Sluiting                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Sluiting`
                     ( `Sluiting` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Sluiting` (`Sluiting` )
                VALUES ('06-12-2010')
                      , ('24-05-2011')
                      , ('12-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug schorsing1                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `schorsing1`
                     ( `schorsing` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `schorsing1` (`schorsing` )
                VALUES ('16:33 03-12-2010 - 12:00 04-12-2010')
                      , ('15:30 04-12-2010 - 09:00 06-12-2010')
                      , ('17:02 23-05-2011 - 10:05 24-05-2011')
                      , ('10:15 12-09-2011 - 11:15 12-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Schorsing2                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Schorsing2`
                     ( `Schorsing` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug schorsing3                *
    *                                *
    * fields:                        *
    * I/\schorsing;schorsing~  [ASY] *
    * schorsing  []                  *
    \********************************/
    mysql_query("CREATE TABLE `schorsing3`
                     ( `Van` VARCHAR(255) DEFAULT NULL
                     , `Tot` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `schorsing3` (`Van` ,`Tot` )
                VALUES ('16:33 03-12-2010 -', '12:00 04-12-2010')
                      , ('15:30 04-12-2010 -', '09:00 06-12-2010')
                      , ('17:02 23-05-2011 -', '10:05 24-05-2011')
                      , ('10:15 12-09-2011 -', '11:15 12-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Tot                             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Tot`
                     ( `Tot` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Tot` (`Tot` )
                VALUES ('12:00 04-12-2010')
                      , ('09:00 06-12-2010')
                      , ('10:05 24-05-2011')
                      , ('11:15 12-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Van                             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Van`
                     ( `Van` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Van` (`Van` )
                VALUES ('16:33 03-12-2010 -')
                      , ('15:30 04-12-2010 -')
                      , ('17:02 23-05-2011 -')
                      , ('10:15 12-09-2011 -')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Griffier                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Griffier`
                     ( `Griffier` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Griffier` (`Griffier` )
                VALUES ('mr. G.M. Fondse')
                      , ('mr. C.C. de Rijke-Maas')
                      , ('mr. B.M. Hoek')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Rechter1                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Rechter1`
                     ( `Rechter` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Rechter1` (`Rechter` )
                VALUES ('mr. J.A.A.M. van Veen')
                      , ('mr. E.M. Dil-Stork')
                      , ('mr. A.M. Rikken')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug rechter2                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * rechter  [TOT]                       *
    \**************************************/
    mysql_query("CREATE TABLE `rechter2`
                     ( `Zitting` VARCHAR(255) DEFAULT NULL
                     , `Rechter` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `rechter2` (`Zitting` ,`Rechter` )
                VALUES ('Zitting RbLee 591', 'mr. J.A.A.M. van Veen')
                      , ('Zitting RbsGr 35', 'mr. E.M. Dil-Stork')
                      , ('Zitting RbAlm 68', 'mr. A.M. Rikken')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Document                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Document`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Document` (`Document` )
                VALUES ('Proc 11/123458')
                      , ('Proc 10/569423')
                      , ('Proc 11/489631')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Rolzitting1                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Rolzitting1`
                     ( `Rolzitting` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Rolzitting1` (`Rolzitting` )
                VALUES ('Rol week 20')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug rolzitting2                 *
    *                                  *
    * fields:                          *
    * I/\rolzitting;rolzitting~  [ASY] *
    * rolzitting  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `rolzitting2`
                     ( `Zaak` VARCHAR(255) DEFAULT NULL
                     , `Rolzitting` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `rolzitting2` (`Zaak` ,`Rolzitting` )
                VALUES ('11/123458', 'Rol week 20')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Geslacht                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Geslacht`
                     ( `Geslacht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Geslacht` (`Geslacht` )
                VALUES ('Man')
                      , ('Vrouw')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Land                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Land`
                     ( `Land` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Land` (`Land` )
                VALUES ('Nederland')
                      , ('Zweden')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Datum                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Datum`
                     ( `Datum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Datum` (`Datum` )
                VALUES ('12-10-1967')
                      , ('06-07-1980')
                      , ('31-02-1970')
                      , ('25-03-1962')
                      , ('01-05-1982')
                      , ('16-07-1976')
                      , ('12-11-1981')
                      , ('12-01-1959')
                      , ('25-02-1948')
                      , ('30-12-1955')
                      , ('04-07-1965')
                      , ('25-04-1975')
                      , ('03-05-1980')
                      , ('10-12-1968')
                      , ('27-11-1976')
                      , ('30-06-1984')
                      , ('15-02-1989')
                      , ('26-05-1980')
                      , ('23-05-2011')
                      , ('03-12-2010')
                      , ('12-09-2011')
                      , ('24-05-2011')
                      , ('06-12-2010')
                      , ('23-07-2011')
                      , ('12-12-2010')
                      , ('03-10-2011')
                      , ('25-08-1990')
                      , ('12-02-2009')
                      , ('06-10-2007')
                      , ('18-04-2009')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Titel                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Titel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Titel` (`Titel` )
                VALUES ('Baron')
                      , ('mr')
                      , ('drs')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Burgerservicenummer             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Burgerservicenummer`
                     ( `Burgerservicenummer` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Burgerservicenummer` (`Burgerservicenummer` )
                VALUES ('23587435')
                      , ('56327491')
                      , ('78954566')
                      , ('14676455')
                      , ('58974564')
                      , ('15876456')
                      , ('45896541')
                      , ('56975633')
                      , ('62096541')
                      , ('45031741')
                      , ('72896694')
                      , ('63254896')
                      , ('45896310')
                      , ('35497763')
                      , ('79823438')
                      , ('46936557')
                      , ('49876337')
                      , ('78974651')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zoek                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Zoek`
                     ( `Zoek` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zoek` (`Zoek` )
                VALUES (NULL)
                      , ('Zoek')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Adres                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Adres`
                     ( `Adres` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Adres` (`Adres` )
                VALUES ('Herengracht 425-429, 1017 BR, Amsterdam')
                      , ('Westblaak 5f, 3001 AC, Rotterdam')
                      , ('Mariahoek 4, 3511 LD, Utrecht')
                      , ('Herculesplein 213, 3584 AA, Utrecht')
                      , ('Noordbolwerk 33, 4331SH Middelburg')
                      , ('Westhavenkade 98, 3133AV Vlaardingen')
                      , ('Koornbeursweg 132, 8442DJ Heerenveen')
                      , ('Johannes Verhulststraat 55/HS, 1071MS Amsterdam')
                      , ('Kruisherenstraat 56, 3078GT Rotterdam')
                      , ('Gezichtslaan 52, 3723GG Bilthoven')
                      , ('Kalkhofseweg 25, 5443NB Haps')
                      , ('Weldammerbos 17, 7543GW Enschede')
                      , ('Zeedijken 42, 9919BM Loppersum')
                      , ('Erve Kokenberg 1, 7625NH Zenderen')
                      , ('Heimerstein 91, 3328MH Dordrecht')
                      , ('Thorbeckelaan 342, 2564BZ \'s-Gravenhage')
                      , ('Bornsestraat 28, 7556BG Hengelo ov')
                      , ('Hooizolder 386, 9205CW Drachten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kantoor                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Kantoor`
                     ( `Kantoor` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kantoor` (`Kantoor` )
                VALUES ('Wieringa advocaten')
                      , ('Haulussy advocaten')
                      , ('Kuipers, Jonkers, van den Berg')
                      , ('ATM Advocaten Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Orgaan                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Orgaan`
                     ( `Orgaan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Orgaan` (`Orgaan` )
                VALUES ('Raad van State')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Schrapping                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Schrapping`
                     ( `Schrapping` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Schrapping` (`Schrapping` )
                VALUES ('Vts1')
                      , ('Vts3')
                      , ('Vts2')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijvingseis1               *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijvingseis1`
                     ( `Inschrijvingseis` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijvingseis1` (`Inschrijvingseis` )
                VALUES ('zijn gecontroleerd')
                      , ('niet zijn gecontroleerd')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************************\
    * Plug inschrijvingseis2                       *
    *                                              *
    * fields:                                      *
    * I/\inschrijvingseis;inschrijvingseis~  [ASY] *
    * inschrijvingseis  []                         *
    \**********************************************/
    mysql_query("CREATE TABLE `inschrijvingseis2`
                     ( `Inschrijvingsverzoek` VARCHAR(255) DEFAULT NULL
                     , `Inschrijvingseis` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `inschrijvingseis2` (`Inschrijvingsverzoek` ,`Inschrijvingseis` )
                VALUES ('Vvi1', 'zijn gecontroleerd')
                      , ('Vvi2', 'zijn gecontroleerd')
                      , ('Vvi3', 'zijn gecontroleerd')
                      , ('Vvi4', 'zijn gecontroleerd')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Barnummer                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Barnummer`
                     ( `Barnummer` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Barnummer` (`Barnummer` )
                VALUES ('A23968')
                      , ('A26815')
                      , ('A16378')
                      , ('A24763')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijvingsstatus1            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijvingsstatus1`
                     ( `Inschrijvingsstatus` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijvingsstatus1` (`Inschrijvingsstatus` )
                VALUES ('onvoorwaardelijk')
                      , ('voorwaardelijk')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug inschrijvingsstatus2                          *
    *                                                    *
    * fields:                                            *
    * I/\inschrijvingsstatus;inschrijvingsstatus~  [ASY] *
    * inschrijvingsstatus  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `inschrijvingsstatus2`
                     ( `Advocaat` VARCHAR(255) DEFAULT NULL
                     , `Inschrijvingsstatus` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug kantoorVerzoek                  *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * kantoorVerzoek  [TOT]                *
    \**************************************/
    mysql_query("CREATE TABLE `kantoorVerzoek`
                     ( `Inschrijvingsverzoek` VARCHAR(255) DEFAULT NULL
                     , `Kantoornummer` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `kantoorVerzoek` (`Inschrijvingsverzoek` ,`Kantoornummer` )
                VALUES ('Vvi1', 'K52347')
                      , ('Vvi2', 'K45317')
                      , ('Vvi3', 'K48933')
                      , ('Vvi4', 'K12493')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug isVerstuurdDoor                 *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * isVerstuurdDoor  [TOT]               *
    \**************************************/
    mysql_query("CREATE TABLE `isVerstuurdDoor`
                     ( `Inschrijvingsverzoek` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `isVerstuurdDoor` (`Inschrijvingsverzoek` ,`Persoon` )
                VALUES ('Vvi1', '4')
                      , ('Vvi2', '5')
                      , ('Vvi3', '6')
                      , ('Vvi4', '7')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug schrappingDoor1                     *
    *                                          *
    * fields:                                  *
    * I/\schrappingDoor;schrappingDoor~  [ASY] *
    * schrappingDoor  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `schrappingDoor1`
                     ( `Schrapping` VARCHAR(255) DEFAULT NULL
                     , `Advocaat` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `schrappingDoor1` (`Schrapping` ,`Advocaat` )
                VALUES ('Vts1', '16378')
                      , ('Vts3', '23968')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug schrappingDoor2                     *
    *                                          *
    * fields:                                  *
    * I/\schrappingDoor;schrappingDoor~  [ASY] *
    * schrappingDoor  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `schrappingDoor2`
                     ( `Schrapping` VARCHAR(255) DEFAULT NULL
                     , `Orgaan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `schrappingDoor2` (`Schrapping` ,`Orgaan` )
                VALUES ('Vts2', 'Raad van State')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug schrappingVan                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * schrappingVan  [TOT]                 *
    \**************************************/
    mysql_query("CREATE TABLE `schrappingVan`
                     ( `Schrapping` VARCHAR(255) DEFAULT NULL
                     , `Advocaat` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `schrappingVan` (`Schrapping` ,`Advocaat` )
                VALUES ('Vts1', '16378')
                      , ('Vts2', '26815')
                      , ('Vts3', '23968')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug houdtkantoor                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * houdtkantoor  [TOT]                  *
    \**************************************/
    mysql_query("CREATE TABLE `houdtkantoor`
                     ( `Advocaat` VARCHAR(255) DEFAULT NULL
                     , `Kantoornummer` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `houdtkantoor` (`Advocaat` ,`Kantoornummer` )
                VALUES ('23968', 'K52347')
                      , ('26815', 'K45317')
                      , ('16378', 'K48933')
                      , ('24763', 'K12493')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug schorsingVan                    *
    *                                      *
    * fields:                              *
    * I/\schorsingVan;schorsingVan~  [ASY] *
    * schorsingVan  []                     *
    \**************************************/
    mysql_query("CREATE TABLE `schorsingVan`
                     ( `Schorsing` VARCHAR(255) DEFAULT NULL
                     , `Advocaat` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug zoeken              *
    *                          *
    * fields:                  *
    * I/\zoeken;zoeken~  [ASY] *
    * zoeken  []               *
    \**************************/
    mysql_query("CREATE TABLE `zoeken`
                     ( `sZoek` VARCHAR(255) DEFAULT NULL
                     , `tZoek` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `zoeken` (`sZoek` ,`tZoek` )
                VALUES (NULL, 'Zoek')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug zoekOpNaam                  *
    *                                  *
    * fields:                          *
    * I/\zoekOpNaam;zoekOpNaam~  [ASY] *
    * zoekOpNaam  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `zoekOpNaam`
                     ( `Zoek` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug zoekOpBAR                 *
    *                                *
    * fields:                        *
    * I/\zoekOpBAR;zoekOpBAR~  [ASY] *
    * zoekOpBAR  []                  *
    \********************************/
    mysql_query("CREATE TABLE `zoekOpBAR`
                     ( `Zoek` VARCHAR(255) DEFAULT NULL
                     , `Advocaat` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug adelijketitel                     *
    *                                        *
    * fields:                                *
    * I/\adelijketitel;adelijketitel~  [ASY] *
    * adelijketitel  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `adelijketitel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `adelijketitel` (`Titel` ,`Persoon` )
                VALUES ('Baron', '1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************\
    * Plug opleidingstitel                       *
    *                                            *
    * fields:                                    *
    * I/\opleidingstitel;opleidingstitel~  [ASY] *
    * opleidingstitel  []                        *
    \********************************************/
    mysql_query("CREATE TABLE `opleidingstitel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `opleidingstitel` (`Titel` ,`Persoon` )
                VALUES ('mr', '4')
                      , ('mr', '5')
                      , ('mr', '6')
                      , ('mr', '7')
                      , ('mr', '8')
                      , ('drs', '18')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************\
    * Plug ouder             *
    *                        *
    * fields:                *
    * I/\ouder;ouder~  [ASY] *
    * ouder  [TRN,ASY]       *
    \************************/
    mysql_query("CREATE TABLE `ouder`
                     ( `sGebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `tGebeurtenis` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************\
    * Plug tolk            *
    *                      *
    * fields:              *
    * I/\tolk;tolk~  [ASY] *
    * tolk  []             *
    \**********************/
    mysql_query("CREATE TABLE `tolk`
                     ( `Persoon` VARCHAR(255) DEFAULT NULL
                     , `Zitting` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************\
    * Plug getuige               *
    *                            *
    * fields:                    *
    * I/\getuige;getuige~  [ASY] *
    * getuige  []                *
    \****************************/
    mysql_query("CREATE TABLE `getuige`
                     ( `Zitting` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug bewijsstuk                  *
    *                                  *
    * fields:                          *
    * I/\bewijsstuk;bewijsstuk~  [ASY] *
    * bewijsstuk  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `bewijsstuk`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Zitting` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug geschorst                 *
    *                                *
    * fields:                        *
    * I/\geschorst;geschorst~  [ASY] *
    * geschorst  []                  *
    \********************************/
    mysql_query("CREATE TABLE `geschorst`
                     ( `Zitting` VARCHAR(255) DEFAULT NULL
                     , `schorsing` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `geschorst` (`Zitting` ,`schorsing` )
                VALUES ('Zitting RbLee 591', '16:33 03-12-2010 - 12:00 04-12-2010')
                      , ('Zitting RbLee 591', '15:30 04-12-2010 - 09:00 06-12-2010')
                      , ('Zitting RbsGr 35', '17:02 23-05-2011 - 10:05 24-05-2011')
                      , ('Zitting RbAlm 68', '10:15 12-09-2011 - 11:15 12-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************\
    * Plug gesloten                *
    *                              *
    * fields:                      *
    * I/\gesloten;gesloten~  [ASY] *
    * gesloten  []                 *
    \******************************/
    mysql_query("CREATE TABLE `gesloten`
                     ( `Zitting` VARCHAR(255) DEFAULT NULL
                     , `Sluiting` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `gesloten` (`Zitting` ,`Sluiting` )
                VALUES ('Zitting RbLee 591', '06-12-2010')
                      , ('Zitting RbsGr 35', '24-05-2011')
                      , ('Zitting RbAlm 68', '12-09-2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************\
    * Plug bevoegd               *
    *                            *
    * fields:                    *
    * I/\bevoegd;bevoegd~  [ASY] *
    * bevoegd  []                *
    \****************************/
    mysql_query("CREATE TABLE `bevoegd`
                     ( `Zaak` VARCHAR(255) DEFAULT NULL
                     , `Gerecht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `bevoegd` (`Zaak` ,`Gerecht` )
                VALUES ('11/123458', 'Gerechtshof \'s-Gravenhage')
                      , ('10/569423', 'Gerechtshof Leeuwarden')
                      , ('11/489631', 'Gerechtshof Arnhem')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************************\
    * Plug hoofdplaatsrechtbank                            *
    *                                                      *
    * fields:                                              *
    * I/\hoofdplaatsrechtbank;hoofdplaatsrechtbank~  [ASY] *
    * hoofdplaatsrechtbank  []                             *
    \******************************************************/
    mysql_query("CREATE TABLE `hoofdplaatsrechtbank`
                     ( `Plaats` VARCHAR(255) DEFAULT NULL
                     , `Rechtbank` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `hoofdplaatsrechtbank` (`Plaats` ,`Rechtbank` )
                VALUES ('Alkmaar', 'Rechtbank Alkmaar')
                      , ('Almelo', 'Rechtbank Almelo')
                      , ('Amsterdam', 'Rechtbank Amsterdam')
                      , ('Arnhem', 'Rechtbank Arnhem')
                      , ('Groningen', 'Rechtbank Groningen')
                      , ('Assen', 'Rechtbank Assen')
                      , ('Breda', 'Rechtbank Breda')
                      , ('Roermond', 'Rechtbank Roermond')
                      , ('\'s-Gravenhage', 'Rechtbank \'s-Gravenhage')
                      , ('Dordrecht', 'Rechtbank Dordrecht')
                      , ('Haarlem', 'Rechtbank Haarlem')
                      , ('Leeuwarden', 'Rechtbank Leeuwarden')
                      , ('Maastricht', 'Rechtbank Maastricht')
                      , ('Middelburg', 'Rechtbank Middelburg')
                      , ('Rotterdam', 'Rechtbank Rotterdam')
                      , ('Utrecht', 'Rechtbank Utrecht')
                      , ('Zutphen', 'Rechtbank Zutphen')
                      , ('Zwolle', 'Rechtbank Zwolle-Lelystad')
                      , ('Lelystad', 'Rechtbank Zwolle-Lelystad')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo 'The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT RegisterDemo\n");
      fwrite($dumpfile, dumprel("advocaatnaam[Advocaat*Persoon]","SELECT DISTINCT `advocaatnaam`, `naam1` FROM `Naam` WHERE `advocaatnaam` IS NOT NULL AND `naam1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsstatus[Advocaat*Inschrijvingsstatus]","SELECT DISTINCT `Advocaat`, `Inschrijvingsstatus` FROM `inschrijvingsstatus2` WHERE `Advocaat` IS NOT NULL AND `Inschrijvingsstatus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("barnummer[Advocaat*Barnummer]","SELECT DISTINCT `advocaatnaam`, `barnummer` FROM `Naam` WHERE `advocaatnaam` IS NOT NULL AND `barnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoorVerzoek[Inschrijvingsverzoek*Kantoornummer]","SELECT DISTINCT `Inschrijvingsverzoek`, `Kantoornummer` FROM `kantoorVerzoek` WHERE `Inschrijvingsverzoek` IS NOT NULL AND `Kantoornummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isGerichtAan[Inschrijvingsverzoek*Rechtbank]","SELECT DISTINCT `Inschrijvingsverzoek`, `isGerichtAan` FROM `Inschrijvingsverzoek` WHERE `Inschrijvingsverzoek` IS NOT NULL AND `isGerichtAan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isVerstuurdDoor[Inschrijvingsverzoek*Persoon]","SELECT DISTINCT `Inschrijvingsverzoek`, `Persoon` FROM `isVerstuurdDoor` WHERE `Inschrijvingsverzoek` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingseis[Inschrijvingsverzoek*Inschrijvingseis]","SELECT DISTINCT `Inschrijvingsverzoek`, `Inschrijvingseis` FROM `inschrijvingseis2` WHERE `Inschrijvingsverzoek` IS NOT NULL AND `Inschrijvingseis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("isBeëdigd[Beëdiging*Persoon]","SELECT DISTINCT `Beëdiging`, `isBeëdigd` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `isBeëdigd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatieBeëdiging[Beëdiging*Rechtbank]","SELECT DISTINCT `Beëdiging`, `locatieBeëdiging` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `locatieBeëdiging` IS NOT NULL"));
      fwrite($dumpfile, dumprel("behoortBij[Inschrijvingsverzoek*Beëdiging]","SELECT DISTINCT `behoortBij`, `Beëdiging` FROM `Gebeurtenis` WHERE `behoortBij` IS NOT NULL AND `Beëdiging` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingDoor[Schrapping*Advocaat]","SELECT DISTINCT `Schrapping`, `Advocaat` FROM `schrappingDoor1` WHERE `Schrapping` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingDoor[Schrapping*Orgaan]","SELECT DISTINCT `Schrapping`, `Orgaan` FROM `schrappingDoor2` WHERE `Schrapping` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingVan[Schrapping*Advocaat]","SELECT DISTINCT `Schrapping`, `Advocaat` FROM `schrappingVan` WHERE `Schrapping` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("houdtkantoor[Advocaat*Kantoornummer]","SELECT DISTINCT `Advocaat`, `Kantoornummer` FROM `houdtkantoor` WHERE `Advocaat` IS NOT NULL AND `Kantoornummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoor[Kantoornummer*Rechtbank]","SELECT DISTINCT `Kantoornummer`, `kantoor` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsingVan[Schorsing*Advocaat]","SELECT DISTINCT `Schorsing`, `Advocaat` FROM `schorsingVan` WHERE `Schorsing` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Beëdiging[Beëdiging*Gebeurtenis]","SELECT DISTINCT `Beëdiging`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoornaam[Kantoornummer*Kantoor]","SELECT DISTINCT `Kantoornummer`, `kantoornaam` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoornaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantooradres[Kantoornummer*Adres]","SELECT DISTINCT `Kantoornummer`, `kantooradres` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantooradres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoeken[Zoek]","SELECT DISTINCT `sZoek`, `tZoek` FROM `zoeken` WHERE `sZoek` IS NOT NULL AND `tZoek` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoekOpNaam[Zoek*Persoon]","SELECT DISTINCT `Zoek`, `Persoon` FROM `zoekOpNaam` WHERE `Zoek` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoekOpBAR[Zoek*Advocaat]","SELECT DISTINCT `Zoek`, `Advocaat` FROM `zoekOpBAR` WHERE `Zoek` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("naam[Persoon*Naam]","SELECT DISTINCT `naam1`, `Naam0` FROM `Naam` WHERE `naam1` IS NOT NULL AND `Naam0` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bsn[Persoon*Burgerservicenummer]","SELECT DISTINCT `naam1`, `bsn` FROM `Naam` WHERE `naam1` IS NOT NULL AND `bsn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adelijketitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `adelijketitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("opleidingstitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `opleidingstitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboortedatum[Persoon*Datum]","SELECT DISTINCT `naam1`, `geboortedatum` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteplaats[Persoon*Plaats]","SELECT DISTINCT `naam1`, `geboorteplaats` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboorteplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteland[Persoon*Land]","SELECT DISTINCT `naam1`, `geboorteland` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboorteland` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaats[Persoon*Adres]","SELECT DISTINCT `naam1`, `woonplaats` FROM `Naam` WHERE `naam1` IS NOT NULL AND `woonplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geslacht[Persoon*Geslacht]","SELECT DISTINCT `naam1`, `geslacht` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geslacht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gba[Gbanummer*Persoon]","SELECT DISTINCT `Gbanummer`, `gba` FROM `Gbanummer` WHERE `Gbanummer` IS NOT NULL AND `gba` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatie[Gebeurtenis*Plaats]","SELECT DISTINCT `Gebeurtenis`, `locatie` FROM `Gebeurtenis` WHERE `Gebeurtenis` IS NOT NULL AND `locatie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("datum[Gebeurtenis*Datum]","SELECT DISTINCT `Gebeurtenis`, `datum` FROM `Gebeurtenis` WHERE `Gebeurtenis` IS NOT NULL AND `datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ouder[Gebeurtenis]","SELECT DISTINCT `sGebeurtenis`, `tGebeurtenis` FROM `ouder` WHERE `sGebeurtenis` IS NOT NULL AND `tGebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("dient[Zaak*Zitting]","SELECT DISTINCT `Zaak`, `dient` FROM `Zaak` WHERE `Zaak` IS NOT NULL AND `dient` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rolzitting[Zaak*Rolzitting]","SELECT DISTINCT `Zaak`, `Rolzitting` FROM `rolzitting2` WHERE `Zaak` IS NOT NULL AND `Rolzitting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaak[behandeling*Zitting]","SELECT DISTINCT `behandeling`, `zaak` FROM `behandeling` WHERE `behandeling` IS NOT NULL AND `zaak` IS NOT NULL"));
      fwrite($dumpfile, dumprel("procesverbaal[behandeling*Document]","SELECT DISTINCT `behandeling`, `procesverbaal` FROM `behandeling` WHERE `behandeling` IS NOT NULL AND `procesverbaal` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kamer[Zitting*Kamer]","SELECT DISTINCT `Zitting`, `kamer` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `kamer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechter[Zitting*Rechter]","SELECT DISTINCT `Zitting`, `Rechter` FROM `rechter2` WHERE `Zitting` IS NOT NULL AND `Rechter` IS NOT NULL"));
      fwrite($dumpfile, dumprel("griffier[Zitting*Griffier]","SELECT DISTINCT `Zitting`, `griffier` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `griffier` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tolk[Persoon*Zitting]","SELECT DISTINCT `Persoon`, `Zitting` FROM `tolk` WHERE `Persoon` IS NOT NULL AND `Zitting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("getuige[Zitting*Persoon]","SELECT DISTINCT `Zitting`, `Persoon` FROM `getuige` WHERE `Zitting` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bewijsstuk[Document*Zitting]","SELECT DISTINCT `Document`, `Zitting` FROM `bewijsstuk` WHERE `Document` IS NOT NULL AND `Zitting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsing[Van*Tot]","SELECT DISTINCT `Van`, `Tot` FROM `schorsing3` WHERE `Van` IS NOT NULL AND `Tot` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geschorst[Zitting*schorsing]","SELECT DISTINCT `Zitting`, `schorsing` FROM `geschorst` WHERE `Zitting` IS NOT NULL AND `schorsing` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gesloten[Zitting*Sluiting]","SELECT DISTINCT `Zitting`, `Sluiting` FROM `gesloten` WHERE `Zitting` IS NOT NULL AND `Sluiting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geagendeerd[Zitting*Datum]","SELECT DISTINCT `Zitting`, `geagendeerd` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `geagendeerd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechtbankhoudt[Zitting*Rechtbank]","SELECT DISTINCT `Zitting`, `rechtbankhoudt` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `rechtbankhoudt` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bevoegd[Zaak*Gerecht]","SELECT DISTINCT `Zaak`, `Gerecht` FROM `bevoegd` WHERE `Zaak` IS NOT NULL AND `Gerecht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechtbank[Kamer*Rechtbank]","SELECT DISTINCT `Kamer`, `rechtbank` FROM `Kamer` WHERE `Kamer` IS NOT NULL AND `rechtbank` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gerecht[Kamer*Gerecht]","SELECT DISTINCT `Kamer`, `gerecht` FROM `Kamer` WHERE `Kamer` IS NOT NULL AND `gerecht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sector[Kamer*Sector]","SELECT DISTINCT `Kamer`, `sector` FROM `Kamer` WHERE `Kamer` IS NOT NULL AND `sector` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hoofdplaatsrechtbank[Plaats*Rechtbank]","SELECT DISTINCT `Plaats`, `Rechtbank` FROM `hoofdplaatsrechtbank` WHERE `Plaats` IS NOT NULL AND `Rechtbank` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ressort[Rechtbank*Gerecht]","SELECT DISTINCT `Rechtbank`, `ressort` FROM `Rechtbank` WHERE `Rechtbank` IS NOT NULL AND `ressort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hoofdplaats[Gerecht*Plaats]","SELECT DISTINCT `Gerecht`, `hoofdplaats` FROM `Gerecht` WHERE `Gerecht` IS NOT NULL AND `hoofdplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("neven[Plaats*Rechtbank]","SELECT DISTINCT `Plaats`, `neven` FROM `Plaats` WHERE `Plaats` IS NOT NULL AND `neven` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Zitting[Zitting*Gebeurtenis]","SELECT DISTINCT `Zitting`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("registerdemo", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
