
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT RegisterDemo\n");
      fwrite($dumpfile, dumprel("advocaat[Advocaat*Persoon]","SELECT DISTINCT `advocaat`, `naam1` FROM `Naam` WHERE `advocaat` IS NOT NULL AND `naam1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsstatus[Advocaat*Inschrijvingsstatus]","SELECT DISTINCT `Advocaat`, `Inschrijvingsstatus` FROM `inschrijvingsstatus2` WHERE `Advocaat` IS NOT NULL AND `Inschrijvingsstatus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("barnummer[Advocaat*Barnummer]","SELECT DISTINCT `advocaat`, `barnummer` FROM `Naam` WHERE `advocaat` IS NOT NULL AND `barnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoorVerzoek[Inschrijvingsverzoek*Kantoornummer]","SELECT DISTINCT `Inschrijvingsverzoek`, `kantoorVerzoek` FROM `Inschrijvingsverzoek` WHERE `Inschrijvingsverzoek` IS NOT NULL AND `kantoorVerzoek` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gerichtAan[Inschrijvingsverzoek*Rechtbank]","SELECT DISTINCT `Inschrijvingsverzoek`, `gerichtAan` FROM `Inschrijvingsverzoek` WHERE `Inschrijvingsverzoek` IS NOT NULL AND `gerichtAan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verstuurdDoor[Inschrijvingsverzoek*Persoon]","SELECT DISTINCT `Inschrijvingsverzoek`, `verstuurdDoor` FROM `Inschrijvingsverzoek` WHERE `Inschrijvingsverzoek` IS NOT NULL AND `verstuurdDoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingseis[Inschrijvingsverzoek*Inschrijvingseis]","SELECT DISTINCT `Inschrijvingsverzoek`, `Inschrijvingseis` FROM `inschrijvingseis2` WHERE `Inschrijvingsverzoek` IS NOT NULL AND `Inschrijvingseis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beëdigd[Beëdiging*Persoon]","SELECT DISTINCT `Beëdiging`, `beëdigd` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `beëdigd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatieBeëdiging[Beëdiging*Rechtbank]","SELECT DISTINCT `Beëdiging`, `locatieBeëdiging` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `locatieBeëdiging` IS NOT NULL"));
      fwrite($dumpfile, dumprel("behoortBij[Inschrijvingsverzoek*Beëdiging]","SELECT DISTINCT `behoortBij`, `Beëdiging` FROM `Gebeurtenis` WHERE `behoortBij` IS NOT NULL AND `Beëdiging` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingDoor[Schrapping*Advocaat]","SELECT DISTINCT `Schrapping`, `Advocaat` FROM `schrappingDoor1` WHERE `Schrapping` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingDoor[Schrapping*Orgaan]","SELECT DISTINCT `Schrapping`, `Orgaan` FROM `schrappingDoor2` WHERE `Schrapping` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingVan[Schrapping*Advocaat]","SELECT DISTINCT `Schrapping`, `Advocaat` FROM `schrappingVan` WHERE `Schrapping` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("houdtkantoor[Advocaat*Kantoornummer]","SELECT DISTINCT `Advocaat`, `Kantoornummer` FROM `houdtkantoor` WHERE `Advocaat` IS NOT NULL AND `Kantoornummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoor[Kantoornummer*Rechtbank]","SELECT DISTINCT `Kantoornummer`, `kantoor` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsingVan[Schorsing*Advocaat]","SELECT DISTINCT `Schorsing`, `Advocaat` FROM `schorsingVan` WHERE `Schorsing` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Beëdiging[Beëdiging*Gebeurtenis]","SELECT DISTINCT `Beëdiging`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoornaam[Kantoornummer*Kantoor]","SELECT DISTINCT `Kantoornummer`, `kantoornaam` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoornaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantooradres[Kantoornummer*Adres]","SELECT DISTINCT `Kantoornummer`, `kantooradres` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantooradres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoeken[Zoek]","SELECT DISTINCT `sZoek`, `tZoek` FROM `zoeken` WHERE `sZoek` IS NOT NULL AND `tZoek` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoekOpNaam[Zoek*Persoon]","SELECT DISTINCT `Zoek`, `Persoon` FROM `zoekOpNaam` WHERE `Zoek` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoekOpBAR[Zoek*Advocaat]","SELECT DISTINCT `Zoek`, `Advocaat` FROM `zoekOpBAR` WHERE `Zoek` IS NOT NULL AND `Advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("naam[Persoon*Naam]","SELECT DISTINCT `naam1`, `Naam0` FROM `Naam` WHERE `naam1` IS NOT NULL AND `Naam0` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bsn[Persoon*Burgerservicenummer]","SELECT DISTINCT `naam1`, `bsn` FROM `Naam` WHERE `naam1` IS NOT NULL AND `bsn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adelijketitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `adelijketitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("opleidingstitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `opleidingstitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboortedatum[Persoon*Datum]","SELECT DISTINCT `naam1`, `geboortedatum` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboortedatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteplaats[Persoon*Plaats]","SELECT DISTINCT `naam1`, `geboorteplaats` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboorteplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteland[Persoon*Land]","SELECT DISTINCT `naam1`, `geboorteland` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geboorteland` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaats[Persoon*Adres]","SELECT DISTINCT `naam1`, `woonplaats` FROM `Naam` WHERE `naam1` IS NOT NULL AND `woonplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geslacht[Persoon*Geslacht]","SELECT DISTINCT `naam1`, `geslacht` FROM `Naam` WHERE `naam1` IS NOT NULL AND `geslacht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gba[Anummer*Persoon]","SELECT DISTINCT `Anummer`, `gba` FROM `Anummer` WHERE `Anummer` IS NOT NULL AND `gba` IS NOT NULL"));
      fwrite($dumpfile, dumprel("nationaliteit[Persoon*Nationaliteit]","SELECT DISTINCT `Persoon`, `Nationaliteit` FROM `nationaliteit2` WHERE `Persoon` IS NOT NULL AND `Nationaliteit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatie[Gebeurtenis*Plaats]","SELECT DISTINCT `Gebeurtenis`, `locatie` FROM `Gebeurtenis` WHERE `Gebeurtenis` IS NOT NULL AND `locatie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("datum[Gebeurtenis*Datum]","SELECT DISTINCT `Gebeurtenis`, `datum` FROM `Gebeurtenis` WHERE `Gebeurtenis` IS NOT NULL AND `datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ouder[Gebeurtenis]","SELECT DISTINCT `sGebeurtenis`, `tGebeurtenis` FROM `ouder` WHERE `sGebeurtenis` IS NOT NULL AND `tGebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("dient[Zaak*Zitting]","SELECT DISTINCT `Zaak`, `dient` FROM `Zaak` WHERE `Zaak` IS NOT NULL AND `dient` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rolzitting[Zaak*Rolzitting]","SELECT DISTINCT `Zaak`, `Rolzitting` FROM `rolzitting2` WHERE `Zaak` IS NOT NULL AND `Rolzitting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zaak[behandeling*Zitting]","SELECT DISTINCT `behandeling`, `zaak` FROM `behandeling` WHERE `behandeling` IS NOT NULL AND `zaak` IS NOT NULL"));
      fwrite($dumpfile, dumprel("procesverbaal[behandeling*Document]","SELECT DISTINCT `behandeling`, `procesverbaal` FROM `behandeling` WHERE `behandeling` IS NOT NULL AND `procesverbaal` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kamer[Zitting*Kamer]","SELECT DISTINCT `Zitting`, `kamer` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `kamer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechter[Zitting*Rechter]","SELECT DISTINCT `Zitting`, `Rechter` FROM `rechter2` WHERE `Zitting` IS NOT NULL AND `Rechter` IS NOT NULL"));
      fwrite($dumpfile, dumprel("griffier[Zitting*Griffier]","SELECT DISTINCT `Zitting`, `griffier` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `griffier` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tolk[Persoon*Zitting]","SELECT DISTINCT `Persoon`, `Zitting` FROM `tolk` WHERE `Persoon` IS NOT NULL AND `Zitting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("getuige[Zitting*Persoon]","SELECT DISTINCT `Zitting`, `Persoon` FROM `getuige` WHERE `Zitting` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bewijsstuk[Document*Zitting]","SELECT DISTINCT `Document`, `Zitting` FROM `bewijsstuk` WHERE `Document` IS NOT NULL AND `Zitting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsing[Van*Tot]","SELECT DISTINCT `Van`, `Tot` FROM `schorsing3` WHERE `Van` IS NOT NULL AND `Tot` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geschorst[Zitting*schorsing]","SELECT DISTINCT `Zitting`, `schorsing` FROM `geschorst` WHERE `Zitting` IS NOT NULL AND `schorsing` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gesloten[Zitting*Sluiting]","SELECT DISTINCT `Zitting`, `Sluiting` FROM `gesloten` WHERE `Zitting` IS NOT NULL AND `Sluiting` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geagendeerd[Zitting*Datum]","SELECT DISTINCT `Zitting`, `geagendeerd` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `geagendeerd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechtbankhoudt[Zitting*Rechtbank]","SELECT DISTINCT `Zitting`, `rechtbankhoudt` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `rechtbankhoudt` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bevoegd[Zaak*Gerecht]","SELECT DISTINCT `Zaak`, `Gerecht` FROM `bevoegd` WHERE `Zaak` IS NOT NULL AND `Gerecht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rechtbank[Kamer*Rechtbank]","SELECT DISTINCT `Kamer`, `rechtbank` FROM `Kamer` WHERE `Kamer` IS NOT NULL AND `rechtbank` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gerecht[Kamer*Gerecht]","SELECT DISTINCT `Kamer`, `gerecht` FROM `Kamer` WHERE `Kamer` IS NOT NULL AND `gerecht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sector[Kamer*Sector]","SELECT DISTINCT `Kamer`, `sector` FROM `Kamer` WHERE `Kamer` IS NOT NULL AND `sector` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hoofdplaatsrechtbank[Plaats*Rechtbank]","SELECT DISTINCT `Plaats`, `Rechtbank` FROM `hoofdplaatsrechtbank` WHERE `Plaats` IS NOT NULL AND `Rechtbank` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ressort[Rechtbank*Gerecht]","SELECT DISTINCT `Rechtbank`, `ressort` FROM `Rechtbank` WHERE `Rechtbank` IS NOT NULL AND `ressort` IS NOT NULL"));
      fwrite($dumpfile, dumprel("hoofdplaats[Gerecht*Plaats]","SELECT DISTINCT `Gerecht`, `hoofdplaats` FROM `Gerecht` WHERE `Gerecht` IS NOT NULL AND `hoofdplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("neven[Plaats*Rechtbank]","SELECT DISTINCT `Plaats`, `neven` FROM `Plaats` WHERE `Plaats` IS NOT NULL AND `neven` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Zitting[Zitting*Gebeurtenis]","SELECT DISTINCT `Zitting`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Zitting` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("registerdemo", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\"",$str); }
      ?>