
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT RegisterDemo\n");
      fwrite($dumpfile, dumprel("advocaat[Inschrijving*Persoon]","SELECT DISTINCT `Inschrijving`, `advocaat` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("barnummer[Barnummer*Inschrijving]","SELECT DISTINCT `Barnummer0`, `barnummer1` FROM `Barnummer` WHERE `Barnummer0` IS NOT NULL AND `barnummer1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsstatus[Inschrijving*Inschrijvingsstatus]","SELECT DISTINCT `Inschrijving`, `Inschrijvingsstatus` FROM `inschrijvingsstatus2` WHERE `Inschrijving` IS NOT NULL AND `Inschrijvingsstatus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verzoeker[Document*Persoon]","SELECT DISTINCT `Document`, `verzoeker` FROM `Document` WHERE `Document` IS NOT NULL AND `verzoeker` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsverzoek[Inschrijving*Document]","SELECT DISTINCT `Inschrijving`, `Document` FROM `inschrijvingsverzoek` WHERE `Inschrijving` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ontvanger[Inschrijving*Rechtbank]","SELECT DISTINCT `Inschrijving`, `ontvanger` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `ontvanger` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoorlocatie[Inschrijving*Adres]","SELECT DISTINCT `Inschrijving`, `kantoorlocatie` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `kantoorlocatie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingseis[Inschrijving*Inschrijvingseis]","SELECT DISTINCT `Inschrijving`, `inschrijvingseis` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `inschrijvingseis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beëdigd[Inschrijving*Beëdiging]","SELECT DISTINCT `Inschrijving`, `beëdigd` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `beëdigd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatieBeëdiging[Beëdiging*Rechtbank]","SELECT DISTINCT `Beëdiging`, `locatieBeëdiging` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `locatieBeëdiging` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrapper[Document*Inschrijving]","SELECT DISTINCT `Document`, `Inschrijving` FROM `schrapper` WHERE `Document` IS NOT NULL AND `Inschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingDoor[Beslissing*Orgaan]","SELECT DISTINCT `Beslissing`, `Orgaan` FROM `schrappingDoor` WHERE `Beslissing` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrapping[Document*Inschrijving]","SELECT DISTINCT `Document`, `Inschrijving` FROM `schrapping` WHERE `Document` IS NOT NULL AND `Inschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("houdtkantoor[Inschrijving*Kantoornummer]","SELECT DISTINCT `Inschrijving`, `houdtkantoor` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `houdtkantoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoor[Kantoornummer*Rechtbank]","SELECT DISTINCT `Kantoornummer`, `kantoor` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsing[Document*Inschrijving]","SELECT DISTINCT `Document`, `Inschrijving` FROM `schorsing1` WHERE `Document` IS NOT NULL AND `Inschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsing[Beslissing*Orgaan]","SELECT DISTINCT `Beslissing`, `Orgaan` FROM `schorsing2` WHERE `Beslissing` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsingOpheffen[Beslissing*Orgaan]","SELECT DISTINCT `Beslissing`, `Orgaan` FROM `schorsingOpheffen` WHERE `Beslissing` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Beëdiging[Beëdiging*Gebeurtenis]","SELECT DISTINCT `Beëdiging`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoornaam[Kantoornummer*Kantoor]","SELECT DISTINCT `Kantoornummer`, `kantoornaam` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoornaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantooradres[Kantoornummer*Adres]","SELECT DISTINCT `Kantoornummer`, `kantooradres` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantooradres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoeken[Zoek]","SELECT DISTINCT `sZoek`, `tZoek` FROM `zoeken` WHERE `sZoek` IS NOT NULL AND `tZoek` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoekOpNaam[Zoek*Inschrijving]","SELECT DISTINCT `Zoek`, `Inschrijving` FROM `zoekOpNaam` WHERE `Zoek` IS NOT NULL AND `Inschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoekOpBAR[Zoek*Barnummer]","SELECT DISTINCT `Zoek`, `Barnummer` FROM `zoekOpBAR` WHERE `Zoek` IS NOT NULL AND `Barnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("naam[Persoon*Naam]","SELECT DISTINCT `Persoon`, `Naam` FROM `naam2` WHERE `Persoon` IS NOT NULL AND `Naam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bsn[Persoon*Burgerservicenummer]","SELECT DISTINCT `Persoon`, `bsn` FROM `Persoon` WHERE `Persoon` IS NOT NULL AND `bsn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adelijketitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `adelijketitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("opleidingstitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `opleidingstitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboortedatum[Persoon*Datum]","SELECT DISTINCT `Persoon`, `Datum` FROM `geboortedatum` WHERE `Persoon` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteplaats[Persoon*Plaats]","SELECT DISTINCT `Persoon`, `geboorteplaats` FROM `Persoon` WHERE `Persoon` IS NOT NULL AND `geboorteplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteland[Persoon*Land]","SELECT DISTINCT `Persoon`, `geboorteland` FROM `Persoon` WHERE `Persoon` IS NOT NULL AND `geboorteland` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaats[Persoon*Adres]","SELECT DISTINCT `Persoon`, `Adres` FROM `woonplaats` WHERE `Persoon` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geslacht[Persoon*Geslacht]","SELECT DISTINCT `Persoon`, `geslacht` FROM `Persoon` WHERE `Persoon` IS NOT NULL AND `geslacht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gba[Anummer*Persoon]","SELECT DISTINCT `Anummer`, `gba` FROM `Anummer` WHERE `Anummer` IS NOT NULL AND `gba` IS NOT NULL"));
      fwrite($dumpfile, dumprel("nationaliteit[Persoon*Nationaliteit]","SELECT DISTINCT `Persoon`, `Nationaliteit` FROM `nationaliteit2` WHERE `Persoon` IS NOT NULL AND `Nationaliteit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatie[Gebeurtenis*Plaats]","SELECT DISTINCT `Gebeurtenis`, `Plaats` FROM `locatie` WHERE `Gebeurtenis` IS NOT NULL AND `Plaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("datum[Gebeurtenis*Datum]","SELECT DISTINCT `Gebeurtenis`, `Datum` FROM `datum2` WHERE `Gebeurtenis` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ouder[Gebeurtenis]","SELECT DISTINCT `sGebeurtenis`, `tGebeurtenis` FROM `ouder` WHERE `sGebeurtenis` IS NOT NULL AND `tGebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("registerdemo", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\"",$str); }
      ?>