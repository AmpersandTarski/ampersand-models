<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass elsewhere
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('registerdemo')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `registerdemo` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('registerdemo');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'registerdemo'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Session timeout table
    if($columns = mysql_query("SHOW COLUMNS FROM `__SessionTimeout__`")){
        mysql_query("DROP TABLE `__SessionTimeout__`");
    }
    mysql_query("CREATE TABLE `__SessionTimeout__`
                         ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                         , `lastAccess` BIGINT NOT NULL
                          ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
    }
    mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                          ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 43
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijving`")){
        mysql_query("DROP TABLE `Inschrijving`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Persoon`")){
        mysql_query("DROP TABLE `Persoon`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kantoornummer`")){
        mysql_query("DROP TABLE `Kantoornummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Gebeurtenis`")){
        mysql_query("DROP TABLE `Gebeurtenis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Anummer`")){
        mysql_query("DROP TABLE `Anummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Document`")){
        mysql_query("DROP TABLE `Document`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Barnummer`")){
        mysql_query("DROP TABLE `Barnummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Nationaliteit1`")){
        mysql_query("DROP TABLE `Nationaliteit1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `nationaliteit2`")){
        mysql_query("DROP TABLE `nationaliteit2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Geslacht`")){
        mysql_query("DROP TABLE `Geslacht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Land`")){
        mysql_query("DROP TABLE `Land`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Plaats`")){
        mysql_query("DROP TABLE `Plaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Datum1`")){
        mysql_query("DROP TABLE `Datum1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `datum2`")){
        mysql_query("DROP TABLE `datum2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Titel`")){
        mysql_query("DROP TABLE `Titel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Burgerservicenummer`")){
        mysql_query("DROP TABLE `Burgerservicenummer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Naam1`")){
        mysql_query("DROP TABLE `Naam1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `naam2`")){
        mysql_query("DROP TABLE `naam2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Zoek`")){
        mysql_query("DROP TABLE `Zoek`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Kantoor`")){
        mysql_query("DROP TABLE `Kantoor`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Orgaan`")){
        mysql_query("DROP TABLE `Orgaan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Beslissing`")){
        mysql_query("DROP TABLE `Beslissing`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijvingseis`")){
        mysql_query("DROP TABLE `Inschrijvingseis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Adres`")){
        mysql_query("DROP TABLE `Adres`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Rechtbank`")){
        mysql_query("DROP TABLE `Rechtbank`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijvingsstatus1`")){
        mysql_query("DROP TABLE `Inschrijvingsstatus1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `inschrijvingsstatus2`")){
        mysql_query("DROP TABLE `inschrijvingsstatus2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `inschrijvingsverzoek`")){
        mysql_query("DROP TABLE `inschrijvingsverzoek`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schrapper`")){
        mysql_query("DROP TABLE `schrapper`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schrappingDoor`")){
        mysql_query("DROP TABLE `schrappingDoor`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schrapping`")){
        mysql_query("DROP TABLE `schrapping`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schorsing1`")){
        mysql_query("DROP TABLE `schorsing1`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schorsing2`")){
        mysql_query("DROP TABLE `schorsing2`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `schorsingOpheffen`")){
        mysql_query("DROP TABLE `schorsingOpheffen`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zoeken`")){
        mysql_query("DROP TABLE `zoeken`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zoekOpNaam`")){
        mysql_query("DROP TABLE `zoekOpNaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `zoekOpBAR`")){
        mysql_query("DROP TABLE `zoekOpBAR`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `adelijketitel`")){
        mysql_query("DROP TABLE `adelijketitel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `opleidingstitel`")){
        mysql_query("DROP TABLE `opleidingstitel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `geboortedatum`")){
        mysql_query("DROP TABLE `geboortedatum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `woonplaats`")){
        mysql_query("DROP TABLE `woonplaats`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `locatie`")){
        mysql_query("DROP TABLE `locatie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `ouder`")){
        mysql_query("DROP TABLE `ouder`");
      }
    }
    /**************************************\
    * Plug Inschrijving                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * advocaat  [UNI,TOT]                  *
    * ontvanger  [UNI,TOT]                 *
    * kantoorlocatie  [UNI,TOT]            *
    * inschrijvingseis  [UNI]              *
    * beëdigd  [UNI]                       *
    * houdtkantoor  [UNI]                  *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijving`
                     ( `Inschrijving` VARCHAR(255) DEFAULT NULL
                     , `advocaat` VARCHAR(255) DEFAULT NULL
                     , `ontvanger` VARCHAR(255) DEFAULT NULL
                     , `kantoorlocatie` VARCHAR(255) DEFAULT NULL
                     , `inschrijvingseis` VARCHAR(255) DEFAULT NULL
                     , `beëdigd` VARCHAR(255) DEFAULT NULL
                     , `houdtkantoor` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijving` (`Inschrijving` ,`advocaat` ,`ontvanger` ,`kantoorlocatie` ,`inschrijvingseis` ,`beëdigd` ,`houdtkantoor` )
                VALUES ('Inschrijving 1', '4', 'Rechtbank Amsterdam', 'Herengracht 425-429, 1017 BR, Amsterdam', 'voldoen', 'Be1', 'K52347')
                      , ('Inschrijving 2', '5', 'Rechtbank Rotterdam', 'Westblaak 5f, 3001 AC, Rotterdam', 'voldoen', 'Be2', 'K45317')
                      , ('Inschrijving 3', '6', 'Rechtbank Utrecht', 'Mariahoek 4, 3511 LD, Utrecht', 'voldoen', 'Be3', 'K48933')
                      , ('Inschrijving 4', '7', 'Rechtbank Utrecht', 'Herculesplein 213, 3584 AA, Utrecht', 'voldoen', 'Be4', 'K12493')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Persoon                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * bsn  [UNI,TOT]                       *
    * geboorteplaats  [UNI]                *
    * geboorteland  [UNI]                  *
    * geslacht  [UNI]                      *
    \**************************************/
    mysql_query("CREATE TABLE `Persoon`
                     ( `Persoon` VARCHAR(255) DEFAULT NULL
                     , `bsn` VARCHAR(255) DEFAULT NULL
                     , `geboorteplaats` VARCHAR(255) DEFAULT NULL
                     , `geboorteland` VARCHAR(255) DEFAULT NULL
                     , `geslacht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Persoon` (`Persoon` ,`bsn` ,`geboorteplaats` ,`geboorteland` ,`geslacht` )
                VALUES ('1', '23587435', 'Middelburg', 'Nederland', 'Man')
                      , ('2', '56327491', 'Veghel', 'Nederland', 'Man')
                      , ('3', '78954566', 'Stockholm', 'Zweden', 'Man')
                      , ('4', '14676455', 'Amsterdam', 'Nederland', 'Man')
                      , ('5', '58974564', 'Tilburg', 'Nederland', 'Man')
                      , ('6', '15876456', 'Spijkenisse', 'Nederland', 'Vrouw')
                      , ('7', '45896541', 'Haps', 'Nederland', 'Vrouw')
                      , ('8', '56975633', 'Enschede', 'Nederland', 'Man')
                      , ('9', '62096541', 'Heerenveen', 'Nederland', 'Man')
                      , ('10', '45031741', 'Utrecht', 'Nederland', 'Vrouw')
                      , ('11', '72896694', 'Arnhem', 'Nederland', 'Man')
                      , ('12', '63254896', 'Zwijndrecht', 'Nederland', 'Man')
                      , ('13', '45896310', '\'s-Gravenhage', 'Nederland', 'Man')
                      , ('14', '35497763', 'Zenderen', 'Nederland', 'Man')
                      , ('15', '79823438', 'Almelo', 'Nederland', 'Man')
                      , ('16', '46936557', 'Ittersum', 'Nederland', 'Man')
                      , ('17', '49876337', 'Heerenveen', 'Nederland', 'Man')
                      , ('18', '78974651', 'Almelo', 'Nederland', 'Vrouw')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kantoornummer                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * kantoor  [UNI]                       *
    * kantoornaam  [UNI,TOT]               *
    * kantooradres  [UNI,TOT]              *
    \**************************************/
    mysql_query("CREATE TABLE `Kantoornummer`
                     ( `Kantoornummer` VARCHAR(255) DEFAULT NULL
                     , `kantoor` VARCHAR(255) DEFAULT NULL
                     , `kantoornaam` VARCHAR(255) DEFAULT NULL
                     , `kantooradres` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kantoornummer` (`Kantoornummer` ,`kantoor` ,`kantoornaam` ,`kantooradres` )
                VALUES ('K52347', 'Rechtbank Amsterdam', 'Wieringa advocaten', 'Herengracht 425-429, 1017 BR, Amsterdam')
                      , ('K45317', 'Rechtbank Rotterdam', 'Haulussy advocaten', 'Westblaak 5f, 3001 AC, Rotterdam')
                      , ('K48933', 'Rechtbank Utrecht', 'Kuipers, Jonkers, van den Berg', 'Mariahoek 4, 3511 LD, Utrecht')
                      , ('K12493', 'Rechtbank Utrecht', 'ATM Advocaten Utrecht', 'Herculesplein 213, 3584 AA, Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Gebeurtenis                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * Beëdiging~  [INJ,SUR,UNI]            *
    * locatieBeëdiging  [UNI]              *
    \**************************************/
    mysql_query("CREATE TABLE `Gebeurtenis`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Beëdiging` VARCHAR(255) DEFAULT NULL
                     , `locatieBeëdiging` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gebeurtenis` (`Gebeurtenis` ,`Beëdiging` ,`locatieBeëdiging` )
                VALUES ('Be1', 'Be1', 'Rechtbank Amsterdam')
                      , ('Be2', 'Be2', 'Rechtbank Rotterdam')
                      , ('Be3', 'Be3', 'Rechtbank Utrecht')
                      , ('Be4', 'Be4', 'Rechtbank Utrecht')
                      , ('Ev739920', NULL, NULL)
                      , ('Ev930023', NULL, NULL)
                      , ('Ev456188', NULL, NULL)
                      , ('Ev695', NULL, NULL)
                      , ('Ev426', NULL, NULL)
                      , ('Ev336', NULL, NULL)
                      , ('Ev732491', NULL, NULL)
                      , ('Ev993123', NULL, NULL)
                      , ('Ev476228', NULL, NULL)
                      , ('Zitting RbsGr 35', NULL, NULL)
                      , ('Zitting RbLee 591', NULL, NULL)
                      , ('Zitting RbAlm 68', NULL, NULL)
                      , ('Msg598', NULL, NULL)
                      , ('Msg449', NULL, NULL)
                      , ('Msg779', NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Anummer                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * gba  [UNI]                           *
    \**************************************/
    mysql_query("CREATE TABLE `Anummer`
                     ( `Anummer` VARCHAR(255) DEFAULT NULL
                     , `gba` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Anummer` (`Anummer` ,`gba` )
                VALUES ('A1567845614', '1')
                      , ('A4587623462', '2')
                      , ('A3265123987', '3')
                      , ('A2598776542', '4')
                      , ('A5687765231', '5')
                      , ('A1002546886', '6')
                      , ('A6740656461', '7')
                      , ('A6547890374', '8')
                      , ('A1149890396', '9')
                      , ('A6539590322', '10')
                      , ('A3211890374', '11')
                      , ('A6565119819', '12')
                      , ('A5216056127', '13')
                      , ('A6131546842', '14')
                      , ('A1551215379', '15')
                      , ('A1168773213', '16')
                      , ('A1447945463', '7')
                      , ('A8374764583', '18')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Document                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * verzoeker  [UNI]                     *
    \**************************************/
    mysql_query("CREATE TABLE `Document`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `verzoeker` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Document` (`Document` ,`verzoeker` )
                VALUES ('Vti1', '4')
                      , ('Vti2', '5')
                      , ('Vti3', '6')
                      , ('Vti4', '7')
                      , ('Vts1', NULL)
                      , ('Vts3', NULL)
                      , ('Vts2', NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Barnummer                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * barnummer  [UNI,TOT]                 *
    \**************************************/
    mysql_query("CREATE TABLE `Barnummer`
                     ( `Barnummer0` VARCHAR(255) DEFAULT NULL
                     , `barnummer1` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Barnummer` (`Barnummer0` ,`barnummer1` )
                VALUES ('A23968', 'Inschrijving 1')
                      , ('A26815', 'Inschrijving 2')
                      , ('A16378', 'Inschrijving 3')
                      , ('A24763', 'Inschrijving 4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Nationaliteit1                  *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Nationaliteit1`
                     ( `Nationaliteit` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug nationaliteit2                    *
    *                                        *
    * fields:                                *
    * I/\nationaliteit;nationaliteit~  [ASY] *
    * nationaliteit  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `nationaliteit2`
                     ( `Persoon` VARCHAR(255) DEFAULT NULL
                     , `Nationaliteit` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Geslacht                        *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Geslacht`
                     ( `Geslacht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Geslacht` (`Geslacht` )
                VALUES ('Man')
                      , ('Vrouw')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Land                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Land`
                     ( `Land` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Land` (`Land` )
                VALUES ('Nederland')
                      , ('Zweden')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Plaats                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Plaats`
                     ( `Plaats` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Plaats` (`Plaats` )
                VALUES ('Middelburg')
                      , ('Veghel')
                      , ('Stockholm')
                      , ('Amsterdam')
                      , ('Tilburg')
                      , ('Spijkenisse')
                      , ('Haps')
                      , ('Enschede')
                      , ('Heerenveen')
                      , ('Utrecht')
                      , ('Arnhem')
                      , ('Zwijndrecht')
                      , ('\'s-Gravenhage')
                      , ('Zenderen')
                      , ('Almelo')
                      , ('Ittersum')
                      , ('Leeuwarden')
                      , ('Groningen')
                      , ('Rotterdam')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Datum1                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Datum1`
                     ( `Datum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Datum1` (`Datum` )
                VALUES ('12-10-1967')
                      , ('06-07-1980')
                      , ('31-02-1970')
                      , ('25-03-1962')
                      , ('01-05-1982')
                      , ('16-07-1976')
                      , ('12-11-1981')
                      , ('12-01-1959')
                      , ('25-02-1948')
                      , ('30-12-1955')
                      , ('04-07-1965')
                      , ('25-04-1975')
                      , ('03-05-1980')
                      , ('10-12-1968')
                      , ('27-11-1976')
                      , ('30-06-1984')
                      , ('15-02-1989')
                      , ('26-05-1980')
                      , ('23-05-2011')
                      , ('03-12-2010')
                      , ('12-09-2011')
                      , ('24-05-2011')
                      , ('06-12-2010')
                      , ('23-07-2011')
                      , ('12-12-2010')
                      , ('03-10-2011')
                      , ('25-08-1990')
                      , ('12-02-2009')
                      , ('06-10-2007')
                      , ('18-04-2009')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************\
    * Plug datum2            *
    *                        *
    * fields:                *
    * I/\datum;datum~  [ASY] *
    * datum  []              *
    \************************/
    mysql_query("CREATE TABLE `datum2`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `datum2` (`Gebeurtenis` ,`Datum` )
                VALUES ('Ev739920', '23-05-2011')
                      , ('Ev930023', '03-12-2010')
                      , ('Ev456188', '12-09-2011')
                      , ('Ev695', '24-05-2011')
                      , ('Ev426', '06-12-2010')
                      , ('Ev336', '12-09-2011')
                      , ('Ev732491', '23-07-2011')
                      , ('Ev993123', '12-12-2010')
                      , ('Ev476228', '03-10-2011')
                      , ('Zitting RbsGr 35', '23-05-2011')
                      , ('Zitting RbLee 591', '03-12-2010')
                      , ('Zitting RbAlm 68', '12-09-2011')
                      , ('Msg598', '24-05-2011')
                      , ('Msg449', '06-12-2010')
                      , ('Msg779', '12-09-2011')
                      , ('Be1', '25-08-1990')
                      , ('Be2', '12-02-2009')
                      , ('Be3', '06-10-2007')
                      , ('Be4', '18-04-2009')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Titel                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Titel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Titel` (`Titel` )
                VALUES ('Baron')
                      , ('mr')
                      , ('drs')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Burgerservicenummer             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Burgerservicenummer`
                     ( `Burgerservicenummer` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Burgerservicenummer` (`Burgerservicenummer` )
                VALUES ('23587435')
                      , ('56327491')
                      , ('78954566')
                      , ('14676455')
                      , ('58974564')
                      , ('15876456')
                      , ('45896541')
                      , ('56975633')
                      , ('62096541')
                      , ('45031741')
                      , ('72896694')
                      , ('63254896')
                      , ('45896310')
                      , ('35497763')
                      , ('79823438')
                      , ('46936557')
                      , ('49876337')
                      , ('78974651')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Naam1                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Naam1`
                     ( `Naam` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Naam1` (`Naam` )
                VALUES ('Peter Jansen')
                      , ('Eman Pietersen')
                      , ('Ola Sigursson')
                      , ('Sebastiaan Levelt')
                      , ('Ilja van Driel')
                      , ('Anne Dekkers')
                      , ('Lonneke Cox')
                      , ('Sascha Guillaume')
                      , ('Hendrik Pieter Cornelis van de Meene')
                      , ('Sandra Anne Wiltschut')
                      , ('Roeland Petrus Dijkstra')
                      , ('Frits Audeur')
                      , ('Bert Stolen')
                      , ('Olaf Elicht')
                      , ('Barend Eul')
                      , ('Tomas Sjesdief')
                      , ('Andre Angereden')
                      , ('Sanne Verhoeven')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************\
    * Plug naam2           *
    *                      *
    * fields:              *
    * I/\naam;naam~  [ASY] *
    * naam  []             *
    \**********************/
    mysql_query("CREATE TABLE `naam2`
                     ( `Persoon` VARCHAR(255) DEFAULT NULL
                     , `Naam` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `naam2` (`Persoon` ,`Naam` )
                VALUES ('1', 'Peter Jansen')
                      , ('2', 'Eman Pietersen')
                      , ('3', 'Ola Sigursson')
                      , ('4', 'Sebastiaan Levelt')
                      , ('5', 'Ilja van Driel')
                      , ('6', 'Anne Dekkers')
                      , ('7', 'Lonneke Cox')
                      , ('8', 'Sascha Guillaume')
                      , ('9', 'Hendrik Pieter Cornelis van de Meene')
                      , ('10', 'Sandra Anne Wiltschut')
                      , ('11', 'Roeland Petrus Dijkstra')
                      , ('12', 'Frits Audeur')
                      , ('13', 'Bert Stolen')
                      , ('14', 'Olaf Elicht')
                      , ('15', 'Barend Eul')
                      , ('16', 'Tomas Sjesdief')
                      , ('17', 'Andre Angereden')
                      , ('18', 'Sanne Verhoeven')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Zoek                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Zoek`
                     ( `Zoek` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Zoek` (`Zoek` )
                VALUES (NULL)
                      , ('Zoek')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Kantoor                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Kantoor`
                     ( `Kantoor` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Kantoor` (`Kantoor` )
                VALUES ('Wieringa advocaten')
                      , ('Haulussy advocaten')
                      , ('Kuipers, Jonkers, van den Berg')
                      , ('ATM Advocaten Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Orgaan                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Orgaan`
                     ( `Orgaan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Orgaan` (`Orgaan` )
                VALUES ('Raad van State')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Beslissing                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Beslissing`
                     ( `Beslissing` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Beslissing` (`Beslissing` )
                VALUES ('Vts2')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijvingseis                *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijvingseis`
                     ( `Inschrijvingseis` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijvingseis` (`Inschrijvingseis` )
                VALUES ('voldoen')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Adres                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Adres`
                     ( `Adres` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Adres` (`Adres` )
                VALUES ('Herengracht 425-429, 1017 BR, Amsterdam')
                      , ('Westblaak 5f, 3001 AC, Rotterdam')
                      , ('Mariahoek 4, 3511 LD, Utrecht')
                      , ('Herculesplein 213, 3584 AA, Utrecht')
                      , ('Noordbolwerk 33, 4331SH Middelburg')
                      , ('Westhavenkade 98, 3133AV Vlaardingen')
                      , ('Koornbeursweg 132, 8442DJ Heerenveen')
                      , ('Johannes Verhulststraat 55/HS, 1071MS Amsterdam')
                      , ('Kruisherenstraat 56, 3078GT Rotterdam')
                      , ('Gezichtslaan 52, 3723GG Bilthoven')
                      , ('Kalkhofseweg 25, 5443NB Haps')
                      , ('Weldammerbos 17, 7543GW Enschede')
                      , ('Zeedijken 42, 9919BM Loppersum')
                      , ('Erve Kokenberg 1, 7625NH Zenderen')
                      , ('Heimerstein 91, 3328MH Dordrecht')
                      , ('Thorbeckelaan 342, 2564BZ \'s-Gravenhage')
                      , ('Bornsestraat 28, 7556BG Hengelo ov')
                      , ('Hooizolder 386, 9205CW Drachten')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Rechtbank                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Rechtbank`
                     ( `Rechtbank` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Rechtbank` (`Rechtbank` )
                VALUES ('Rechtbank Amsterdam')
                      , ('Rechtbank Rotterdam')
                      , ('Rechtbank Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijvingsstatus1            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijvingsstatus1`
                     ( `Inschrijvingsstatus` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijvingsstatus1` (`Inschrijvingsstatus` )
                VALUES ('onvoorwaardelijk')
                      , ('voorwaardelijk')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************\
    * Plug inschrijvingsstatus2                          *
    *                                                    *
    * fields:                                            *
    * I/\inschrijvingsstatus;inschrijvingsstatus~  [ASY] *
    * inschrijvingsstatus  []                            *
    \****************************************************/
    mysql_query("CREATE TABLE `inschrijvingsstatus2`
                     ( `Inschrijving` VARCHAR(255) DEFAULT NULL
                     , `Inschrijvingsstatus` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `inschrijvingsstatus2` (`Inschrijving` ,`Inschrijvingsstatus` )
                VALUES ('Inschrijving 1', 'onvoorwaardelijk')
                      , ('Inschrijving 2', 'voorwaardelijk')
                      , ('Inschrijving 3', 'onvoorwaardelijk')
                      , ('Inschrijving 4', 'onvoorwaardelijk')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************************\
    * Plug inschrijvingsverzoek                            *
    *                                                      *
    * fields:                                              *
    * I/\inschrijvingsverzoek;inschrijvingsverzoek~  [ASY] *
    * inschrijvingsverzoek  []                             *
    \******************************************************/
    mysql_query("CREATE TABLE `inschrijvingsverzoek`
                     ( `Inschrijving` VARCHAR(255) DEFAULT NULL
                     , `Document` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `inschrijvingsverzoek` (`Inschrijving` ,`Document` )
                VALUES ('Inschrijving 1', 'Vti1')
                      , ('Inschrijving 2', 'Vti2')
                      , ('Inschrijving 3', 'Vti3')
                      , ('Inschrijving 4', 'Vti4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug schrapper                 *
    *                                *
    * fields:                        *
    * I/\schrapper;schrapper~  [ASY] *
    * schrapper  []                  *
    \********************************/
    mysql_query("CREATE TABLE `schrapper`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Inschrijving` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `schrapper` (`Document` ,`Inschrijving` )
                VALUES ('Vts1', 'Inschrijving 3')
                      , ('Vts3', 'Inschrijving 1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************\
    * Plug schrappingDoor                      *
    *                                          *
    * fields:                                  *
    * I/\schrappingDoor;schrappingDoor~  [ASY] *
    * schrappingDoor  []                       *
    \******************************************/
    mysql_query("CREATE TABLE `schrappingDoor`
                     ( `Beslissing` VARCHAR(255) DEFAULT NULL
                     , `Orgaan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `schrappingDoor` (`Beslissing` ,`Orgaan` )
                VALUES ('Vts2', 'Raad van State')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug schrapping                  *
    *                                  *
    * fields:                          *
    * I/\schrapping;schrapping~  [ASY] *
    * schrapping  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `schrapping`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Inschrijving` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `schrapping` (`Document` ,`Inschrijving` )
                VALUES ('Vts1', 'Inschrijving 3')
                      , ('Vts2', 'Inschrijving 2')
                      , ('Vts3', 'Inschrijving 1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug schorsing1                *
    *                                *
    * fields:                        *
    * I/\schorsing;schorsing~  [ASY] *
    * schorsing  []                  *
    \********************************/
    mysql_query("CREATE TABLE `schorsing1`
                     ( `Document` VARCHAR(255) DEFAULT NULL
                     , `Inschrijving` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug schorsing2                *
    *                                *
    * fields:                        *
    * I/\schorsing;schorsing~  [ASY] *
    * schorsing  []                  *
    \********************************/
    mysql_query("CREATE TABLE `schorsing2`
                     ( `Beslissing` VARCHAR(255) DEFAULT NULL
                     , `Orgaan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************************\
    * Plug schorsingOpheffen                         *
    *                                                *
    * fields:                                        *
    * I/\schorsingOpheffen;schorsingOpheffen~  [ASY] *
    * schorsingOpheffen  []                          *
    \************************************************/
    mysql_query("CREATE TABLE `schorsingOpheffen`
                     ( `Beslissing` VARCHAR(255) DEFAULT NULL
                     , `Orgaan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************\
    * Plug zoeken              *
    *                          *
    * fields:                  *
    * I/\zoeken;zoeken~  [ASY] *
    * zoeken  []               *
    \**************************/
    mysql_query("CREATE TABLE `zoeken`
                     ( `sZoek` VARCHAR(255) DEFAULT NULL
                     , `tZoek` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `zoeken` (`sZoek` ,`tZoek` )
                VALUES (NULL, 'Zoek')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug zoekOpNaam                  *
    *                                  *
    * fields:                          *
    * I/\zoekOpNaam;zoekOpNaam~  [ASY] *
    * zoekOpNaam  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `zoekOpNaam`
                     ( `Zoek` VARCHAR(255) DEFAULT NULL
                     , `Inschrijving` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************\
    * Plug zoekOpBAR                 *
    *                                *
    * fields:                        *
    * I/\zoekOpBAR;zoekOpBAR~  [ASY] *
    * zoekOpBAR  []                  *
    \********************************/
    mysql_query("CREATE TABLE `zoekOpBAR`
                     ( `Zoek` VARCHAR(255) DEFAULT NULL
                     , `Barnummer` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************\
    * Plug adelijketitel                     *
    *                                        *
    * fields:                                *
    * I/\adelijketitel;adelijketitel~  [ASY] *
    * adelijketitel  []                      *
    \****************************************/
    mysql_query("CREATE TABLE `adelijketitel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `adelijketitel` (`Titel` ,`Persoon` )
                VALUES ('Baron', '1')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************\
    * Plug opleidingstitel                       *
    *                                            *
    * fields:                                    *
    * I/\opleidingstitel;opleidingstitel~  [ASY] *
    * opleidingstitel  []                        *
    \********************************************/
    mysql_query("CREATE TABLE `opleidingstitel`
                     ( `Titel` VARCHAR(255) DEFAULT NULL
                     , `Persoon` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `opleidingstitel` (`Titel` ,`Persoon` )
                VALUES ('mr', '4')
                      , ('mr', '5')
                      , ('mr', '6')
                      , ('mr', '7')
                      , ('mr', '8')
                      , ('drs', '18')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug geboortedatum                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * geboortedatum  [TOT]                 *
    \**************************************/
    mysql_query("CREATE TABLE `geboortedatum`
                     ( `Persoon` VARCHAR(255) DEFAULT NULL
                     , `Datum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `geboortedatum` (`Persoon` ,`Datum` )
                VALUES ('1', '12-10-1967')
                      , ('2', '06-07-1980')
                      , ('3', '31-02-1970')
                      , ('4', '25-03-1962')
                      , ('5', '01-05-1982')
                      , ('6', '16-07-1976')
                      , ('7', '12-11-1981')
                      , ('8', '12-01-1959')
                      , ('9', '25-02-1948')
                      , ('10', '30-12-1955')
                      , ('11', '04-07-1965')
                      , ('12', '25-04-1975')
                      , ('13', '03-05-1980')
                      , ('14', '10-12-1968')
                      , ('15', '27-11-1976')
                      , ('16', '30-06-1984')
                      , ('17', '15-02-1989')
                      , ('18', '26-05-1980')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug woonplaats                  *
    *                                  *
    * fields:                          *
    * I/\woonplaats;woonplaats~  [ASY] *
    * woonplaats  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `woonplaats`
                     ( `Persoon` VARCHAR(255) DEFAULT NULL
                     , `Adres` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `woonplaats` (`Persoon` ,`Adres` )
                VALUES ('1', 'Noordbolwerk 33, 4331SH Middelburg')
                      , ('2', 'Westhavenkade 98, 3133AV Vlaardingen')
                      , ('3', 'Koornbeursweg 132, 8442DJ Heerenveen')
                      , ('4', 'Johannes Verhulststraat 55/HS, 1071MS Amsterdam')
                      , ('5', 'Kruisherenstraat 56, 3078GT Rotterdam')
                      , ('6', 'Gezichtslaan 52, 3723GG Bilthoven')
                      , ('7', 'Kalkhofseweg 25, 5443NB Haps')
                      , ('8', 'Weldammerbos 17, 7543GW Enschede')
                      , ('9', 'Koornbeursweg 132, 8442DJ Heerenveen')
                      , ('10', 'Zeedijken 42, 9919BM Loppersum')
                      , ('11', 'Erve Kokenberg 1, 7625NH Zenderen')
                      , ('12', 'Heimerstein 91, 3328MH Dordrecht')
                      , ('13', 'Thorbeckelaan 342, 2564BZ \'s-Gravenhage')
                      , ('14', 'Erve Kokenberg 1, 7625NH Zenderen')
                      , ('15', 'Bornsestraat 28, 7556BG Hengelo ov')
                      , ('16', 'Zeedijken 42, 9919BM Loppersum')
                      , ('17', 'Hooizolder 386, 9205CW Drachten')
                      , ('18', 'Westhavenkade 98, 3133AV Vlaardingen')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************\
    * Plug locatie               *
    *                            *
    * fields:                    *
    * I/\locatie;locatie~  [ASY] *
    * locatie  []                *
    \****************************/
    mysql_query("CREATE TABLE `locatie`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Plaats` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `locatie` (`Gebeurtenis` ,`Plaats` )
                VALUES ('Ev739920', '\'s-Gravenhage')
                      , ('Ev930023', 'Leeuwarden')
                      , ('Ev456188', 'Almelo')
                      , ('Ev695', '\'s-Gravenhage')
                      , ('Ev426', 'Leeuwarden')
                      , ('Ev336', 'Almelo')
                      , ('Ev732491', '\'s-Gravenhage')
                      , ('Ev993123', 'Groningen')
                      , ('Ev476228', 'Enschede')
                      , ('Zitting RbsGr 35', '\'s-Gravenhage')
                      , ('Zitting RbLee 591', 'Leeuwarden')
                      , ('Zitting RbAlm 68', 'Almelo')
                      , ('Msg598', '\'s-Gravenhage')
                      , ('Msg449', 'Leeuwarden')
                      , ('Msg779', 'Almelo')
                      , ('Be1', 'Amsterdam')
                      , ('Be2', 'Rotterdam')
                      , ('Be3', 'Utrecht')
                      , ('Be4', 'Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************\
    * Plug ouder             *
    *                        *
    * fields:                *
    * I/\ouder;ouder~  [ASY] *
    * ouder  [TRN,ASY]       *
    \************************/
    mysql_query("CREATE TABLE `ouder`
                     ( `sGebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `tGebeurtenis` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo '<div id="ResetSuccess"/>The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT RegisterDemo\n");
      fwrite($dumpfile, dumprel("advocaat[Inschrijving*Persoon]","SELECT DISTINCT `Inschrijving`, `advocaat` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `advocaat` IS NOT NULL"));
      fwrite($dumpfile, dumprel("barnummer[Barnummer*Inschrijving]","SELECT DISTINCT `Barnummer0`, `barnummer1` FROM `Barnummer` WHERE `Barnummer0` IS NOT NULL AND `barnummer1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsstatus[Inschrijving*Inschrijvingsstatus]","SELECT DISTINCT `Inschrijving`, `Inschrijvingsstatus` FROM `inschrijvingsstatus2` WHERE `Inschrijving` IS NOT NULL AND `Inschrijvingsstatus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verzoeker[Document*Persoon]","SELECT DISTINCT `Document`, `verzoeker` FROM `Document` WHERE `Document` IS NOT NULL AND `verzoeker` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsverzoek[Inschrijving*Document]","SELECT DISTINCT `Inschrijving`, `Document` FROM `inschrijvingsverzoek` WHERE `Inschrijving` IS NOT NULL AND `Document` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ontvanger[Inschrijving*Rechtbank]","SELECT DISTINCT `Inschrijving`, `ontvanger` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `ontvanger` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoorlocatie[Inschrijving*Adres]","SELECT DISTINCT `Inschrijving`, `kantoorlocatie` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `kantoorlocatie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingseis[Inschrijving*Inschrijvingseis]","SELECT DISTINCT `Inschrijving`, `inschrijvingseis` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `inschrijvingseis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beëdigd[Inschrijving*Beëdiging]","SELECT DISTINCT `Inschrijving`, `beëdigd` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `beëdigd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatieBeëdiging[Beëdiging*Rechtbank]","SELECT DISTINCT `Beëdiging`, `locatieBeëdiging` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `locatieBeëdiging` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrapper[Document*Inschrijving]","SELECT DISTINCT `Document`, `Inschrijving` FROM `schrapper` WHERE `Document` IS NOT NULL AND `Inschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrappingDoor[Beslissing*Orgaan]","SELECT DISTINCT `Beslissing`, `Orgaan` FROM `schrappingDoor` WHERE `Beslissing` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schrapping[Document*Inschrijving]","SELECT DISTINCT `Document`, `Inschrijving` FROM `schrapping` WHERE `Document` IS NOT NULL AND `Inschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("houdtkantoor[Inschrijving*Kantoornummer]","SELECT DISTINCT `Inschrijving`, `houdtkantoor` FROM `Inschrijving` WHERE `Inschrijving` IS NOT NULL AND `houdtkantoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoor[Kantoornummer*Rechtbank]","SELECT DISTINCT `Kantoornummer`, `kantoor` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsing[Document*Inschrijving]","SELECT DISTINCT `Document`, `Inschrijving` FROM `schorsing1` WHERE `Document` IS NOT NULL AND `Inschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsing[Beslissing*Orgaan]","SELECT DISTINCT `Beslissing`, `Orgaan` FROM `schorsing2` WHERE `Beslissing` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("schorsingOpheffen[Beslissing*Orgaan]","SELECT DISTINCT `Beslissing`, `Orgaan` FROM `schorsingOpheffen` WHERE `Beslissing` IS NOT NULL AND `Orgaan` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Beëdiging[Beëdiging*Gebeurtenis]","SELECT DISTINCT `Beëdiging`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Beëdiging` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantoornaam[Kantoornummer*Kantoor]","SELECT DISTINCT `Kantoornummer`, `kantoornaam` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantoornaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("kantooradres[Kantoornummer*Adres]","SELECT DISTINCT `Kantoornummer`, `kantooradres` FROM `Kantoornummer` WHERE `Kantoornummer` IS NOT NULL AND `kantooradres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoeken[Zoek]","SELECT DISTINCT `sZoek`, `tZoek` FROM `zoeken` WHERE `sZoek` IS NOT NULL AND `tZoek` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoekOpNaam[Zoek*Inschrijving]","SELECT DISTINCT `Zoek`, `Inschrijving` FROM `zoekOpNaam` WHERE `Zoek` IS NOT NULL AND `Inschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("zoekOpBAR[Zoek*Barnummer]","SELECT DISTINCT `Zoek`, `Barnummer` FROM `zoekOpBAR` WHERE `Zoek` IS NOT NULL AND `Barnummer` IS NOT NULL"));
      fwrite($dumpfile, dumprel("naam[Persoon*Naam]","SELECT DISTINCT `Persoon`, `Naam` FROM `naam2` WHERE `Persoon` IS NOT NULL AND `Naam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bsn[Persoon*Burgerservicenummer]","SELECT DISTINCT `Persoon`, `bsn` FROM `Persoon` WHERE `Persoon` IS NOT NULL AND `bsn` IS NOT NULL"));
      fwrite($dumpfile, dumprel("adelijketitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `adelijketitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("opleidingstitel[Titel*Persoon]","SELECT DISTINCT `Titel`, `Persoon` FROM `opleidingstitel` WHERE `Titel` IS NOT NULL AND `Persoon` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboortedatum[Persoon*Datum]","SELECT DISTINCT `Persoon`, `Datum` FROM `geboortedatum` WHERE `Persoon` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteplaats[Persoon*Plaats]","SELECT DISTINCT `Persoon`, `geboorteplaats` FROM `Persoon` WHERE `Persoon` IS NOT NULL AND `geboorteplaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geboorteland[Persoon*Land]","SELECT DISTINCT `Persoon`, `geboorteland` FROM `Persoon` WHERE `Persoon` IS NOT NULL AND `geboorteland` IS NOT NULL"));
      fwrite($dumpfile, dumprel("woonplaats[Persoon*Adres]","SELECT DISTINCT `Persoon`, `Adres` FROM `woonplaats` WHERE `Persoon` IS NOT NULL AND `Adres` IS NOT NULL"));
      fwrite($dumpfile, dumprel("geslacht[Persoon*Geslacht]","SELECT DISTINCT `Persoon`, `geslacht` FROM `Persoon` WHERE `Persoon` IS NOT NULL AND `geslacht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gba[Anummer*Persoon]","SELECT DISTINCT `Anummer`, `gba` FROM `Anummer` WHERE `Anummer` IS NOT NULL AND `gba` IS NOT NULL"));
      fwrite($dumpfile, dumprel("nationaliteit[Persoon*Nationaliteit]","SELECT DISTINCT `Persoon`, `Nationaliteit` FROM `nationaliteit2` WHERE `Persoon` IS NOT NULL AND `Nationaliteit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("locatie[Gebeurtenis*Plaats]","SELECT DISTINCT `Gebeurtenis`, `Plaats` FROM `locatie` WHERE `Gebeurtenis` IS NOT NULL AND `Plaats` IS NOT NULL"));
      fwrite($dumpfile, dumprel("datum[Gebeurtenis*Datum]","SELECT DISTINCT `Gebeurtenis`, `Datum` FROM `datum2` WHERE `Gebeurtenis` IS NOT NULL AND `Datum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ouder[Gebeurtenis]","SELECT DISTINCT `sGebeurtenis`, `tGebeurtenis` FROM `ouder` WHERE `sGebeurtenis` IS NOT NULL AND `tGebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("registerdemo", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
