AmpersandApp.controller('addObjectController', function($scope){
	
	$scope.selected = {}; // an empty object for temporary storing the typeahead selection
	
});