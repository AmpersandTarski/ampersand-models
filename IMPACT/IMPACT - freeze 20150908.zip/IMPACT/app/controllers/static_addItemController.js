AmpersandApp.controller('addItemController', function($scope){
	
	$scope.selected = { value : ''}; // an empty object for temporary storing the input values
	
});