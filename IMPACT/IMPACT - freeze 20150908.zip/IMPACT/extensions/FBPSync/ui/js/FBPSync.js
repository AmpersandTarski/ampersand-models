var app = angular.module('AmpersandApp');

AmpersandApp.config(function($routeProvider) {
	$routeProvider
		// default start page
		.when('/ext/FBPSync',
			{
				controller: 'FBPSyncController'
			,	templateUrl: 'extensions/FBPSync/ui/views/FBPSync.html'
			,	interfaceLabel: 'FBP Sync'
			});
});

AmpersandApp.controller('FBPSyncController', function ($scope, $rootScope) {

});
