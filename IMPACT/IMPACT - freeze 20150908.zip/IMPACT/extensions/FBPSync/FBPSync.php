<?php
date_default_timezone_set('Europe/London');
//require_once (__DIR__ . '/lib/Classes/PHPExcel.php');

$apps[] = array('url' => 'extensions/FBPSync/ui/views/MenuItem.html'); // activeer app extension in framework

// UI
$GLOBALS['hooks']['after_Viewer_load_cssFiles'][] = 'extensions/FBPSync/ui/css/style.css';
$GLOBALS['hooks']['after_Viewer_load_angularScripts'][] = 'extensions/FBPSync/ui/js/FBPSync.js';

class FBPSync {
	private $db;

	function __construct() {
		$this->db = Database::singleton();
	}
}

?>
