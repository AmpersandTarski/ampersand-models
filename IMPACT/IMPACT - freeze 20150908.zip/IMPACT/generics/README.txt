All generated files will be placed in this folder. This includes:
|- app
|  |- RouteProvider.js (contains part of the routeProvider config that mathes URL path to controllers and views
|  |- controllers
|  |  |- (folder contains all controllers, 1 controller for every interface)
|  |- views
|     |- (folder contains all html views, 1 view for every interface)
|- dbSettings.php (contains database settings, needed for InstallerDBstruct.php and InstallerDefPop.php)
|- Generics.php (contains ampersand model, needed by the framework)
|- InstallerDBstruct.php (file with SQL queries that create the database structure)
|- InstallerDefPop.php (file with SQL queries that populates the database with the included population)