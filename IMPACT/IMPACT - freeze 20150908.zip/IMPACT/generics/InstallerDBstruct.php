<?php
// Try to connect to the database

include "dbSettings.php";

$DB_name='ampersand_impact';
$DB_link = mysqli_connect($DB_host,$DB_user,$DB_pass);
// Check connection
if (mysqli_connect_errno()) {
  die("Failed to connect to MySQL: " . mysqli_connect_error());
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

// Drop the database if it exists
$sql="DROP DATABASE $DB_name";
mysqli_query($DB_link,$sql);
// Don't bother about the error if the database didn't exist...

// Create the database
$sql="CREATE DATABASE $DB_name DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN";
if (!mysqli_query($DB_link,$sql)) {
  die("Error creating the database: " . mysqli_error($DB_link));
  }

// Connect to the freshly created database
$DB_link = mysqli_connect($DB_host,$DB_user,$DB_pass,$DB_name);
// Check connection
if (mysqli_connect_errno()) {
  die("Failed to connect to the database: " . mysqli_connect_error());
  }

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/*** Create new SQL tables ***/

// Session timeout table
if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `__SessionTimeout__`')){
    mysqli_query($DB_link, 'DROP TABLE `__SessionTimeout__`');
}
mysqli_query($DB_link,"CREATE TABLE `__SessionTimeout__`
                       ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                       , `lastAccess` BIGINT NOT NULL
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

// Timestamp table
if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `__History__`')){
    mysqli_query($DB_link, 'DROP TABLE `__History__`');
}
mysqli_query($DB_link,"CREATE TABLE `__History__`
                       ( `Seconds` VARCHAR(255) DEFAULT NULL
                       , `Date` VARCHAR(255) DEFAULT NULL
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

$time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
$microseconds = substr($time[0], 2,6);
$seconds =$time[1].$microseconds;
date_default_timezone_set("Europe/Amsterdam");
$date = date("j-M-Y, H:i:s.").$microseconds;
mysqli_query($DB_link, "INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

// Signal table
if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `__all_signals__`')){
    mysqli_query($DB_link, 'DROP TABLE `__all_signals__`');
}
mysqli_query($DB_link,"CREATE TABLE `__all_signals__`
                       ( `conjId` VARCHAR(255) NOT NULL
                       , `src` VARCHAR(255) NOT NULL
                       , `tgt` VARCHAR(255) NOT NULL
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }


//// Number of plugs: 22
/******************************************************\
* Plug Scope                                           *
*                                                      *
* fields:                                              *
* I[Scope]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]          *
* scopeNewComponentFromTemplate  [UNI]                 *
* scopeNewInputPortName  [UNI]                         *
* scopeNewOutputPortName  [UNI]                        *
* scopeNewConstantforPort  [UNI]                       *
* scopeNewWireSrc  [UNI]                               *
* scopeNewWireTgt  [UNI]                               *
* scopeDeleteWire  [UNI]                               *
* scopeICO  [UNI,IRF,ASY]                              *
* scopeID  [UNI]                                       *
* scopeName  [UNI,TOT]                                 *
* scopeOrg  [UNI]                                      *
* scopeIPO  [UNI,IRF,ASY,TOT,SUR]                      *
* scopeIsComponent  [SYM,ASY,UNI,INJ,TOT,SUR]          *
* scopeIsaSubScope  [SYM,ASY,UNI,INJ]                  *
* projApplications~  [UNI]                             *
* scopeDoc  [UNI]                                      *
* scopeAllConfigQuestionsAreDefined  [SYM,ASY,UNI,INJ] *
* scopeIsConfigured  [SYM,ASY,UNI,INJ]                 *
* counterHasCountedScope~  [UNI]                       *
* scopeSeqNr  [UNI]                                    *
\******************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Scope`')){
    mysqli_query($DB_link, 'DROP TABLE `Scope`');
}
mysqli_query($DB_link,"CREATE TABLE `Scope`
                       ( `Scope` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeNewComponentFromTemplate` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeNewInputPortName` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeNewOutputPortName` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeNewConstantforPort` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeNewWireSrc` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeNewWireTgt` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeDeleteWire` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeICO` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeID` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeName` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeOrg` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeIPO` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeIsComponent` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeIsaSubScope` VARCHAR(255) DEFAULT NULL
                       , `src_projApplications` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeDoc` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeAllConfigQuestionsAreDefined` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeIsConfigured` VARCHAR(255) DEFAULT NULL
                       , `src_counterHasCountedScope` VARCHAR(255) DEFAULT NULL
                       , `tgt_scopeSeqNr` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Scope`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/********************************************\
* Plug Port                                  *
*                                            *
* fields:                                    *
* I[Port]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* portICO  [UNI,IRF,ASY]                     *
* portID  [UNI]                              *
* portName  [UNI,TOT,SUR]                    *
* portComponent  [UNI,TOT,SUR]               *
* portIsConst  [SYM,ASY,UNI,INJ]             *
* portIsInput  [SYM,ASY,UNI,INJ,TOT,SUR]     *
* portIsOutput  [SYM,ASY,UNI,INJ,TOT,SUR]    *
* portDefValue  [UNI]                        *
* portType  [UNI]                            *
* portConfigQstn  [UNI]                      *
* portMinWires  [UNI]                        *
* portMaxWires  [UNI]                        *
* constPort~  [UNI,SUR]                      *
* portDoc  [UNI]                             *
* counterHasCountedPort~  [UNI]              *
* portSeqNr  [UNI]                           *
\********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Port`')){
    mysqli_query($DB_link, 'DROP TABLE `Port`');
}
mysqli_query($DB_link,"CREATE TABLE `Port`
                       ( `Port` VARCHAR(255) DEFAULT NULL
                       , `tgt_portICO` VARCHAR(255) DEFAULT NULL
                       , `tgt_portID` VARCHAR(255) DEFAULT NULL
                       , `tgt_portName` VARCHAR(255) DEFAULT NULL
                       , `tgt_portComponent` VARCHAR(255) DEFAULT NULL
                       , `tgt_portIsConst` VARCHAR(255) DEFAULT NULL
                       , `tgt_portIsInput` VARCHAR(255) DEFAULT NULL
                       , `tgt_portIsOutput` VARCHAR(255) DEFAULT NULL
                       , `tgt_portDefValue` VARCHAR(255) DEFAULT NULL
                       , `tgt_portType` VARCHAR(255) DEFAULT NULL
                       , `tgt_portConfigQstn` VARCHAR(255) DEFAULT NULL
                       , `tgt_portMinWires` VARCHAR(255) DEFAULT NULL
                       , `tgt_portMaxWires` VARCHAR(255) DEFAULT NULL
                       , `src_constPort` VARCHAR(255) DEFAULT NULL
                       , `tgt_portDoc` VARCHAR(255) DEFAULT NULL
                       , `src_counterHasCountedPort` VARCHAR(255) DEFAULT NULL
                       , `tgt_portSeqNr` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Port`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/***********************************************\
* Plug SESSION                                  *
*                                               *
* fields:                                       *
* I[SESSION]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* sessionNewProject  [UNI]                      *
* sessionCreateNamedApplication  [UNI]          *
* sessionCopyApplicationName  [UNI]             *
* sessionCopyApplicationFrom  [UNI]             *
* sessionCreateNamedComponent  [UNI]            *
* sessionCopyComponentName  [UNI]               *
* sessionCopyComponentFrom  [UNI]               *
\***********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `SESSION`')){
    mysqli_query($DB_link, 'DROP TABLE `SESSION`');
}
mysqli_query($DB_link,"CREATE TABLE `SESSION`
                       ( `SESSION` VARCHAR(255) DEFAULT NULL
                       , `tgt_sessionNewProject` VARCHAR(255) DEFAULT NULL
                       , `tgt_sessionCreateNamedApplication` VARCHAR(255) DEFAULT NULL
                       , `tgt_sessionCopyApplicationName` VARCHAR(255) DEFAULT NULL
                       , `tgt_sessionCopyApplicationFrom` VARCHAR(255) DEFAULT NULL
                       , `tgt_sessionCreateNamedComponent` VARCHAR(255) DEFAULT NULL
                       , `tgt_sessionCopyComponentName` VARCHAR(255) DEFAULT NULL
                       , `tgt_sessionCopyComponentFrom` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`SESSION`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/************************************************\
* Plug Constant                                  *
*                                                *
* fields:                                        *
* I[Constant]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* constICO  [UNI,IRF,ASY]                        *
* constName  [UNI,TOT]                           *
* constScope  [UNI]                              *
* constType  [UNI]                               *
* constValue  [UNI]                              *
* constQstn  [UNI]                               *
* constDoc  [UNI]                                *
\************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Constant`')){
    mysqli_query($DB_link, 'DROP TABLE `Constant`');
}
mysqli_query($DB_link,"CREATE TABLE `Constant`
                       ( `Constant` VARCHAR(255) DEFAULT NULL
                       , `tgt_constICO` VARCHAR(255) DEFAULT NULL
                       , `tgt_constName` VARCHAR(255) DEFAULT NULL
                       , `tgt_constScope` VARCHAR(255) DEFAULT NULL
                       , `tgt_constType` VARCHAR(255) DEFAULT NULL
                       , `tgt_constValue` VARCHAR(255) DEFAULT NULL
                       , `tgt_constQstn` VARCHAR(255) DEFAULT NULL
                       , `tgt_constDoc` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Constant`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/********************************************\
* Plug Wire                                  *
*                                            *
* fields:                                    *
* I[Wire]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* wICO  [UNI,IRF,ASY]                        *
* wSrcRef  [UNI]                             *
* wTgtRef  [UNI]                             *
* wScope  [UNI,TOT]                          *
* wSrc  [UNI,TOT]                            *
\********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Wire`')){
    mysqli_query($DB_link, 'DROP TABLE `Wire`');
}
mysqli_query($DB_link,"CREATE TABLE `Wire`
                       ( `Wire` VARCHAR(255) DEFAULT NULL
                       , `tgt_wICO` VARCHAR(255) DEFAULT NULL
                       , `tgt_wSrcRef` VARCHAR(255) DEFAULT NULL
                       , `tgt_wTgtRef` VARCHAR(255) DEFAULT NULL
                       , `tgt_wScope` VARCHAR(255) DEFAULT NULL
                       , `tgt_wSrc` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Wire`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/***********************************************\
* Plug Project                                  *
*                                               *
* fields:                                       *
* I[Project]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* projCreateNamedApplication  [UNI]             *
* projCopyApplicationName  [UNI]                *
* projCopyApplicationFrom  [UNI]                *
* projName  [UNI,TOT]                           *
* projDoc  [UNI]                                *
\***********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Project`')){
    mysqli_query($DB_link, 'DROP TABLE `Project`');
}
mysqli_query($DB_link,"CREATE TABLE `Project`
                       ( `Project` VARCHAR(255) DEFAULT NULL
                       , `tgt_projCreateNamedApplication` VARCHAR(255) DEFAULT NULL
                       , `tgt_projCopyApplicationName` VARCHAR(255) DEFAULT NULL
                       , `tgt_projCopyApplicationFrom` VARCHAR(255) DEFAULT NULL
                       , `tgt_projName` VARCHAR(255) DEFAULT NULL
                       , `tgt_projDoc` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Project`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/***********************************************\
* Plug Counter                                  *
*                                               *
* fields:                                       *
* I[Counter]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* counterScope  [UNI]                           *
* counterName  [UNI,TOT]                        *
* counterValue  [UNI]                           *
* counterComponent  [UNI]                       *
\***********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Counter`')){
    mysqli_query($DB_link, 'DROP TABLE `Counter`');
}
mysqli_query($DB_link,"CREATE TABLE `Counter`
                       ( `Counter` VARCHAR(255) DEFAULT NULL
                       , `tgt_counterScope` VARCHAR(255) DEFAULT NULL
                       , `tgt_counterName` VARCHAR(255) DEFAULT NULL
                       , `tgt_counterValue` VARCHAR(255) DEFAULT NULL
                       , `tgt_counterComponent` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Counter`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/****************************************************\
* Plug Name                                          *
*                                                    *
* fields:                                            *
* I[Name]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]         *
* I[ScopeName]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]    *
* I[PortName]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]     *
* I[ConstantName]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* I[ProjectName]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]  *
\****************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Name`')){
    mysqli_query($DB_link, 'DROP TABLE `Name`');
}
mysqli_query($DB_link,"CREATE TABLE `Name`
                       ( `Name` VARCHAR(255) DEFAULT NULL
                       , `ScopeName` VARCHAR(255) DEFAULT NULL
                       , `PortName` VARCHAR(255) DEFAULT NULL
                       , `ConstantName` VARCHAR(255) DEFAULT NULL
                       , `ProjectName` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Name`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/*****************************************************\
* Plug Documentation                                  *
*                                                     *
* fields:                                             *
* I[Documentation]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* docICO  [UNI,IRF,ASY]                               *
* docShort  [UNI]                                     *
* docLong  [UNI]                                      *
\*****************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Documentation`')){
    mysqli_query($DB_link, 'DROP TABLE `Documentation`');
}
mysqli_query($DB_link,"CREATE TABLE `Documentation`
                       ( `Documentation` VARCHAR(255) DEFAULT NULL
                       , `tgt_docICO` VARCHAR(255) DEFAULT NULL
                       , `tgt_docShort` VARCHAR(255) DEFAULT NULL
                       , `tgt_docLong` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Documentation`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/***********************************************\
* Plug PortRef                                  *
*                                               *
* fields:                                       *
* I[PortRef]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* prComponent  [UNI,TOT]                        *
* prPortName  [UNI,TOT]                         *
\***********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `PortRef`')){
    mysqli_query($DB_link, 'DROP TABLE `PortRef`');
}
mysqli_query($DB_link,"CREATE TABLE `PortRef`
                       ( `PortRef` VARCHAR(255) DEFAULT NULL
                       , `tgt_prComponent` VARCHAR(255) DEFAULT NULL
                       , `tgt_prPortName` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`PortRef`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/******************************************************\
* Plug Question                                        *
*                                                      *
* fields:                                              *
* I[Question]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]       *
* I[ConfigQuestion]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\******************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Question`')){
    mysqli_query($DB_link, 'DROP TABLE `Question`');
}
mysqli_query($DB_link,"CREATE TABLE `Question`
                       ( `Question` VARCHAR(255) DEFAULT NULL
                       , `ConfigQuestion` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Question`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/***********************************************\
* Plug Message                                  *
*                                               *
* fields:                                       *
* I[Message]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\***********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Message`')){
    mysqli_query($DB_link, 'DROP TABLE `Message`');
}
mysqli_query($DB_link,"CREATE TABLE `Message`
                       ( `Message` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Message`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/******************************************************\
* Plug DocDescription                                  *
*                                                      *
* fields:                                              *
* I[DocDescription]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\******************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `DocDescription`')){
    mysqli_query($DB_link, 'DROP TABLE `DocDescription`');
}
mysqli_query($DB_link,"CREATE TABLE `DocDescription`
                       ( `DocDescription` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`DocDescription`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/**************************************************\
* Plug DocSummary                                  *
*                                                  *
* fields:                                          *
* I[DocSummary]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\**************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `DocSummary`')){
    mysqli_query($DB_link, 'DROP TABLE `DocSummary`');
}
mysqli_query($DB_link,"CREATE TABLE `DocSummary`
                       ( `DocSummary` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`DocSummary`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/***********************************************\
* Plug Integer                                  *
*                                               *
* fields:                                       *
* I[Integer]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\***********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Integer`')){
    mysqli_query($DB_link, 'DROP TABLE `Integer`');
}
mysqli_query($DB_link,"CREATE TABLE `Integer`
                       ( `Integer` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Integer`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/***************************************************\
* Plug ConfigValue                                  *
*                                                   *
* fields:                                           *
* I[ConfigValue]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\***************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `ConfigValue`')){
    mysqli_query($DB_link, 'DROP TABLE `ConfigValue`');
}
mysqli_query($DB_link,"CREATE TABLE `ConfigValue`
                       ( `ConfigValue` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`ConfigValue`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/****************************************************\
* Plug Organization                                  *
*                                                    *
* fields:                                            *
* I[Organization]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\****************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Organization`')){
    mysqli_query($DB_link, 'DROP TABLE `Organization`');
}
mysqli_query($DB_link,"CREATE TABLE `Organization`
                       ( `Organization` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`Organization`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/**************************************************\
* Plug ConfigType                                  *
*                                                  *
* fields:                                          *
* I[ConfigType]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\**************************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `ConfigType`')){
    mysqli_query($DB_link, 'DROP TABLE `ConfigType`');
}
mysqli_query($DB_link,"CREATE TABLE `ConfigType`
                       ( `ConfigType` VARCHAR(255) DEFAULT NULL
                       , PRIMARY KEY (`ConfigType`)
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/*******************************\
* Plug wPorts                   *
*                               *
* fields:                       *
* I[Wire] /\ wPorts;wPorts~  [] *
* wPorts  []                    *
\*******************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `wPorts`')){
    mysqli_query($DB_link, 'DROP TABLE `wPorts`');
}
mysqli_query($DB_link,"CREATE TABLE `wPorts`
                       ( `Wire` VARCHAR(255) DEFAULT NULL
                       , `Port` VARCHAR(255) DEFAULT NULL
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/********************************************\
* Plug scopeIPOPlus                          *
*                                            *
* fields:                                    *
* I[Scope] /\ scopeIPOPlus;scopeIPOPlus~  [] *
* scopeIPOPlus  [IRF,ASY]                    *
\********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `scopeIPOPlus`')){
    mysqli_query($DB_link, 'DROP TABLE `scopeIPOPlus`');
}
mysqli_query($DB_link,"CREATE TABLE `scopeIPOPlus`
                       ( `SrcScope` VARCHAR(255) DEFAULT NULL
                       , `TgtScope` VARCHAR(255) DEFAULT NULL
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/********************************************\
* Plug scopeIPOCopy                          *
*                                            *
* fields:                                    *
* I[Scope] /\ scopeIPOCopy;scopeIPOCopy~  [] *
* scopeIPOCopy  []                           *
\********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `scopeIPOCopy`')){
    mysqli_query($DB_link, 'DROP TABLE `scopeIPOCopy`');
}
mysqli_query($DB_link,"CREATE TABLE `scopeIPOCopy`
                       ( `SrcScope` VARCHAR(255) DEFAULT NULL
                       , `TgtScope` VARCHAR(255) DEFAULT NULL
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

/********************************************\
* Plug wTgt                                  *
*                                            *
* fields:                                    *
* I[Wire]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* wTgt  [TOT]                                *
\********************************************/

if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `wTgt`')){
    mysqli_query($DB_link, 'DROP TABLE `wTgt`');
}
mysqli_query($DB_link,"CREATE TABLE `wTgt`
                       ( `Wire` VARCHAR(255) DEFAULT NULL
                       , `Port` VARCHAR(255) DEFAULT NULL
                       ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8 DEFAULT COLLATE UTF8_BIN");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

mysqli_query($DB_link,'SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
?>
