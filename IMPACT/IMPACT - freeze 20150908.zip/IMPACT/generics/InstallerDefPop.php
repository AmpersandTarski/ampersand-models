<?php
// Connect to the database
include "dbSettings.php";

$DB_link = mysqli_connect($DB_host,$DB_user,$DB_pass,$DB_name);
// Check connection
if (mysqli_connect_errno()) {
  die("Failed to connect to the database: " . mysqli_connect_error());
  }
$error=false;
$sql="SET SESSION sql_mode = 'ANSI,TRADITIONAL'";
if (!mysqli_query($DB_link,$sql)) {
  die("Error setting sql_mode: " . mysqli_error($DB_link));
  }

mysqli_query($DB_link, 'INSERT INTO `SESSION` (`SESSION`,`tgt_sessionNewProject`,`tgt_sessionCreateNamedApplication`,`tgt_sessionCopyApplicationName`,`tgt_sessionCopyApplicationFrom`,`tgt_sessionCreateNamedComponent`,`tgt_sessionCopyComponentName`,`tgt_sessionCopyComponentFrom`)
                 VALUES (\'_SESSION\', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
mysqli_query($DB_link, 'INSERT INTO `Message` (`Message`)
                 VALUES (\'Input\')
                      , (\'Output\')
                      , (\'Input port\')
                      , (\'Output port\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
mysqli_query($DB_link, 'INSERT INTO `ConfigType` (`ConfigType`)
                 VALUES (\'float\')
                      , (\'boolean\')
                      , (\'string\')
                      , (\'integer\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
?>
