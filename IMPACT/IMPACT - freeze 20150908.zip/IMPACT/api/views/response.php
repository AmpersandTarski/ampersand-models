<?php
echo $basePath;