<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="cache-Control" content="no-cache">

</html>
<body>
<?php
// Try to connect to the database

include "dbSettings.php";

$DB_name='HRM';
$DB_link = mysqli_connect($DB_host,$DB_user,$DB_pass);
// Check connection
if (mysqli_connect_errno()) {
  die("Failed to connect to MySQL: " . mysqli_connect_error());
}

// Drop the database if it exists
$sql="DROP DATABASE $DB_name";
mysqli_query($DB_link,$sql);
// Don't bother about the error if the database didn't exist...

// Create the database
$sql="CREATE DATABASE $DB_name DEFAULT CHARACTER SET UTF8";
if (!mysqli_query($DB_link,$sql)) {
  die("Error creating the database: " . mysqli_error($DB_link));
  }
// Connect to the freshly created database
$DB_link = mysqli_connect($DB_host,$DB_user,$DB_pass,$DB_name);
// Check connection
if (mysqli_connect_errno()) {
  die("Failed to connect to the database: " . mysqli_connect_error());
}

/*** Create new SQL tables ***/

// Session timeout table
if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `__SessionTimeout__`')){
    mysqli_query($DB_link, 'DROP TABLE `__SessionTimeout__`');
}
mysqli_query($DB_link,"CREATE TABLE `__SessionTimeout__`
                     ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                     , `lastAccess` BIGINT NOT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

// Timestamp table
if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `__History__`')){
    mysqli_query($DB_link, 'DROP TABLE `__History__`');
}
mysqli_query($DB_link,"CREATE TABLE `__History__`
                     ( `Seconds` VARCHAR(255) DEFAULT NULL
                     , `Date` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}
$time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
$microseconds = substr($time[0], 2,6);
$seconds =$time[1].$microseconds;
date_default_timezone_set("Europe/Amsterdam");
$date = date("j-M-Y, H:i:s.").$microseconds;
mysqli_query($DB_link, "INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
if($err=mysqli_error($DB_link)) {
  $error=true; echo $err.'<br />';
}

//// Number of plugs: 15
if(true){
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Equipment`')){
    mysqli_query($DB_link, 'DROP TABLE `Equipment`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Employee`')){
    mysqli_query($DB_link, 'DROP TABLE `Employee`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `EqtType`')){
    mysqli_query($DB_link, 'DROP TABLE `EqtType`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Name`')){
    mysqli_query($DB_link, 'DROP TABLE `Name`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `Status`')){
    mysqli_query($DB_link, 'DROP TABLE `Status`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `EqtSerial`')){
    mysqli_query($DB_link, 'DROP TABLE `EqtSerial`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `EqtMake`')){
    mysqli_query($DB_link, 'DROP TABLE `EqtMake`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `OrgFunction`')){
    mysqli_query($DB_link, 'DROP TABLE `OrgFunction`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `EqtKind`')){
    mysqli_query($DB_link, 'DROP TABLE `EqtKind`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `needsToReturnEqt`')){
    mysqli_query($DB_link, 'DROP TABLE `needsToReturnEqt`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `allNecessaryEqtHasBeenIssued`')){
    mysqli_query($DB_link, 'DROP TABLE `allNecessaryEqtHasBeenIssued`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `noNecessaryEqtHasBeenIssued`')){
    mysqli_query($DB_link, 'DROP TABLE `noNecessaryEqtHasBeenIssued`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `orgfuncReqdEqtKind`')){
    mysqli_query($DB_link, 'DROP TABLE `orgfuncReqdEqtKind`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `emplOrgFunction`')){
    mysqli_query($DB_link, 'DROP TABLE `emplOrgFunction`');
  }
  if($columns = mysqli_query($DB_link, 'SHOW COLUMNS FROM `emplIssuedEqt`')){
    mysqli_query($DB_link, 'DROP TABLE `emplIssuedEqt`');
  }
}
/*************************************************\
* Plug Equipment                                  *
*                                                 *
* fields:                                         *
* I[Equipment]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* eqtMake  [UNI,TOT]                              *
* eqtType  [UNI,TOT]                              *
* eqtSerial  [UNI,TOT]                            *
* eqtKind  [UNI,TOT]                              *
\*************************************************/
mysqli_query($DB_link,"CREATE TABLE `Equipment`
                 ( `Equipment` VARCHAR(255) DEFAULT NULL
                 , `eqtMake` VARCHAR(255) DEFAULT NULL
                 , `eqtType` VARCHAR(255) DEFAULT NULL
                 , `eqtSerial` VARCHAR(255) DEFAULT NULL
                 , `eqtKind` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`Equipment`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `Equipment` (`Equipment`,`eqtMake`,`eqtType`,`eqtSerial`,`eqtKind`)
                 VALUES (\'Eqt_XEROX_1\', \'XEROX\', \'Mobile\', \'0693826586\', \'Phonenumber\')
                      , (\'Eqt_XEROX_2\', \'XEROX\', \'Mobile\', \'0682746586\', \'Phonenumber\')
                      , (\'Eqt_XEROX_3\', \'XEROX\', \'Mobile\', \'0698274586\', \'Phonenumber\')
                      , (\'Eqt_XEROX_4\', \'XEROX\', \'Mobile\', \'0693827666\', \'Phonenumber\')
                      , (\'Eqt_XEROX_5\', \'XEROX\', \'Mobile\', \'0693555586\', \'Phonenumber\')
                      , (\'Eqt_Cellphone1\', \'Nokia\', \'N32\', \'407-21\', \'Cellphone\')
                      , (\'Eqt_Cellphone2\', \'Nokia\', \'N32\', \'169-07\', \'Cellphone\')
                      , (\'Eqt_Cellphone3\', \'Apple\', \'iPhone III\', \'245-23\', \'Cellphone\')
                      , (\'Eqt_Cellphone4\', \'Apple\', \'iPhone II\', \'803-44\', \'Cellphone\')
                      , (\'Eqt_Dell1\', \'Dell\', \'Latitude D30\', \'5492921\', \'Computer\')
                      , (\'Eqt_Dell2\', \'Dell\', \'Latitude D30\', \'1394597\', \'Computer\')
                      , (\'Eqt_Dell3\', \'Apple\', \'MacBook\', \'11223\', \'Computer\')
                      , (\'Eqt_Dell4\', \'Apple\', \'MacBook Pro\', \'39624\', \'Computer\')
                      , (\'Eqt_Car1\', \'Volkswagen\', \'Passat\', \'1-TNO-23\', \'Car\')
                      , (\'Eqt_Car2\', \'Volkswagen\', \'Polo\', \'1-TNO-24\', \'Car\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/************************************************\
* Plug Employee                                  *
*                                                *
* fields:                                        *
* I[Employee]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
* emplStatus  [UNI]                              *
* emplName  [UNI]                                *
\************************************************/
mysqli_query($DB_link,"CREATE TABLE `Employee`
                 ( `Employee` VARCHAR(255) DEFAULT NULL
                 , `emplStatus` VARCHAR(255) DEFAULT NULL
                 , `emplName` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`Employee`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `Employee` (`Employee`,`emplStatus`,`emplName`)
                 VALUES (\'Empl_1\', NULL, \'Jean-Pierre Chanod\')
                      , (\'Empl_2\', NULL, \'Jan Klaassen\')
                      , (\'Empl_3\', NULL, \'Thierry Jacquin\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/***********************************************\
* Plug EqtType                                  *
*                                               *
* fields:                                       *
* I[EqtType]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\***********************************************/
mysqli_query($DB_link,"CREATE TABLE `EqtType`
                 ( `EqtType` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`EqtType`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `EqtType` (`EqtType`)
                 VALUES (\'Mobile\')
                      , (\'N32\')
                      , (\'iPhone III\')
                      , (\'iPhone II\')
                      , (\'Latitude D30\')
                      , (\'MacBook\')
                      , (\'MacBook Pro\')
                      , (\'Passat\')
                      , (\'Polo\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/********************************************\
* Plug Name                                  *
*                                            *
* fields:                                    *
* I[Name]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\********************************************/
mysqli_query($DB_link,"CREATE TABLE `Name`
                 ( `Name` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`Name`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `Name` (`Name`)
                 VALUES (\'Jean-Pierre Chanod\')
                      , (\'Jan Klaassen\')
                      , (\'Thierry Jacquin\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/**********************************************\
* Plug Status                                  *
*                                              *
* fields:                                      *
* I[Status]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\**********************************************/
mysqli_query($DB_link,"CREATE TABLE `Status`
                 ( `Status` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`Status`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `Status` (`Status`)
                 VALUES (\'Black\')
                      , (\'Green\')
                      , (\'Red\')
                      , (\'Yellow\')
                      , (\'Grey\')
                      , (\'Blue\')
                      , (\'Orange\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/*************************************************\
* Plug EqtSerial                                  *
*                                                 *
* fields:                                         *
* I[EqtSerial]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\*************************************************/
mysqli_query($DB_link,"CREATE TABLE `EqtSerial`
                 ( `EqtSerial` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`EqtSerial`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `EqtSerial` (`EqtSerial`)
                 VALUES (\'0693826586\')
                      , (\'0682746586\')
                      , (\'0698274586\')
                      , (\'0693827666\')
                      , (\'0693555586\')
                      , (\'407-21\')
                      , (\'169-07\')
                      , (\'245-23\')
                      , (\'803-44\')
                      , (\'5492921\')
                      , (\'1394597\')
                      , (\'11223\')
                      , (\'39624\')
                      , (\'1-TNO-23\')
                      , (\'1-TNO-24\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/***********************************************\
* Plug EqtMake                                  *
*                                               *
* fields:                                       *
* I[EqtMake]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\***********************************************/
mysqli_query($DB_link,"CREATE TABLE `EqtMake`
                 ( `EqtMake` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`EqtMake`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `EqtMake` (`EqtMake`)
                 VALUES (\'XEROX\')
                      , (\'Nokia\')
                      , (\'Apple\')
                      , (\'Dell\')
                      , (\'Volkswagen\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/***************************************************\
* Plug OrgFunction                                  *
*                                                   *
* fields:                                           *
* I[OrgFunction]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\***************************************************/
mysqli_query($DB_link,"CREATE TABLE `OrgFunction`
                 ( `OrgFunction` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`OrgFunction`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `OrgFunction` (`OrgFunction`)
                 VALUES (\'Director\')
                      , (\'Salesperson\')
                      , (\'Programmer\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/***********************************************\
* Plug EqtKind                                  *
*                                               *
* fields:                                       *
* I[EqtKind]  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
\***********************************************/
mysqli_query($DB_link,"CREATE TABLE `EqtKind`
                 ( `EqtKind` VARCHAR(255) DEFAULT NULL
                 , PRIMARY KEY (`EqtKind`)
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `EqtKind` (`EqtKind`)
                 VALUES (\'Computer\')
                      , (\'Cellphone\')
                      , (\'Phonenumber\')
                      , (\'Car\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/*******************************************************\
* Plug needsToReturnEqt                                 *
*                                                       *
* fields:                                               *
* I[Employee] /\ needsToReturnEqt;needsToReturnEqt~  [] *
* needsToReturnEqt  []                                  *
\*******************************************************/
mysqli_query($DB_link,"CREATE TABLE `needsToReturnEqt`
                 ( `SrcEmployee` VARCHAR(255) DEFAULT NULL
                 , `TgtEmployee` VARCHAR(255) DEFAULT NULL
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/*******************************************************************************\
* Plug allNecessaryEqtHasBeenIssued                                             *
*                                                                               *
* fields:                                                                       *
* I[Employee] /\ allNecessaryEqtHasBeenIssued;allNecessaryEqtHasBeenIssued~  [] *
* allNecessaryEqtHasBeenIssued  []                                              *
\*******************************************************************************/
mysqli_query($DB_link,"CREATE TABLE `allNecessaryEqtHasBeenIssued`
                 ( `SrcEmployee` VARCHAR(255) DEFAULT NULL
                 , `TgtEmployee` VARCHAR(255) DEFAULT NULL
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/*****************************************************************************\
* Plug noNecessaryEqtHasBeenIssued                                            *
*                                                                             *
* fields:                                                                     *
* I[Employee] /\ noNecessaryEqtHasBeenIssued;noNecessaryEqtHasBeenIssued~  [] *
* noNecessaryEqtHasBeenIssued  []                                             *
\*****************************************************************************/
mysqli_query($DB_link,"CREATE TABLE `noNecessaryEqtHasBeenIssued`
                 ( `SrcEmployee` VARCHAR(255) DEFAULT NULL
                 , `TgtEmployee` VARCHAR(255) DEFAULT NULL
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/**************************************************************\
* Plug orgfuncReqdEqtKind                                      *
*                                                              *
* fields:                                                      *
* I[OrgFunction] /\ orgfuncReqdEqtKind;orgfuncReqdEqtKind~  [] *
* orgfuncReqdEqtKind  []                                       *
\**************************************************************/
mysqli_query($DB_link,"CREATE TABLE `orgfuncReqdEqtKind`
                 ( `OrgFunction` VARCHAR(255) DEFAULT NULL
                 , `EqtKind` VARCHAR(255) DEFAULT NULL
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `orgfuncReqdEqtKind` (`OrgFunction`,`EqtKind`)
                 VALUES (\'Director\', \'Phonenumber\')
                      , (\'Director\', \'Cellphone\')
                      , (\'Director\', \'Computer\')
                      , (\'Programmer\', \'Computer\')
                      , (\'Salesperson\', \'Car\')
                      , (\'Salesperson\', \'Phonenumber\')
                      , (\'Salesperson\', \'Cellphone\')
                      , (\'Salesperson\', \'Computer\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/*****************************************************\
* Plug emplOrgFunction                                *
*                                                     *
* fields:                                             *
* I[Employee] /\ emplOrgFunction;emplOrgFunction~  [] *
* emplOrgFunction  []                                 *
\*****************************************************/
mysqli_query($DB_link,"CREATE TABLE `emplOrgFunction`
                 ( `Employee` VARCHAR(255) DEFAULT NULL
                 , `OrgFunction` VARCHAR(255) DEFAULT NULL
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `emplOrgFunction` (`Employee`,`OrgFunction`)
                 VALUES (\'Empl_1\', \'Director\')
                      , (\'Empl_2\', \'Salesperson\')
                      , (\'Empl_3\', \'Programmer\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
/*************************************************\
* Plug emplIssuedEqt                              *
*                                                 *
* fields:                                         *
* I[Employee] /\ emplIssuedEqt;emplIssuedEqt~  [] *
* emplIssuedEqt  []                               *
\*************************************************/
mysqli_query($DB_link,"CREATE TABLE `emplIssuedEqt`
                 ( `Employee` VARCHAR(255) DEFAULT NULL
                 , `Equipment` VARCHAR(255) DEFAULT NULL
                 ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
else
mysqli_query($DB_link, 'INSERT IGNORE INTO `emplIssuedEqt` (`Employee`,`Equipment`)
                 VALUES (\'Empl_1\', \'Eqt_XEROX_1\')
                      , (\'Empl_1\', \'Eqt_Cellphone1\')
                      , (\'Empl_2\', \'Eqt_Car2\')
                      , (\'Empl_2\', \'Eqt_Dell2\')
                      , (\'Empl_2\', \'Eqt_XEROX_2\')
                      , (\'Empl_2\', \'Eqt_Cellphone2\')
                      , (\'Empl_3\', \'Eqt_Cellphone3\')
                ');
if($err=mysqli_error($DB_link)) { $error=true; echo $err.'<br />'; }
mysqli_query($DB_link,'SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
if ($err=='') {
  echo '<div id="ResetSuccess"/>The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
  $content = '
  <?php
  require "Generics.php";
  require "php/DatabaseUtils.php";
  $dumpfile = fopen("dbdump.adl","w");
  fwrite($dumpfile, "CONTEXT HRM\n");
  fwrite($dumpfile, dumprel("needsToReturnEqt[Employee*Employee]","SELECT DISTINCT `SrcEmployee`, `TgtEmployee` FROM `needsToReturnEqt` WHERE `SrcEmployee` IS NOT NULL AND `TgtEmployee` IS NOT NULL"));
  fwrite($dumpfile, dumprel("allNecessaryEqtHasBeenIssued[Employee*Employee]","SELECT DISTINCT `SrcEmployee`, `TgtEmployee` FROM `allNecessaryEqtHasBeenIssued` WHERE `SrcEmployee` IS NOT NULL AND `TgtEmployee` IS NOT NULL"));
  fwrite($dumpfile, dumprel("noNecessaryEqtHasBeenIssued[Employee*Employee]","SELECT DISTINCT `SrcEmployee`, `TgtEmployee` FROM `noNecessaryEqtHasBeenIssued` WHERE `SrcEmployee` IS NOT NULL AND `TgtEmployee` IS NOT NULL"));
  fwrite($dumpfile, dumprel("emplStatus[Employee*Status]","SELECT DISTINCT `Employee`, `emplStatus` FROM `Employee` WHERE `Employee` IS NOT NULL AND `emplStatus` IS NOT NULL"));
  fwrite($dumpfile, dumprel("orgfuncReqdEqtKind[OrgFunction*EqtKind]","SELECT DISTINCT `OrgFunction`, `EqtKind` FROM `orgfuncReqdEqtKind` WHERE `OrgFunction` IS NOT NULL AND `EqtKind` IS NOT NULL"));
  fwrite($dumpfile, dumprel("emplName[Employee*Name]","SELECT DISTINCT `Employee`, `emplName` FROM `Employee` WHERE `Employee` IS NOT NULL AND `emplName` IS NOT NULL"));
  fwrite($dumpfile, dumprel("emplOrgFunction[Employee*OrgFunction]","SELECT DISTINCT `Employee`, `OrgFunction` FROM `emplOrgFunction` WHERE `Employee` IS NOT NULL AND `OrgFunction` IS NOT NULL"));
  fwrite($dumpfile, dumprel("emplIssuedEqt[Employee*Equipment]","SELECT DISTINCT `Employee`, `Equipment` FROM `emplIssuedEqt` WHERE `Employee` IS NOT NULL AND `Equipment` IS NOT NULL"));
  fwrite($dumpfile, dumprel("eqtMake[Equipment*EqtMake]","SELECT DISTINCT `Equipment`, `eqtMake` FROM `Equipment` WHERE `Equipment` IS NOT NULL AND `eqtMake` IS NOT NULL"));
  fwrite($dumpfile, dumprel("eqtType[Equipment*EqtType]","SELECT DISTINCT `Equipment`, `eqtType` FROM `Equipment` WHERE `Equipment` IS NOT NULL AND `eqtType` IS NOT NULL"));
  fwrite($dumpfile, dumprel("eqtSerial[Equipment*EqtSerial]","SELECT DISTINCT `Equipment`, `eqtSerial` FROM `Equipment` WHERE `Equipment` IS NOT NULL AND `eqtSerial` IS NOT NULL"));
  fwrite($dumpfile, dumprel("eqtKind[Equipment*EqtKind]","SELECT DISTINCT `Equipment`, `eqtKind` FROM `Equipment` WHERE `Equipment` IS NOT NULL AND `eqtKind` IS NOT NULL"));
  fwrite($dumpfile, "ENDCONTEXT");
  fclose($dumpfile);
  
  function dumprel ($rel,$quer)
  {
    $rows = DB_doquer($quer);
    $pop = "";
    foreach ($rows as $row)
      $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
    return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
  }
  function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
  ?>';
  file_put_contents("dbdump.php.",$content);
}

?></body></html>

