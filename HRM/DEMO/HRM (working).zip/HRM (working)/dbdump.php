
  <?php
  require "Generics.php";
  require "php/DatabaseUtils.php";
  $dumpfile = fopen("dbdump.adl","w");
  fwrite($dumpfile, "CONTEXT HRM\n");
  fwrite($dumpfile, dumprel("needsToReturnEqt[Employee*Employee]","SELECT DISTINCT `SrcEmployee`, `TgtEmployee` FROM `needsToReturnEqt` WHERE `SrcEmployee` IS NOT NULL AND `TgtEmployee` IS NOT NULL"));
  fwrite($dumpfile, dumprel("allNecessaryEqtHasBeenIssued[Employee*Employee]","SELECT DISTINCT `SrcEmployee`, `TgtEmployee` FROM `allNecessaryEqtHasBeenIssued` WHERE `SrcEmployee` IS NOT NULL AND `TgtEmployee` IS NOT NULL"));
  fwrite($dumpfile, dumprel("noNecessaryEqtHasBeenIssued[Employee*Employee]","SELECT DISTINCT `SrcEmployee`, `TgtEmployee` FROM `noNecessaryEqtHasBeenIssued` WHERE `SrcEmployee` IS NOT NULL AND `TgtEmployee` IS NOT NULL"));
  fwrite($dumpfile, dumprel("emplStatus[Employee*Status]","SELECT DISTINCT `Employee`, `emplStatus` FROM `Employee` WHERE `Employee` IS NOT NULL AND `emplStatus` IS NOT NULL"));
  fwrite($dumpfile, dumprel("orgfuncReqdEqtKind[OrgFunction*EqtKind]","SELECT DISTINCT `OrgFunction`, `EqtKind` FROM `orgfuncReqdEqtKind` WHERE `OrgFunction` IS NOT NULL AND `EqtKind` IS NOT NULL"));
  fwrite($dumpfile, dumprel("emplName[Employee*Name]","SELECT DISTINCT `Employee`, `emplName` FROM `Employee` WHERE `Employee` IS NOT NULL AND `emplName` IS NOT NULL"));
  fwrite($dumpfile, dumprel("emplOrgFunction[Employee*OrgFunction]","SELECT DISTINCT `Employee`, `OrgFunction` FROM `emplOrgFunction` WHERE `Employee` IS NOT NULL AND `OrgFunction` IS NOT NULL"));
  fwrite($dumpfile, dumprel("emplIssuedEqt[Employee*Equipment]","SELECT DISTINCT `Employee`, `Equipment` FROM `emplIssuedEqt` WHERE `Employee` IS NOT NULL AND `Equipment` IS NOT NULL"));
  fwrite($dumpfile, dumprel("eqtMake[Equipment*EqtMake]","SELECT DISTINCT `Equipment`, `eqtMake` FROM `Equipment` WHERE `Equipment` IS NOT NULL AND `eqtMake` IS NOT NULL"));
  fwrite($dumpfile, dumprel("eqtType[Equipment*EqtType]","SELECT DISTINCT `Equipment`, `eqtType` FROM `Equipment` WHERE `Equipment` IS NOT NULL AND `eqtType` IS NOT NULL"));
  fwrite($dumpfile, dumprel("eqtSerial[Equipment*EqtSerial]","SELECT DISTINCT `Equipment`, `eqtSerial` FROM `Equipment` WHERE `Equipment` IS NOT NULL AND `eqtSerial` IS NOT NULL"));
  fwrite($dumpfile, dumprel("eqtKind[Equipment*EqtKind]","SELECT DISTINCT `Equipment`, `eqtKind` FROM `Equipment` WHERE `Equipment` IS NOT NULL AND `eqtKind` IS NOT NULL"));
  fwrite($dumpfile, "ENDCONTEXT");
  fclose($dumpfile);
  
  function dumprel ($rel,$quer)
  {
    $rows = DB_doquer($quer);
    $pop = "";
    foreach ($rows as $row)
      $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
    return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
  }
  function escapedoublequotes($str) { return str_replace("\"","\\\"",$str); }
  ?>