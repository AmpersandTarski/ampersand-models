<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass from some place else
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('EURent')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `EURent` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('EURent');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'EURent'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Session timeout table
    if($columns = mysql_query("SHOW COLUMNS FROM `__SessionTimeout__`")){
        mysql_query("DROP TABLE `__SessionTimeout__`");
    }
    mysql_query("CREATE TABLE `__SessionTimeout__`
                         ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                         , `lastAccess` BIGINT NOT NULL
                         ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
    }
    mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                         ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    date_default_timezone_set("Europe/Amsterdam");
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 24
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `RentalCase`")){
        mysql_query("DROP TABLE `RentalCase`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `SESSION`")){
        mysql_query("DROP TABLE `SESSION`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `CompRentalCharge`")){
        mysql_query("DROP TABLE `CompRentalCharge`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `CarType`")){
        mysql_query("DROP TABLE `CarType`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `DateDifference`")){
        mysql_query("DROP TABLE `DateDifference`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `CompTariffedCharge`")){
        mysql_query("DROP TABLE `CompTariffedCharge`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `DateDifferencePlusOne`")){
        mysql_query("DROP TABLE `DateDifferencePlusOne`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `DistanceBetweenLocations`")){
        mysql_query("DROP TABLE `DistanceBetweenLocations`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Car`")){
        mysql_query("DROP TABLE `Car`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Branch`")){
        mysql_query("DROP TABLE `Branch`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Date`")){
        mysql_query("DROP TABLE `Date`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `CarRentalCompany`")){
        mysql_query("DROP TABLE `CarRentalCompany`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Distance`")){
        mysql_query("DROP TABLE `Distance`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `YesNoAnswer`")){
        mysql_query("DROP TABLE `YesNoAnswer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `DrivingLicense`")){
        mysql_query("DROP TABLE `DrivingLicense`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Person`")){
        mysql_query("DROP TABLE `Person`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Integer`")){
        mysql_query("DROP TABLE `Integer`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Amount`")){
        mysql_query("DROP TABLE `Amount`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Model`")){
        mysql_query("DROP TABLE `Model`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Brand`")){
        mysql_query("DROP TABLE `Brand`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Location`")){
        mysql_query("DROP TABLE `Location`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `dateIntervalIsWithinMaxRentalDuration`")){
        mysql_query("DROP TABLE `dateIntervalIsWithinMaxRentalDuration`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `dateIntervalCompTrigger`")){
        mysql_query("DROP TABLE `dateIntervalCompTrigger`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `distbranch`")){
        mysql_query("DROP TABLE `distbranch`");
      }
    }
    /************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************\
    * Plug RentalCase                                                                                                                                                                                                                                                                                                                                                                    *
    *                                                                                                                                                                                                                                                                                                                                                                                    *
    * fields:                                                                                                                                                                                                                                                                                                                                                                            *
    * EDcI RentalCase  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                                                                                                                                                                                                                                                                                                                 *
    * EDcD RELATION contractedStartDate [RentalCase*Date] Just [UNI] PRAGMA "The contractual and/or actual starting date of the rental of" "is" "" MEANING IN English HTML {+ Rental contracts may specify the actual (and contractual) start date of the rental. -}  [UNI]                                                                                                              *
    * EDcD RELATION contractedEndDate [RentalCase*Date] Just [UNI] PRAGMA "The contractual end date of the rental of" "is" "" MEANING IN English HTML {+ Rental contracts may specify the (contractual) end date of the rental. -}  [UNI]                                                                                                                                                *
    * EDcD RELATION contractedCarType [RentalCase*CarType] Just [UNI] PRAGMA "The contractual type of the car being rented under" "is" "" MEANING IN English HTML {+ Rental contracts may specify the car type of the rental. -}  [UNI]                                                                                                                                                  *
    * EDcD RELATION contractedPickupBranch [RentalCase*Branch] Just [UNI] PRAGMA "The contractual and/or actual pick-up branch for the rental of" "is" "" MEANING IN English HTML {+ Rental contracts may specify the branch where the rental starts (i.e.: the car is picked up). -}  [UNI]                                                                                             *
    * EDcD RELATION contractedDropOffBranch [RentalCase*Branch] Just [UNI] PRAGMA "The contractual drop-off branch for the rental of" "is" "" MEANING IN English HTML {+ Rental contracts may specify the branch where the rental supposedly ends (i.e.: the car is dropped off). -}  [UNI]                                                                                              *
    * EDcD RELATION rcRenter [RentalCase*Person] Just [UNI] PRAGMA "The renter for" "is" "" MEANING IN English HTML {+ The person who rents the car is called the renter. -}  [UNI]                                                                                                                                                                                                      *
    * EDcD RELATION rcDriver [RentalCase*Person] Just [UNI] PRAGMA "The driver for" "is" "" MEANING IN English HTML {+ The person who is going to drive is called the driver. -}  [UNI]                                                                                                                                                                                                  *
    * EDcD RELATION rcDrivingLicense [RentalCase*DrivingLicense] Just [UNI] PRAGMA "The driver for" "has a valid driving license, with number" "" MEANING IN English HTML {+ Rental cases register the driving license of the driver. -}  [UNI]                                                                                                                                          *
    * EDcD RELATION rcAssignedCar [RentalCase*Car] Just [UNI] PRAGMA "The car that will be, or has been issued under" "has license plate" "" MEANING IN English HTML {+ Rental contracts specify the car that is (to be) issued to the driver. -}  [UNI]                                                                                                                                 *
    * EDcD RELATION rentalHasBeenPromised [RentalCase*RentalCase] Just [SYM,ASY,UNI,INJ] PRAGMA "" "" "" MEANING IN English HTML {+ Rental cases may have the property 'rental has been promised' -}  [SYM,ASY,UNI,INJ]                                                                                                                                                                  *
    * EDcD RELATION rcUserRequestedQ [RentalCase*YesNoAnswer] Just [UNI] PRAGMA "" "" "" MEANING IN English HTML {+ A user has requested a new rental to be started, and has provided all necessary information for that. -}  [UNI]                                                                                                                                                      *
    * EDcD RELATION rcBranchRequestedQ [RentalCase*YesNoAnswer] Just [UNI] PRAGMA "" "" "" MEANING IN English HTML {+ A branch office has requested a new rental to be started, and has provided all necessary information for that. -}  [UNI]                                                                                                                                           *
    * EDcD RELATION rentalCarHasBeenPickedUp [RentalCase*RentalCase] Just [SYM,ASY,UNI,INJ] PRAGMA "" "has the property 'car of rental has been picked up', meaning that the keys of the car associated with" "have been handed over to the driver" MEANING IN English HTML {+ Rental cases may have the property 'rental has been started'. -}  [SYM,ASY,UNI,INJ]                       *
    * EDcD RELATION rcKeysHandedOverQ [RentalCase*YesNoAnswer] Just [UNI] PRAGMA "The answer to the question 'have the keys of the car rented under" "been handed over to the designated driver?' is" "" MEANING IN English HTML {+ Branches must register the handover of car keys (i.e. the responsibility for the car). -}  [UNI]                                                     *
    * EDcD RELATION rentalHasBeenStarted [RentalCase*RentalCase] Just [SYM,ASY,UNI,INJ] PRAGMA "" "has the property 'rental has started', meaning that the rental associated with" "has started" MEANING IN English HTML {+ Rental cases may have the property 'rental has been started'. -}  [SYM,ASY,UNI,INJ]                                                                          *
    * EDcD RELATION rentalCarHasBeenDroppedOff [RentalCase*RentalCase] Just [SYM,ASY,UNI,INJ] PRAGMA "" "has the property 'car has been dropped off', meaning that the car associated with" "(and its keys) have been returned to a branch." MEANING IN English HTML {+ Rental cases may have the property 'car has been dropped off'. -}  [SYM,ASY,UNI,INJ]                             *
    * EDcD RELATION rcDroppedOffCar [RentalCase*Car] Just [UNI] PRAGMA "The car that has been dropped-off for" "is" "" MEANING IN English HTML {+ Rental cases may specify the car that has actually been dropped off. -}  [UNI]                                                                                                                                                         *
    * EDcD RELATION rcDroppedOffDate [RentalCase*Date] Just [UNI] PRAGMA "The car rented under" "has been dropped off on" "" MEANING IN English HTML {+ Rented cars are dropped off on specific dates. -}  [UNI]                                                                                                                                                                         *
    * EDcD RELATION rcDroppedOffBranch [RentalCase*Branch] Just [UNI] PRAGMA "The car rented under" "has been dropped off at" "" MEANING IN English HTML {+ Rental cases may specify the branch that the drop-off has taken place. -}  [UNI]                                                                                                                                             *
    * EDcD RELATION contractualRentalPeriod [RentalCase*Integer] Just [UNI] PRAGMA "The number of days, according to the specified contractual start and end dates for rental" ", that this rental will last, is" "" MEANING IN English HTML {+ A rental may specify the number of days that the rental will last, according to the specified contractual start and end dates. -}  [UNI] *
    * EDcD RELATION contractualBasicCharge [RentalCase*Amount] Just [UNI] PRAGMA "The projected charge for" "amounts to" "" MEANING IN English HTML {+ Rental contracts may specify an amount for the projected basic charge -}  [UNI]                                                                                                                                                   *
    * EDcD RELATION rentalPeriod [RentalCase*Integer] Just [UNI] PRAGMA "The number of days that the rental of" "lasted, is" "" MEANING IN English HTML {+ A rental may specify the number of days that the rental has lasted. -}  [UNI]                                                                                                                                                 *
    * EDcD RELATION rentalBasicCharge [RentalCase*Amount] Just [UNI] PRAGMA "The basic charge for" "is" "Euro." MEANING IN English HTML {+ Rental contracts may specify the basic charge. -}  [UNI]                                                                                                                                                                                      *
    * EDcD RELATION rentalExcessPeriod [RentalCase*Integer] Just [UNI] PRAGMA "The number of days in the excess period of the rental of" "is" ""  [UNI]                                                                                                                                                                                                                                  *
    * EDcD RELATION rentalPenaltyCharge [RentalCase*Amount] Just [UNI] PRAGMA "The penalty charge for" "is" "Euro." MEANING IN English HTML {+ Rental contracts may specify a penalty charge for late drop-offs. -}  [UNI]                                                                                                                                                               *
    * EDcD RELATION rentalLocationPenaltyCharge [RentalCase*Amount] Just [UNI] PRAGMA "The location penaly charge" "is" "Euro." MEANING IN English HTML {+ Rental contracts may specify a location penalty charge, i.e. a penalty for dropping off the car at a location that differs from the contracted drop-off branch. -}  [UNI]                                                     *
    * EDcD RELATION rentalCharge [RentalCase*Amount] Just [UNI] PRAGMA "The total amount to be paid for" "is" "Euro." MEANING IN English HTML {+ The rental charge is the total amount to be paid for a rental. -}  [UNI]                                                                                                                                                                *
    * EDcD RELATION paymentHasBeenRequested [RentalCase*RentalCase] Just [SYM,ASY,UNI,INJ] PRAGMA "" "has the property 'payment has been requested', meaning that the amount that the renter has to pay is computed." "" MEANING IN English HTML {+ Rental cases may have the property 'payment has been requested'. -}  [SYM,ASY,UNI,INJ]                                               *
    * EDcD RELATION rentalIsPaidQ [RentalCase*YesNoAnswer] Just [UNI] PRAGMA "The answer to the question: 'Has the rental charge for" "been received?' is" "" MEANING IN English HTML {+ Payments for rental contracts need to be accepted (or declined). -}  [UNI]                                                                                                                      *
    * EDcD RELATION rentalHasBeenEnded [RentalCase*RentalCase] Just [SYM,ASY,UNI,INJ] PRAGMA "" "has the property 'rental has ended', meaning that the rental associated with" "has ended." MEANING IN English HTML {+ Rental cases may have the property 'rental has been ended'. -}  [SYM,ASY,UNI,INJ]                                                                                 *
    * EDcD RELATION rcMaxRentalDuration [RentalCase*Integer] Just [UNI] PRAGMA "" "" "" MEANING IN English HTML {+ Rental contracts may specify the maximum rental duration. -}  [UNI]                                                                                                                                                                                                   *
    \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `RentalCase`
                     ( `RentalCase` VARCHAR(255) DEFAULT NULL
                     , `contractedStartDate` VARCHAR(255) DEFAULT NULL
                     , `contractedEndDate` VARCHAR(255) DEFAULT NULL
                     , `contractedCarType` VARCHAR(255) DEFAULT NULL
                     , `contractedPickupBranch` VARCHAR(255) DEFAULT NULL
                     , `contractedDropOffBranch` VARCHAR(255) DEFAULT NULL
                     , `rcRenter` VARCHAR(255) DEFAULT NULL
                     , `rcDriver` VARCHAR(255) DEFAULT NULL
                     , `rcDrivingLicense` VARCHAR(255) DEFAULT NULL
                     , `rcAssignedCar` VARCHAR(255) DEFAULT NULL
                     , `rentalHasBeenPromised` VARCHAR(255) DEFAULT NULL
                     , `rcUserRequestedQ` VARCHAR(255) DEFAULT NULL
                     , `rcBranchRequestedQ` VARCHAR(255) DEFAULT NULL
                     , `rentalCarHasBeenPickedUp` VARCHAR(255) DEFAULT NULL
                     , `rcKeysHandedOverQ` VARCHAR(255) DEFAULT NULL
                     , `rentalHasBeenStarted` VARCHAR(255) DEFAULT NULL
                     , `rentalCarHasBeenDroppedOff` VARCHAR(255) DEFAULT NULL
                     , `rcDroppedOffCar` VARCHAR(255) DEFAULT NULL
                     , `rcDroppedOffDate` VARCHAR(255) DEFAULT NULL
                     , `rcDroppedOffBranch` VARCHAR(255) DEFAULT NULL
                     , `contractualRentalPeriod` VARCHAR(255) DEFAULT NULL
                     , `contractualBasicCharge` VARCHAR(255) DEFAULT NULL
                     , `rentalPeriod` VARCHAR(255) DEFAULT NULL
                     , `rentalBasicCharge` VARCHAR(255) DEFAULT NULL
                     , `rentalExcessPeriod` VARCHAR(255) DEFAULT NULL
                     , `rentalPenaltyCharge` VARCHAR(255) DEFAULT NULL
                     , `rentalLocationPenaltyCharge` VARCHAR(255) DEFAULT NULL
                     , `rentalCharge` VARCHAR(255) DEFAULT NULL
                     , `paymentHasBeenRequested` VARCHAR(255) DEFAULT NULL
                     , `rentalIsPaidQ` VARCHAR(255) DEFAULT NULL
                     , `rentalHasBeenEnded` VARCHAR(255) DEFAULT NULL
                     , `rcMaxRentalDuration` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`RentalCase`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `RentalCase` (`RentalCase` ,`contractedStartDate` ,`contractedEndDate` ,`contractedCarType` ,`contractedPickupBranch` ,`contractedDropOffBranch` ,`rcRenter` ,`rcDriver` ,`rcDrivingLicense` ,`rcAssignedCar` ,`rentalHasBeenPromised` ,`rcUserRequestedQ` ,`rcBranchRequestedQ` ,`rentalCarHasBeenPickedUp` ,`rcKeysHandedOverQ` ,`rentalHasBeenStarted` ,`rentalCarHasBeenDroppedOff` ,`rcDroppedOffCar` ,`rcDroppedOffDate` ,`rcDroppedOffBranch` ,`contractualRentalPeriod` ,`contractualBasicCharge` ,`rentalPeriod` ,`rentalBasicCharge` ,`rentalExcessPeriod` ,`rentalPenaltyCharge` ,`rentalLocationPenaltyCharge` ,`rentalCharge` ,`paymentHasBeenRequested` ,`rentalIsPaidQ` ,`rentalHasBeenEnded` ,`rcMaxRentalDuration` )
                VALUES ('RC_RTD_262', '01-06-2014', '07-06-2014', 'VW Polo', 'RTD', 'UTR', 'Richard Enter', 'Dick River', 'DL01235467', '3-RTD-18', 'RC_RTD_262', NULL, 'Yes', 'RC_RTD_262', 'Yes', 'RC_RTD_262', 'RC_RTD_262', '3-RTD-18', '14-06-2014', 'AMS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'RC_RTD_262', 'Yes', 'RC_RTD_262', NULL)
                      , ('RC_AMS_123', '01-07-2014', '10-07-2014', 'VW Polo', 'AMS', 'DHG', 'Richard Enter', 'Dick River', 'DL01235467', '1-AMS-12', 'RC_AMS_123', NULL, 'Yes', 'RC_AMS_123', 'Yes', 'RC_AMS_123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /***********************************************************************************************\
    * Plug SESSION                                                                                  *
    *                                                                                               *
    * fields:                                                                                       *
    * EDcI SESSION  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                               *
    * EDcD RELATION sessionDroppedoffRC [SESSION*RentalCase] Just [UNI] PRAGMA "" "" ""  [UNI]      *
    * EDcD RELATION sessionDroppedOffCar [SESSION*Car] Just [UNI] PRAGMA "" "" ""  [UNI]            *
    * EDcD RELATION sessionDroppedOffPerson [SESSION*Person] Just [UNI] PRAGMA "" "" ""  [UNI]      *
    * EDcD RELATION sessionNewRC [SESSION*RentalCase] Just [UNI] PRAGMA "" "" ""  [UNI]             *
    * EDcD RELATION sessionBranch [SESSION*Branch] Just [UNI] PRAGMA "" "" ""  [UNI]                *
    * EDcD RELATION sessionNewBranchRC [SESSION*RentalCase] Just [UNI] PRAGMA "" "" ""  [UNI]       *
    * EDcD RELATION sessionPickupPerson [SESSION*Person] Just [UNI] PRAGMA "" "" ""  [UNI]          *
    * EDcD RELATION sessionToday [SESSION*Date] Just [UNI] PRAGMA "" "" ""  [UNI]                   *
    * EDcD RELATION sessionNewUserRC [SESSION*RentalCase] Just [INJ,UNI] PRAGMA "" "" ""  [INJ,UNI] *
    \***********************************************************************************************/
    mysql_query("CREATE TABLE `SESSION`
                     ( `SESSION` VARCHAR(255) DEFAULT NULL
                     , `sessionDroppedoffRC` VARCHAR(255) DEFAULT NULL
                     , `sessionDroppedOffCar` VARCHAR(255) DEFAULT NULL
                     , `sessionDroppedOffPerson` VARCHAR(255) DEFAULT NULL
                     , `sessionNewRC` VARCHAR(255) DEFAULT NULL
                     , `sessionBranch` VARCHAR(255) DEFAULT NULL
                     , `sessionNewBranchRC` VARCHAR(255) DEFAULT NULL
                     , `sessionPickupPerson` VARCHAR(255) DEFAULT NULL
                     , `sessionToday` VARCHAR(255) DEFAULT NULL
                     , `sessionNewUserRC` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`SESSION`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************************************************************************\
    * Plug CompRentalCharge                                                                          *
    *                                                                                                *
    * fields:                                                                                        *
    * EDcI CompRentalCharge  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                       *
    * EDcD RELATION arg1 [CompRentalCharge*Amount] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT]         *
    * EDcD RELATION arg2 [CompRentalCharge*Amount] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT]         *
    * EDcD RELATION arg3 [CompRentalCharge*Amount] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT]         *
    * EDcD RELATION computedRentalCharge [CompRentalCharge*Amount] Just [UNI] PRAGMA "" "" ""  [UNI] *
    \************************************************************************************************/
    mysql_query("CREATE TABLE `CompRentalCharge`
                     ( `CompRentalCharge` VARCHAR(255) DEFAULT NULL
                     , `arg1` VARCHAR(255) DEFAULT NULL
                     , `arg2` VARCHAR(255) DEFAULT NULL
                     , `arg3` VARCHAR(255) DEFAULT NULL
                     , `computedRentalCharge` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`CompRentalCharge`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************************************************************************************************************************************************************************************************************\
    * Plug CarType                                                                                                                                                                                                                                     *
    *                                                                                                                                                                                                                                                  *
    * fields:                                                                                                                                                                                                                                          *
    * EDcI CarType  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                                                                                                                                                                                  *
    * EDcD RELATION brand [CarType*Brand] Just [UNI,TOT] PRAGMA "The brand of" "is" "" MEANING IN English HTML {+ A cartype has a specific brand. -}  [UNI,TOT]                                                                                        *
    * EDcD RELATION model [CarType*Model] Just [UNI,TOT] PRAGMA "The model of" "is" "" MEANING IN English HTML {+ A cartype has a specific model. -}  [UNI,TOT]                                                                                        *
    * EDcD RELATION rentalTariffPerDay [CarType*Amount] Just [UNI,TOT] PRAGMA "The rental tariff for" "is" "Euros/day" MEANING IN English HTML {+ All car types have a specified rental tariff (Euros/day). -}  [UNI,TOT]                              *
    * EDcD RELATION excessTariffPerDay [CarType*Amount] Just [UNI,TOT] PRAGMA "For cars of type" "the extra charge for a late drop-off is" "Euro/day" MEANING IN English HTML {+ All car types have a specified excess tariff (Euro/day) -}  [UNI,TOT] *
    \**************************************************************************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `CarType`
                     ( `CarType` VARCHAR(255) DEFAULT NULL
                     , `brand` VARCHAR(255) DEFAULT NULL
                     , `model` VARCHAR(255) DEFAULT NULL
                     , `rentalTariffPerDay` VARCHAR(255) DEFAULT NULL
                     , `excessTariffPerDay` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`CarType`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `CarType` (`CarType` ,`brand` ,`model` ,`rentalTariffPerDay` ,`excessTariffPerDay` )
                VALUES ('VW Beetle', 'Volkswagen', 'Beetle', '60', '38')
                      , ('VW Polo', 'Volkswagen', 'Polo', '25', '12')
                      , ('VW Passat', 'Volkswagen', 'Passat', '34', '19')
                      , ('Audi A4', 'Audi', 'A4', '103', '56')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /*************************************************************************************************\
    * Plug DateDifference                                                                             *
    *                                                                                                 *
    * fields:                                                                                         *
    * EDcI DateDifference  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                          *
    * EDcD RELATION firstDate [DateDifference*Date] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT]         *
    * EDcD RELATION lastDate [DateDifference*Date] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT]          *
    * EDcD RELATION computedNrOfExcessDays [DateDifference*Integer] Just [UNI] PRAGMA "" "" ""  [UNI] *
    \*************************************************************************************************/
    mysql_query("CREATE TABLE `DateDifference`
                     ( `DateDifference` VARCHAR(255) DEFAULT NULL
                     , `firstDate` VARCHAR(255) DEFAULT NULL
                     , `lastDate` VARCHAR(255) DEFAULT NULL
                     , `computedNrOfExcessDays` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`DateDifference`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************************************************************\
    * Plug CompTariffedCharge                                                                            *
    *                                                                                                    *
    * fields:                                                                                            *
    * EDcI CompTariffedCharge  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                         *
    * EDcD RELATION ctcNrOfDays [CompTariffedCharge*Integer] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT]   *
    * EDcD RELATION ctcDailyAmount [CompTariffedCharge*Amount] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT] *
    * EDcD RELATION computedTariffedCharge [CompTariffedCharge*Amount] Just [UNI] PRAGMA "" "" ""  [UNI] *
    \****************************************************************************************************/
    mysql_query("CREATE TABLE `CompTariffedCharge`
                     ( `CompTariffedCharge` VARCHAR(255) DEFAULT NULL
                     , `ctcNrOfDays` VARCHAR(255) DEFAULT NULL
                     , `ctcDailyAmount` VARCHAR(255) DEFAULT NULL
                     , `computedTariffedCharge` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`CompTariffedCharge`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************************************************************************\
    * Plug DateDifferencePlusOne                                                                           *
    *                                                                                                      *
    * fields:                                                                                              *
    * EDcI DateDifferencePlusOne  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                        *
    * EDcD RELATION earliestDate [DateDifferencePlusOne*Date] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT]    *
    * EDcD RELATION latestDate [DateDifferencePlusOne*Date] Just [UNI,TOT] PRAGMA "" "" ""  [UNI,TOT]      *
    * EDcD RELATION computedRentalPeriod [DateDifferencePlusOne*Integer] Just [UNI] PRAGMA "" "" ""  [UNI] *
    \******************************************************************************************************/
    mysql_query("CREATE TABLE `DateDifferencePlusOne`
                     ( `DateDifferencePlusOne` VARCHAR(255) DEFAULT NULL
                     , `earliestDate` VARCHAR(255) DEFAULT NULL
                     , `latestDate` VARCHAR(255) DEFAULT NULL
                     , `computedRentalPeriod` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`DateDifferencePlusOne`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************\
    * Plug DistanceBetweenLocations                                                                                                                                                                                                                                                                                                                                          *
    *                                                                                                                                                                                                                                                                                                                                                                        *
    * fields:                                                                                                                                                                                                                                                                                                                                                                *
    * EDcI DistanceBetweenLocations  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                                                                                                                                                                                                                                                                                       *
    * EDcD RELATION computedLocationPenaltyCharge [DistanceBetweenLocations*Amount] Just [UNI,TOT] PRAGMA "The penalty charge for dropping off a car at a branch that is" "km away from the contracted drop-off branch, is" "Euro." MEANING IN English HTML {+ There is a location penalty charge for cars that are dropped-off at another branch than agreed. -}  [UNI,TOT] *
    * EDcD RELATION distance [DistanceBetweenLocations*Distance] Just [UNI,TOT] PRAGMA "" "" "" MEANING IN English HTML {+ There may be a distance between locations. -}  [UNI,TOT]                                                                                                                                                                                          *
    \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `DistanceBetweenLocations`
                     ( `DistanceBetweenLocations` VARCHAR(255) DEFAULT NULL
                     , `computedLocationPenaltyCharge` VARCHAR(255) DEFAULT NULL
                     , `distance` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`DistanceBetweenLocations`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `DistanceBetweenLocations` (`DistanceBetweenLocations` ,`computedLocationPenaltyCharge` ,`distance` )
                VALUES ('AMS-DHG', '61', '61')
                      , ('AMS-RTD', '67', '67')
                      , ('AMS-UTR', '38', '38')
                      , ('DHG-RTD', '23', '23')
                      , ('DHG-UTR', '63', '63')
                      , ('RTD-UTR', '56', '56')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /*****************************************************************************************************************************************************************************************************************\
    * Plug Car                                                                                                                                                                                                        *
    *                                                                                                                                                                                                                 *
    * fields:                                                                                                                                                                                                         *
    * EDcI Car  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                                                                                                                                                     *
    * EDcD RELATION carAvailableAt [Car*Branch] Just [UNI] PRAGMA "Car with license plate" "is available at EU-Rent branch" "" MEANING IN English HTML {+ It is known which cars are available at a branch. -}  [UNI] *
    * EDcD RELATION carType [Car*CarType] Just [UNI,TOT] PRAGMA "Car with license plate" "is a " "" MEANING IN English HTML {+ Every car is of a specific type (brand, model). -}  [UNI,TOT]                          *
    \*****************************************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `Car`
                     ( `Car` VARCHAR(255) DEFAULT NULL
                     , `carAvailableAt` VARCHAR(255) DEFAULT NULL
                     , `carType` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Car`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Car` (`Car` ,`carAvailableAt` ,`carType` )
                VALUES ('1-AMS-11', 'AMS', 'VW Polo')
                      , ('1-AMS-12', NULL, 'VW Polo')
                      , ('1-AMS-13', 'AMS', 'VW Passat')
                      , ('2-DHG-14', 'DHG', 'Audi A4')
                      , ('2-DHG-15', 'DHG', 'VW Polo')
                      , ('2-DHG-16', 'DHG', 'VW Passat')
                      , ('3-RTD-19', 'RTD', 'VW Beetle')
                      , ('3-RTD-17', 'RTD', 'VW Passat')
                      , ('3-RTD-18', 'UTR', 'VW Polo')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /******************************************************************************************************************************************************************************************\
    * Plug Branch                                                                                                                                                                              *
    *                                                                                                                                                                                          *
    * fields:                                                                                                                                                                                  *
    * EDcI Branch  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                                                                                                                           *
    * EDcD RELATION branchOf [Branch*CarRentalCompany] Just [UNI,TOT] PRAGMA "" "is a branch of " "" MEANING IN English HTML {+ Every branch is part of a car rental company. -}  [UNI,TOT]    *
    * EDcD RELATION branchLocation [Branch*Location] Just [UNI,TOT] PRAGMA "" "is located in " "" MEANING IN English HTML {+ Every branch operates from a geographical location. -}  [UNI,TOT] *
    \******************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `Branch`
                     ( `Branch` VARCHAR(255) DEFAULT NULL
                     , `branchOf` VARCHAR(255) DEFAULT NULL
                     , `branchLocation` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Branch`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Branch` (`Branch` ,`branchOf` ,`branchLocation` )
                VALUES ('AMS', 'EU-Rent', 'Amsterdam')
                      , ('RTD', 'EU-Rent', 'Rotterdam')
                      , ('DHG', 'EU-Rent', 'Den Haag')
                      , ('UTR', 'EU-Rent', 'Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************************************************************************************************************************************************************************\
    * Plug Date                                                                                                                                                                                              *
    *                                                                                                                                                                                                        *
    * fields:                                                                                                                                                                                                *
    * EDcI Date  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                                                                                                                                           *
    * EDcD RELATION defaultSessionToday [Date*Date] Just [SYM,ASY,UNI,INJ] PRAGMA "" "" "" MEANING IN English HTML {+ For demo purposes the date of today may be set to a fixed value. -}  [SYM,ASY,UNI,INJ] *
    \********************************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `Date`
                     ( `Date` VARCHAR(255) DEFAULT NULL
                     , `defaultSessionToday` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Date`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Date` (`Date` ,`defaultSessionToday` )
                VALUES ('01-06-2014', NULL)
                      , ('15-07-2014', '15-07-2014')
                      , ('01-07-2014', NULL)
                      , ('07-06-2014', NULL)
                      , ('14-06-2014', NULL)
                      , ('10-07-2014', NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************************************************************************************************************************************************************************************************************\
    * Plug CarRentalCompany                                                                                                                                                                                                                            *
    *                                                                                                                                                                                                                                                  *
    * fields:                                                                                                                                                                                                                                          *
    * EDcI CarRentalCompany  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                                                                                                                                                                         *
    * EDcD RELATION maxRentalDuration [CarRentalCompany*Integer] Just [UNI] PRAGMA "" "has set the maximum duration of a rental to" "days" MEANING IN English HTML {+ Rental companies must have specified the maximum duration of a rental. -}  [UNI] *
    \**************************************************************************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `CarRentalCompany`
                     ( `CarRentalCompany` VARCHAR(255) DEFAULT NULL
                     , `maxRentalDuration` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`CarRentalCompany`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `CarRentalCompany` (`CarRentalCompany` ,`maxRentalDuration` )
                VALUES ('EU-Rent', '60')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug Distance                                    *
    *                                                  *
    * fields:                                          *
    * EDcI Distance  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************************/
    mysql_query("CREATE TABLE `Distance`
                     ( `Distance` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Distance`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Distance` (`Distance` )
                VALUES ('61')
                      , ('67')
                      , ('38')
                      , ('23')
                      , ('63')
                      , ('56')
                      , ('0')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /*****************************************************\
    * Plug YesNoAnswer                                    *
    *                                                     *
    * fields:                                             *
    * EDcI YesNoAnswer  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \*****************************************************/
    mysql_query("CREATE TABLE `YesNoAnswer`
                     ( `YesNoAnswer` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`YesNoAnswer`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `YesNoAnswer` (`YesNoAnswer` )
                VALUES ('Yes')
                      , ('No')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************************\
    * Plug DrivingLicense                                    *
    *                                                        *
    * fields:                                                *
    * EDcI DrivingLicense  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \********************************************************/
    mysql_query("CREATE TABLE `DrivingLicense`
                     ( `DrivingLicense` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`DrivingLicense`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `DrivingLicense` (`DrivingLicense` )
                VALUES ('DL01235467')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************************\
    * Plug Person                                    *
    *                                                *
    * fields:                                        *
    * EDcI Person  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \************************************************/
    mysql_query("CREATE TABLE `Person`
                     ( `Person` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Person`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Person` (`Person` )
                VALUES ('Richard Enter')
                      , ('Dick River')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /*************************************************\
    * Plug Integer                                    *
    *                                                 *
    * fields:                                         *
    * EDcI Integer  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \*************************************************/
    mysql_query("CREATE TABLE `Integer`
                     ( `Integer` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Integer`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Integer` (`Integer` )
                VALUES ('60')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************************\
    * Plug Amount                                    *
    *                                                *
    * fields:                                        *
    * EDcI Amount  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \************************************************/
    mysql_query("CREATE TABLE `Amount`
                     ( `Amount` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Amount`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Amount` (`Amount` )
                VALUES ('61')
                      , ('67')
                      , ('38')
                      , ('23')
                      , ('63')
                      , ('56')
                      , ('60')
                      , ('25')
                      , ('12')
                      , ('34')
                      , ('19')
                      , ('103')
                      , ('0')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /***********************************************\
    * Plug Model                                    *
    *                                               *
    * fields:                                       *
    * EDcI Model  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \***********************************************/
    mysql_query("CREATE TABLE `Model`
                     ( `Model` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Model`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Model` (`Model` )
                VALUES ('Beetle')
                      , ('Polo')
                      , ('Passat')
                      , ('A4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /***********************************************\
    * Plug Brand                                    *
    *                                               *
    * fields:                                       *
    * EDcI Brand  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \***********************************************/
    mysql_query("CREATE TABLE `Brand`
                     ( `Brand` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Brand`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Brand` (`Brand` )
                VALUES ('Volkswagen')
                      , ('Audi')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************************\
    * Plug Location                                    *
    *                                                  *
    * fields:                                          *
    * EDcI Location  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************************/
    mysql_query("CREATE TABLE `Location`
                     ( `Location` VARCHAR(255) DEFAULT NULL
                     , PRIMARY KEY (`Location`)
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Location` (`Location` )
                VALUES ('Amsterdam')
                      , ('Rotterdam')
                      , ('Den Haag')
                      , ('Utrecht')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************\
    * Plug dateIntervalIsWithinMaxRentalDuration                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 *
    *                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            *
    * fields:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    *
    * EIsc (EDcI Date,ECps (EDcD RELATION dateIntervalIsWithinMaxRentalDuration [Date*Date] Just [] PRAGMA "The period between" "and" "does not exceed the maximum allowed rental duration" MEANING IN English HTML {+ the date interval (e.g.: [start date,end date]) is within the maximum rental duration as specified by EURent. -},EFlp (EDcD RELATION dateIntervalIsWithinMaxRentalDuration [Date*Date] Just [] PRAGMA "The period between" "and" "does not exceed the maximum allowed rental duration" MEANING IN English HTML {+ the date interval (e.g.: [start date,end date]) is within the maximum rental duration as specified by EURent. -})))  [] *
    * EDcD RELATION dateIntervalIsWithinMaxRentalDuration [Date*Date] Just [] PRAGMA "The period between" "and" "does not exceed the maximum allowed rental duration" MEANING IN English HTML {+ the date interval (e.g.: [start date,end date]) is within the maximum rental duration as specified by EURent. -}  []                                                                                                                                                                                                                                                                                                                                            *
    \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `dateIntervalIsWithinMaxRentalDuration`
                     ( `SrcDate` VARCHAR(255) DEFAULT NULL
                     , `TgtDate` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `dateIntervalIsWithinMaxRentalDuration` (`SrcDate` ,`TgtDate` )
                VALUES ('01-06-2014', '07-06-2014')
                      , ('01-07-2014', '10-07-2014')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /****************************************************************************************************************************************************************************************\
    * Plug dateIntervalCompTrigger                                                                                                                                                           *
    *                                                                                                                                                                                        *
    * fields:                                                                                                                                                                                *
    * EIsc (EDcI Date,ECps (EDcD RELATION dateIntervalCompTrigger [Date*Date] Just [] PRAGMA "" "" "",EFlp (EDcD RELATION dateIntervalCompTrigger [Date*Date] Just [] PRAGMA "" "" "")))  [] *
    * EDcD RELATION dateIntervalCompTrigger [Date*Date] Just [] PRAGMA "" "" ""  []                                                                                                          *
    \****************************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `dateIntervalCompTrigger`
                     ( `SrcDate` VARCHAR(255) DEFAULT NULL
                     , `TgtDate` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /*********************************************************************************************************************************************************************************\
    * Plug distbranch                                                                                                                                                                 *
    *                                                                                                                                                                                 *
    * fields:                                                                                                                                                                         *
    * EDcI DistanceBetweenLocations  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX]                                                                                                                *
    * EDcD RELATION distbranch [DistanceBetweenLocations*Branch] Just [TOT,SUR] PRAGMA "" "" "" MEANING IN English HTML {+ A distance is computed relative to a branch. -}  [TOT,SUR] *
    \*********************************************************************************************************************************************************************************/
    mysql_query("CREATE TABLE `distbranch`
                     ( `DistanceBetweenLocations` VARCHAR(255) DEFAULT NULL
                     , `Branch` VARCHAR(255) DEFAULT NULL
                     ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `distbranch` (`DistanceBetweenLocations` ,`Branch` )
                VALUES ('AMS-DHG', 'AMS')
                      , ('AMS-DHG', 'DHG')
                      , ('AMS-RTD', 'AMS')
                      , ('AMS-RTD', 'RTD')
                      , ('AMS-UTR', 'AMS')
                      , ('AMS-UTR', 'UTR')
                      , ('DHG-RTD', 'DHG')
                      , ('DHG-RTD', 'RTD')
                      , ('DHG-UTR', 'DHG')
                      , ('DHG-UTR', 'UTR')
                      , ('RTD-UTR', 'RTD')
                      , ('RTD-UTR', 'UTR')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo '<div id="ResetSuccess"/>The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "Generics.php";
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT EURent\n");
      fwrite($dumpfile, dumprel("branchOf[Branch*CarRentalCompany]","SELECT DISTINCT `Branch`, `branchOf` FROM `Branch` WHERE `Branch` IS NOT NULL AND `branchOf` IS NOT NULL"));
      fwrite($dumpfile, dumprel("branchLocation[Branch*Location]","SELECT DISTINCT `Branch`, `branchLocation` FROM `Branch` WHERE `Branch` IS NOT NULL AND `branchLocation` IS NOT NULL"));
      fwrite($dumpfile, dumprel("carAvailableAt[Car*Branch]","SELECT DISTINCT `Car`, `carAvailableAt` FROM `Car` WHERE `Car` IS NOT NULL AND `carAvailableAt` IS NOT NULL"));
      fwrite($dumpfile, dumprel("carType[Car*CarType]","SELECT DISTINCT `Car`, `carType` FROM `Car` WHERE `Car` IS NOT NULL AND `carType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("brand[CarType*Brand]","SELECT DISTINCT `CarType`, `brand` FROM `CarType` WHERE `CarType` IS NOT NULL AND `brand` IS NOT NULL"));
      fwrite($dumpfile, dumprel("model[CarType*Model]","SELECT DISTINCT `CarType`, `model` FROM `CarType` WHERE `CarType` IS NOT NULL AND `model` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalTariffPerDay[CarType*Amount]","SELECT DISTINCT `CarType`, `rentalTariffPerDay` FROM `CarType` WHERE `CarType` IS NOT NULL AND `rentalTariffPerDay` IS NOT NULL"));
      fwrite($dumpfile, dumprel("excessTariffPerDay[CarType*Amount]","SELECT DISTINCT `CarType`, `excessTariffPerDay` FROM `CarType` WHERE `CarType` IS NOT NULL AND `excessTariffPerDay` IS NOT NULL"));
      fwrite($dumpfile, dumprel("maxRentalDuration[CarRentalCompany*Integer]","SELECT DISTINCT `CarRentalCompany`, `maxRentalDuration` FROM `CarRentalCompany` WHERE `CarRentalCompany` IS NOT NULL AND `maxRentalDuration` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedStartDate[RentalCase*Date]","SELECT DISTINCT `RentalCase`, `contractedStartDate` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedStartDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedEndDate[RentalCase*Date]","SELECT DISTINCT `RentalCase`, `contractedEndDate` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedEndDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedCarType[RentalCase*CarType]","SELECT DISTINCT `RentalCase`, `contractedCarType` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedCarType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedPickupBranch[RentalCase*Branch]","SELECT DISTINCT `RentalCase`, `contractedPickupBranch` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedPickupBranch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedDropOffBranch[RentalCase*Branch]","SELECT DISTINCT `RentalCase`, `contractedDropOffBranch` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedDropOffBranch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcRenter[RentalCase*Person]","SELECT DISTINCT `RentalCase`, `rcRenter` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcRenter` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDriver[RentalCase*Person]","SELECT DISTINCT `RentalCase`, `rcDriver` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDriver` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDrivingLicense[RentalCase*DrivingLicense]","SELECT DISTINCT `RentalCase`, `rcDrivingLicense` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDrivingLicense` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcAssignedCar[RentalCase*Car]","SELECT DISTINCT `RentalCase`, `rcAssignedCar` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcAssignedCar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalHasBeenPromised[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalHasBeenPromised` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalHasBeenPromised` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcUserRequestedQ[RentalCase*YesNoAnswer]","SELECT DISTINCT `RentalCase`, `rcUserRequestedQ` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcUserRequestedQ` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcBranchRequestedQ[RentalCase*YesNoAnswer]","SELECT DISTINCT `RentalCase`, `rcBranchRequestedQ` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcBranchRequestedQ` IS NOT NULL"));
      fwrite($dumpfile, dumprel("dateIntervalIsWithinMaxRentalDuration[Date*Date]","SELECT DISTINCT `SrcDate`, `TgtDate` FROM `dateIntervalIsWithinMaxRentalDuration` WHERE `SrcDate` IS NOT NULL AND `TgtDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalCarHasBeenPickedUp[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalCarHasBeenPickedUp` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalCarHasBeenPickedUp` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcKeysHandedOverQ[RentalCase*YesNoAnswer]","SELECT DISTINCT `RentalCase`, `rcKeysHandedOverQ` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcKeysHandedOverQ` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalHasBeenStarted[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalHasBeenStarted` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalHasBeenStarted` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalCarHasBeenDroppedOff[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalCarHasBeenDroppedOff` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalCarHasBeenDroppedOff` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDroppedOffCar[RentalCase*Car]","SELECT DISTINCT `RentalCase`, `rcDroppedOffCar` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDroppedOffCar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDroppedOffDate[RentalCase*Date]","SELECT DISTINCT `RentalCase`, `rcDroppedOffDate` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDroppedOffDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDroppedOffBranch[RentalCase*Branch]","SELECT DISTINCT `RentalCase`, `rcDroppedOffBranch` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDroppedOffBranch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractualRentalPeriod[RentalCase*Integer]","SELECT DISTINCT `RentalCase`, `contractualRentalPeriod` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractualRentalPeriod` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractualBasicCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `contractualBasicCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractualBasicCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalPeriod[RentalCase*Integer]","SELECT DISTINCT `RentalCase`, `rentalPeriod` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalPeriod` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalBasicCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `rentalBasicCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalBasicCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalExcessPeriod[RentalCase*Integer]","SELECT DISTINCT `RentalCase`, `rentalExcessPeriod` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalExcessPeriod` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalPenaltyCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `rentalPenaltyCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalPenaltyCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedLocationPenaltyCharge[DistanceBetweenLocations*Amount]","SELECT DISTINCT `DistanceBetweenLocations`, `computedLocationPenaltyCharge` FROM `DistanceBetweenLocations` WHERE `DistanceBetweenLocations` IS NOT NULL AND `computedLocationPenaltyCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalLocationPenaltyCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `rentalLocationPenaltyCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalLocationPenaltyCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `rentalCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("paymentHasBeenRequested[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `paymentHasBeenRequested` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `paymentHasBeenRequested` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalIsPaidQ[RentalCase*YesNoAnswer]","SELECT DISTINCT `RentalCase`, `rentalIsPaidQ` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalIsPaidQ` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalHasBeenEnded[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalHasBeenEnded` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalHasBeenEnded` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcMaxRentalDuration[RentalCase*Integer]","SELECT DISTINCT `RentalCase`, `rcMaxRentalDuration` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcMaxRentalDuration` IS NOT NULL"));
      fwrite($dumpfile, dumprel("dateIntervalCompTrigger[Date*Date]","SELECT DISTINCT `SrcDate`, `TgtDate` FROM `dateIntervalCompTrigger` WHERE `SrcDate` IS NOT NULL AND `TgtDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("arg1[CompRentalCharge*Amount]","SELECT DISTINCT `CompRentalCharge`, `arg1` FROM `CompRentalCharge` WHERE `CompRentalCharge` IS NOT NULL AND `arg1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("arg2[CompRentalCharge*Amount]","SELECT DISTINCT `CompRentalCharge`, `arg2` FROM `CompRentalCharge` WHERE `CompRentalCharge` IS NOT NULL AND `arg2` IS NOT NULL"));
      fwrite($dumpfile, dumprel("arg3[CompRentalCharge*Amount]","SELECT DISTINCT `CompRentalCharge`, `arg3` FROM `CompRentalCharge` WHERE `CompRentalCharge` IS NOT NULL AND `arg3` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedRentalCharge[CompRentalCharge*Amount]","SELECT DISTINCT `CompRentalCharge`, `computedRentalCharge` FROM `CompRentalCharge` WHERE `CompRentalCharge` IS NOT NULL AND `computedRentalCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("earliestDate[DateDifferencePlusOne*Date]","SELECT DISTINCT `DateDifferencePlusOne`, `earliestDate` FROM `DateDifferencePlusOne` WHERE `DateDifferencePlusOne` IS NOT NULL AND `earliestDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("latestDate[DateDifferencePlusOne*Date]","SELECT DISTINCT `DateDifferencePlusOne`, `latestDate` FROM `DateDifferencePlusOne` WHERE `DateDifferencePlusOne` IS NOT NULL AND `latestDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedRentalPeriod[DateDifferencePlusOne*Integer]","SELECT DISTINCT `DateDifferencePlusOne`, `computedRentalPeriod` FROM `DateDifferencePlusOne` WHERE `DateDifferencePlusOne` IS NOT NULL AND `computedRentalPeriod` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ctcNrOfDays[CompTariffedCharge*Integer]","SELECT DISTINCT `CompTariffedCharge`, `ctcNrOfDays` FROM `CompTariffedCharge` WHERE `CompTariffedCharge` IS NOT NULL AND `ctcNrOfDays` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ctcDailyAmount[CompTariffedCharge*Amount]","SELECT DISTINCT `CompTariffedCharge`, `ctcDailyAmount` FROM `CompTariffedCharge` WHERE `CompTariffedCharge` IS NOT NULL AND `ctcDailyAmount` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedTariffedCharge[CompTariffedCharge*Amount]","SELECT DISTINCT `CompTariffedCharge`, `computedTariffedCharge` FROM `CompTariffedCharge` WHERE `CompTariffedCharge` IS NOT NULL AND `computedTariffedCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("firstDate[DateDifference*Date]","SELECT DISTINCT `DateDifference`, `firstDate` FROM `DateDifference` WHERE `DateDifference` IS NOT NULL AND `firstDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("lastDate[DateDifference*Date]","SELECT DISTINCT `DateDifference`, `lastDate` FROM `DateDifference` WHERE `DateDifference` IS NOT NULL AND `lastDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedNrOfExcessDays[DateDifference*Integer]","SELECT DISTINCT `DateDifference`, `computedNrOfExcessDays` FROM `DateDifference` WHERE `DateDifference` IS NOT NULL AND `computedNrOfExcessDays` IS NOT NULL"));
      fwrite($dumpfile, dumprel("distbranch[DistanceBetweenLocations*Branch]","SELECT DISTINCT `DistanceBetweenLocations`, `Branch` FROM `distbranch` WHERE `DistanceBetweenLocations` IS NOT NULL AND `Branch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("distance[DistanceBetweenLocations*Distance]","SELECT DISTINCT `DistanceBetweenLocations`, `distance` FROM `DistanceBetweenLocations` WHERE `DistanceBetweenLocations` IS NOT NULL AND `distance` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionDroppedoffRC[SESSION*RentalCase]","SELECT DISTINCT `SESSION`, `sessionDroppedoffRC` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionDroppedoffRC` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionDroppedOffCar[SESSION*Car]","SELECT DISTINCT `SESSION`, `sessionDroppedOffCar` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionDroppedOffCar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionDroppedOffPerson[SESSION*Person]","SELECT DISTINCT `SESSION`, `sessionDroppedOffPerson` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionDroppedOffPerson` IS NOT NULL"));
      fwrite($dumpfile, dumprel("defaultSessionToday[Date*Date]","SELECT DISTINCT `Date`, `defaultSessionToday` FROM `Date` WHERE `Date` IS NOT NULL AND `defaultSessionToday` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionNewRC[SESSION*RentalCase]","SELECT DISTINCT `SESSION`, `sessionNewRC` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionNewRC` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionBranch[SESSION*Branch]","SELECT DISTINCT `SESSION`, `sessionBranch` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionBranch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionNewBranchRC[SESSION*RentalCase]","SELECT DISTINCT `SESSION`, `sessionNewBranchRC` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionNewBranchRC` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionPickupPerson[SESSION*Person]","SELECT DISTINCT `SESSION`, `sessionPickupPerson` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionPickupPerson` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionToday[SESSION*Date]","SELECT DISTINCT `SESSION`, `sessionToday` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionToday` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionNewUserRC[SESSION*RentalCase]","SELECT DISTINCT `SESSION`, `sessionNewUserRC` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionNewUserRC` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer($quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
