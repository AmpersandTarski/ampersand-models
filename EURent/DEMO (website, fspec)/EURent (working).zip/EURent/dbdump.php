
      <?php
      require "Generics.php";
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT EURent\n");
      fwrite($dumpfile, dumprel("branchOf[Branch*CarRentalCompany]","SELECT DISTINCT `Branch`, `branchOf` FROM `Branch` WHERE `Branch` IS NOT NULL AND `branchOf` IS NOT NULL"));
      fwrite($dumpfile, dumprel("branchLocation[Branch*Location]","SELECT DISTINCT `Branch`, `branchLocation` FROM `Branch` WHERE `Branch` IS NOT NULL AND `branchLocation` IS NOT NULL"));
      fwrite($dumpfile, dumprel("carAvailableAt[Car*Branch]","SELECT DISTINCT `Car`, `carAvailableAt` FROM `Car` WHERE `Car` IS NOT NULL AND `carAvailableAt` IS NOT NULL"));
      fwrite($dumpfile, dumprel("carType[Car*CarType]","SELECT DISTINCT `Car`, `carType` FROM `Car` WHERE `Car` IS NOT NULL AND `carType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("brand[CarType*Brand]","SELECT DISTINCT `CarType`, `brand` FROM `CarType` WHERE `CarType` IS NOT NULL AND `brand` IS NOT NULL"));
      fwrite($dumpfile, dumprel("model[CarType*Model]","SELECT DISTINCT `CarType`, `model` FROM `CarType` WHERE `CarType` IS NOT NULL AND `model` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalTariffPerDay[CarType*Amount]","SELECT DISTINCT `CarType`, `rentalTariffPerDay` FROM `CarType` WHERE `CarType` IS NOT NULL AND `rentalTariffPerDay` IS NOT NULL"));
      fwrite($dumpfile, dumprel("excessTariffPerDay[CarType*Amount]","SELECT DISTINCT `CarType`, `excessTariffPerDay` FROM `CarType` WHERE `CarType` IS NOT NULL AND `excessTariffPerDay` IS NOT NULL"));
      fwrite($dumpfile, dumprel("maxRentalDuration[CarRentalCompany*Integer]","SELECT DISTINCT `CarRentalCompany`, `maxRentalDuration` FROM `CarRentalCompany` WHERE `CarRentalCompany` IS NOT NULL AND `maxRentalDuration` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedStartDate[RentalCase*Date]","SELECT DISTINCT `RentalCase`, `contractedStartDate` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedStartDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedEndDate[RentalCase*Date]","SELECT DISTINCT `RentalCase`, `contractedEndDate` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedEndDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedCarType[RentalCase*CarType]","SELECT DISTINCT `RentalCase`, `contractedCarType` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedCarType` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedPickupBranch[RentalCase*Branch]","SELECT DISTINCT `RentalCase`, `contractedPickupBranch` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedPickupBranch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractedDropOffBranch[RentalCase*Branch]","SELECT DISTINCT `RentalCase`, `contractedDropOffBranch` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractedDropOffBranch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcRenter[RentalCase*Person]","SELECT DISTINCT `RentalCase`, `rcRenter` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcRenter` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDriver[RentalCase*Person]","SELECT DISTINCT `RentalCase`, `rcDriver` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDriver` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDrivingLicense[RentalCase*DrivingLicense]","SELECT DISTINCT `RentalCase`, `rcDrivingLicense` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDrivingLicense` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcAssignedCar[RentalCase*Car]","SELECT DISTINCT `RentalCase`, `rcAssignedCar` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcAssignedCar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalHasBeenPromised[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalHasBeenPromised` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalHasBeenPromised` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcUserRequestedQ[RentalCase*YesNoAnswer]","SELECT DISTINCT `RentalCase`, `rcUserRequestedQ` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcUserRequestedQ` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcBranchRequestedQ[RentalCase*YesNoAnswer]","SELECT DISTINCT `RentalCase`, `rcBranchRequestedQ` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcBranchRequestedQ` IS NOT NULL"));
      fwrite($dumpfile, dumprel("dateIntervalIsWithinMaxRentalDuration[Date*Date]","SELECT DISTINCT `SrcDate`, `TgtDate` FROM `dateIntervalIsWithinMaxRentalDuration` WHERE `SrcDate` IS NOT NULL AND `TgtDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalCarHasBeenPickedUp[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalCarHasBeenPickedUp` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalCarHasBeenPickedUp` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcKeysHandedOverQ[RentalCase*YesNoAnswer]","SELECT DISTINCT `RentalCase`, `rcKeysHandedOverQ` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcKeysHandedOverQ` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalHasBeenStarted[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalHasBeenStarted` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalHasBeenStarted` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalCarHasBeenDroppedOff[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalCarHasBeenDroppedOff` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalCarHasBeenDroppedOff` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDroppedOffCar[RentalCase*Car]","SELECT DISTINCT `RentalCase`, `rcDroppedOffCar` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDroppedOffCar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDroppedOffDate[RentalCase*Date]","SELECT DISTINCT `RentalCase`, `rcDroppedOffDate` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDroppedOffDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcDroppedOffBranch[RentalCase*Branch]","SELECT DISTINCT `RentalCase`, `rcDroppedOffBranch` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcDroppedOffBranch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractualRentalPeriod[RentalCase*Integer]","SELECT DISTINCT `RentalCase`, `contractualRentalPeriod` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractualRentalPeriod` IS NOT NULL"));
      fwrite($dumpfile, dumprel("contractualBasicCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `contractualBasicCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `contractualBasicCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalPeriod[RentalCase*Integer]","SELECT DISTINCT `RentalCase`, `rentalPeriod` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalPeriod` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalBasicCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `rentalBasicCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalBasicCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalExcessPeriod[RentalCase*Integer]","SELECT DISTINCT `RentalCase`, `rentalExcessPeriod` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalExcessPeriod` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalPenaltyCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `rentalPenaltyCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalPenaltyCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedLocationPenaltyCharge[DistanceBetweenLocations*Amount]","SELECT DISTINCT `DistanceBetweenLocations`, `computedLocationPenaltyCharge` FROM `DistanceBetweenLocations` WHERE `DistanceBetweenLocations` IS NOT NULL AND `computedLocationPenaltyCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalLocationPenaltyCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `rentalLocationPenaltyCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalLocationPenaltyCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalCharge[RentalCase*Amount]","SELECT DISTINCT `RentalCase`, `rentalCharge` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("paymentHasBeenRequested[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `paymentHasBeenRequested` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `paymentHasBeenRequested` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalIsPaidQ[RentalCase*YesNoAnswer]","SELECT DISTINCT `RentalCase`, `rentalIsPaidQ` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalIsPaidQ` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rentalHasBeenEnded[RentalCase*RentalCase]","SELECT DISTINCT `RentalCase`, `rentalHasBeenEnded` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rentalHasBeenEnded` IS NOT NULL"));
      fwrite($dumpfile, dumprel("rcMaxRentalDuration[RentalCase*Integer]","SELECT DISTINCT `RentalCase`, `rcMaxRentalDuration` FROM `RentalCase` WHERE `RentalCase` IS NOT NULL AND `rcMaxRentalDuration` IS NOT NULL"));
      fwrite($dumpfile, dumprel("dateIntervalCompTrigger[Date*Date]","SELECT DISTINCT `SrcDate`, `TgtDate` FROM `dateIntervalCompTrigger` WHERE `SrcDate` IS NOT NULL AND `TgtDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("arg1[CompRentalCharge*Amount]","SELECT DISTINCT `CompRentalCharge`, `arg1` FROM `CompRentalCharge` WHERE `CompRentalCharge` IS NOT NULL AND `arg1` IS NOT NULL"));
      fwrite($dumpfile, dumprel("arg2[CompRentalCharge*Amount]","SELECT DISTINCT `CompRentalCharge`, `arg2` FROM `CompRentalCharge` WHERE `CompRentalCharge` IS NOT NULL AND `arg2` IS NOT NULL"));
      fwrite($dumpfile, dumprel("arg3[CompRentalCharge*Amount]","SELECT DISTINCT `CompRentalCharge`, `arg3` FROM `CompRentalCharge` WHERE `CompRentalCharge` IS NOT NULL AND `arg3` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedRentalCharge[CompRentalCharge*Amount]","SELECT DISTINCT `CompRentalCharge`, `computedRentalCharge` FROM `CompRentalCharge` WHERE `CompRentalCharge` IS NOT NULL AND `computedRentalCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("earliestDate[DateDifferencePlusOne*Date]","SELECT DISTINCT `DateDifferencePlusOne`, `earliestDate` FROM `DateDifferencePlusOne` WHERE `DateDifferencePlusOne` IS NOT NULL AND `earliestDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("latestDate[DateDifferencePlusOne*Date]","SELECT DISTINCT `DateDifferencePlusOne`, `latestDate` FROM `DateDifferencePlusOne` WHERE `DateDifferencePlusOne` IS NOT NULL AND `latestDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedRentalPeriod[DateDifferencePlusOne*Integer]","SELECT DISTINCT `DateDifferencePlusOne`, `computedRentalPeriod` FROM `DateDifferencePlusOne` WHERE `DateDifferencePlusOne` IS NOT NULL AND `computedRentalPeriod` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ctcNrOfDays[CompTariffedCharge*Integer]","SELECT DISTINCT `CompTariffedCharge`, `ctcNrOfDays` FROM `CompTariffedCharge` WHERE `CompTariffedCharge` IS NOT NULL AND `ctcNrOfDays` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ctcDailyAmount[CompTariffedCharge*Amount]","SELECT DISTINCT `CompTariffedCharge`, `ctcDailyAmount` FROM `CompTariffedCharge` WHERE `CompTariffedCharge` IS NOT NULL AND `ctcDailyAmount` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedTariffedCharge[CompTariffedCharge*Amount]","SELECT DISTINCT `CompTariffedCharge`, `computedTariffedCharge` FROM `CompTariffedCharge` WHERE `CompTariffedCharge` IS NOT NULL AND `computedTariffedCharge` IS NOT NULL"));
      fwrite($dumpfile, dumprel("firstDate[DateDifference*Date]","SELECT DISTINCT `DateDifference`, `firstDate` FROM `DateDifference` WHERE `DateDifference` IS NOT NULL AND `firstDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("lastDate[DateDifference*Date]","SELECT DISTINCT `DateDifference`, `lastDate` FROM `DateDifference` WHERE `DateDifference` IS NOT NULL AND `lastDate` IS NOT NULL"));
      fwrite($dumpfile, dumprel("computedNrOfExcessDays[DateDifference*Integer]","SELECT DISTINCT `DateDifference`, `computedNrOfExcessDays` FROM `DateDifference` WHERE `DateDifference` IS NOT NULL AND `computedNrOfExcessDays` IS NOT NULL"));
      fwrite($dumpfile, dumprel("distbranch[DistanceBetweenLocations*Branch]","SELECT DISTINCT `DistanceBetweenLocations`, `Branch` FROM `distbranch` WHERE `DistanceBetweenLocations` IS NOT NULL AND `Branch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("distance[DistanceBetweenLocations*Distance]","SELECT DISTINCT `DistanceBetweenLocations`, `distance` FROM `DistanceBetweenLocations` WHERE `DistanceBetweenLocations` IS NOT NULL AND `distance` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionDroppedoffRC[SESSION*RentalCase]","SELECT DISTINCT `SESSION`, `sessionDroppedoffRC` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionDroppedoffRC` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionDroppedOffCar[SESSION*Car]","SELECT DISTINCT `SESSION`, `sessionDroppedOffCar` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionDroppedOffCar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionDroppedOffPerson[SESSION*Person]","SELECT DISTINCT `SESSION`, `sessionDroppedOffPerson` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionDroppedOffPerson` IS NOT NULL"));
      fwrite($dumpfile, dumprel("defaultSessionToday[Date*Date]","SELECT DISTINCT `Date`, `defaultSessionToday` FROM `Date` WHERE `Date` IS NOT NULL AND `defaultSessionToday` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionNewRC[SESSION*RentalCase]","SELECT DISTINCT `SESSION`, `sessionNewRC` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionNewRC` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionBranch[SESSION*Branch]","SELECT DISTINCT `SESSION`, `sessionBranch` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionBranch` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionNewBranchRC[SESSION*RentalCase]","SELECT DISTINCT `SESSION`, `sessionNewBranchRC` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionNewBranchRC` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionPickupPerson[SESSION*Person]","SELECT DISTINCT `SESSION`, `sessionPickupPerson` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionPickupPerson` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionToday[SESSION*Date]","SELECT DISTINCT `SESSION`, `sessionToday` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionToday` IS NOT NULL"));
      fwrite($dumpfile, dumprel("sessionNewUserRC[SESSION*RentalCase]","SELECT DISTINCT `SESSION`, `sessionNewUserRC` FROM `SESSION` WHERE `SESSION` IS NOT NULL AND `sessionNewUserRC` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer($quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\"",$str); }
      ?>