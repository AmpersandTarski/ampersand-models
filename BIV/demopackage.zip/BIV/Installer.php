<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta http-equiv="cache-Control" content="no-cache">
  
  </html>
  <body>
  <?php
  // Try to connect to the database

  if(isset($DB_host)&&!isset($_REQUEST['DB_host'])){
    $included = true; // this means user/pass are probably correct
    $DB_link = @mysql_connect(@$DB_host,@$DB_user,@$DB_pass);
  }else{
    $included = false; // get user/pass elsewhere
    if(file_exists("dbSettings.php")) include "dbSettings.php";
    else { // no settings found.. try some default settings
      if(!( $DB_link=@mysql_connect($DB_host='localhost',$DB_user='root',$DB_pass='')))
      { // we still have no working settings.. ask the user!
        die("Install failed: cannot connect to MySQL"); // todo
      }
    } 
  }
  if($DB_slct = @mysql_select_db('ounl')){
    $existing=true;
  }else{
    $existing = false; // db does not exist, so try to create it
    @mysql_query("CREATE DATABASE `ounl` DEFAULT CHARACTER SET UTF8");
    $DB_slct = @mysql_select_db('ounl');
  }
  if(!$DB_slct){
    echo die("Install failed: cannot connect to MySQL or error selecting database 'ounl'");
  }else{
    if(!$included && !file_exists("dbSettings.php")){ // we have a link now; try to write the dbSettings.php file
       if($fh = @fopen("dbSettings.php", 'w')){
         fwrite($fh, '<'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'>');
         fclose($fh);
       }else die('<P>Error: could not write dbSettings.php, make sure that the directory of Installer.php is writable
                  or create dbSettings.php in the same directory as Installer.php
                  and paste the following code into it:</P><code>'.
                 '&lt;'.'?php $DB_link=mysql_connect($DB_host="'.$DB_host.'", $DB_user="'.$DB_user.'", $DB_pass="'.$DB_pass.'"); $DB_debug = 3; ?'.'&gt;</code>');
    }

    $error=false;
    /*** Create new SQL tables ***/
    
    // Session timeout table
    if($columns = mysql_query("SHOW COLUMNS FROM `__SessionTimeout__`")){
        mysql_query("DROP TABLE `__SessionTimeout__`");
    }
    mysql_query("CREATE TABLE `__SessionTimeout__`
                         ( `SESSION` VARCHAR(255) UNIQUE NOT NULL
                         , `lastAccess` BIGINT NOT NULL
                          ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    // Timestamp table
    if($columns = mysql_query("SHOW COLUMNS FROM `__History__`")){
        mysql_query("DROP TABLE `__History__`");
    }
    mysql_query("CREATE TABLE `__History__`
                         ( `Seconds` VARCHAR(255) DEFAULT NULL
                         , `Date` VARCHAR(255) DEFAULT NULL
                          ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    $time = explode(' ', microTime()); // copied from DatabaseUtils setTimestamp
    $microseconds = substr($time[0], 2,6);
    $seconds =$time[1].$microseconds;
    $date = date("j-M-Y, H:i:s.").$microseconds;
    mysql_query("INSERT INTO `__History__` (`Seconds`,`Date`) VALUES ('$seconds','$date')");
    if($err=mysql_error()) {
      $error=true; echo $err.'<br />';
    }
    
    //// Number of plugs: 29
    if($existing==true){
      if($columns = mysql_query("SHOW COLUMNS FROM `Gebeurtenis`")){
        mysql_query("DROP TABLE `Gebeurtenis`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Product`")){
        mysql_query("DROP TABLE `Product`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Cel`")){
        mysql_query("DROP TABLE `Cel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Log`")){
        mysql_query("DROP TABLE `Log`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Studiepad`")){
        mysql_query("DROP TABLE `Studiepad`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Functie`")){
        mysql_query("DROP TABLE `Functie`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Naam`")){
        mysql_query("DROP TABLE `Naam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Eenheid`")){
        mysql_query("DROP TABLE `Eenheid`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Waarde`")){
        mysql_query("DROP TABLE `Waarde`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Resultaat`")){
        mysql_query("DROP TABLE `Resultaat`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `TransitieStudentsoort`")){
        mysql_query("DROP TABLE `TransitieStudentsoort`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Inschrijvingsvorm`")){
        mysql_query("DROP TABLE `Inschrijvingsvorm`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Student`")){
        mysql_query("DROP TABLE `Student`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Leermiddel`")){
        mysql_query("DROP TABLE `Leermiddel`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Arbeidskracht`")){
        mysql_query("DROP TABLE `Arbeidskracht`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Cursusinhoud`")){
        mysql_query("DROP TABLE `Cursusinhoud`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Cursuscode`")){
        mysql_query("DROP TABLE `Cursuscode`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Orgaan`")){
        mysql_query("DROP TABLE `Orgaan`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Aantal`")){
        mysql_query("DROP TABLE `Aantal`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Productnaam`")){
        mysql_query("DROP TABLE `Productnaam`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `Datum`")){
        mysql_query("DROP TABLE `Datum`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `bestaatuit`")){
        mysql_query("DROP TABLE `bestaatuit`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `tbv`")){
        mysql_query("DROP TABLE `tbv`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `omvat`")){
        mysql_query("DROP TABLE `omvat`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `examinators`")){
        mysql_query("DROP TABLE `examinators`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `cursusmateriaal`")){
        mysql_query("DROP TABLE `cursusmateriaal`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `heeftdocent`")){
        mysql_query("DROP TABLE `heeftdocent`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `inschrijvingsvormen`")){
        mysql_query("DROP TABLE `inschrijvingsvormen`");
      }
      if($columns = mysql_query("SHOW COLUMNS FROM `bevat`")){
        mysql_query("DROP TABLE `bevat`");
      }
    }
    /**************************************\
    * Plug Gebeurtenis                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * Cursusuitvoering~  [INJ,SUR,UNI]     *
    * Aanmelding~  [INJ,SUR,UNI]           *
    * Cursusinschrijving~  [INJ,SUR,UNI]   *
    * VerlopenRechten~  [INJ,SUR,UNI]      *
    * Transitie~  [INJ,SUR,UNI]            *
    * Tentamen~  [INJ,SUR,UNI]             *
    * verloopt~  [UNI,INJ,SUR]             *
    * moment  [UNI,TOT]                    *
    * voertuit  [UNI,TOT]                  *
    * cursusaanmelding  [UNI,TOT]          *
    * studentaanmelding  [UNI,TOT]         *
    * cursus  [UNI,TOT]                    *
    * student  [UNI,TOT]                   *
    * goedgekeurd  [UNI,TOT]               *
    * inschrijvingsvorm  [UNI,TOT]         *
    * transitiebetreft  [UNI,TOT]          *
    * transitienaar  [UNI,TOT]             *
    * veroorzaaktdoor  [UNI,TOT]           *
    * vorigetransitie  [UNI,TOT]           *
    * gemaaktdoor  [UNI,TOT]               *
    * tentamenvoor  [UNI,TOT]              *
    * beoordeling  [UNI]                   *
    * beoordeeltdoor  [UNI,TOT]            *
    \**************************************/
    mysql_query("CREATE TABLE `Gebeurtenis`
                     ( `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                     , `Cursusuitvoering` VARCHAR(255) DEFAULT NULL
                     , `Aanmelding` VARCHAR(255) DEFAULT NULL
                     , `Cursusinschrijving` VARCHAR(255) DEFAULT NULL
                     , `VerlopenRechten` VARCHAR(255) DEFAULT NULL
                     , `Transitie` VARCHAR(255) DEFAULT NULL
                     , `Tentamen` VARCHAR(255) DEFAULT NULL
                     , `verloopt` VARCHAR(255) DEFAULT NULL
                     , `moment` VARCHAR(255) DEFAULT NULL
                     , `voertuit` VARCHAR(255) DEFAULT NULL
                     , `cursusaanmelding` VARCHAR(255) DEFAULT NULL
                     , `studentaanmelding` VARCHAR(255) DEFAULT NULL
                     , `cursus` VARCHAR(255) DEFAULT NULL
                     , `student` VARCHAR(255) DEFAULT NULL
                     , `goedgekeurd` VARCHAR(255) DEFAULT NULL
                     , `inschrijvingsvorm` VARCHAR(255) DEFAULT NULL
                     , `transitiebetreft` VARCHAR(255) DEFAULT NULL
                     , `transitienaar` VARCHAR(255) DEFAULT NULL
                     , `veroorzaaktdoor` VARCHAR(255) DEFAULT NULL
                     , `vorigetransitie` VARCHAR(255) DEFAULT NULL
                     , `gemaaktdoor` VARCHAR(255) DEFAULT NULL
                     , `tentamenvoor` VARCHAR(255) DEFAULT NULL
                     , `beoordeling` VARCHAR(255) DEFAULT NULL
                     , `beoordeeltdoor` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Gebeurtenis` (`Gebeurtenis` ,`Cursusuitvoering` ,`Aanmelding` ,`Cursusinschrijving` ,`VerlopenRechten` ,`Transitie` ,`Tentamen` ,`verloopt` ,`moment` ,`voertuit` ,`cursusaanmelding` ,`studentaanmelding` ,`cursus` ,`student` ,`goedgekeurd` ,`inschrijvingsvorm` ,`transitiebetreft` ,`transitienaar` ,`veroorzaaktdoor` ,`vorigetransitie` ,`gemaaktdoor` ,`tentamenvoor` ,`beoordeling` ,`beoordeeltdoor` )
                VALUES ('Aanmelding_1326202668_191000', NULL, 'Aanmelding_1326202668_191000', NULL, NULL, NULL, NULL, NULL, '07/01/2012', NULL, 'Cursus_1326194435_466000', '877777777', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326194211_034000', 'Cursusuitvoering_1326194211_034000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326194211_034000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusinschrijving_1326202829_167000', NULL, NULL, 'Cursusinschrijving_1326202829_167000', NULL, NULL, NULL, NULL, '10/01/2012', NULL, NULL, NULL, 'Cursus_1326194435_466000', '877777777', 'Aanmelding_1326202668_191000', 'LIS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Aanmelding_1326202714_150000', NULL, 'Aanmelding_1326202714_150000', NULL, NULL, NULL, NULL, NULL, '08/01/2012', NULL, 'Cursus_1326194929_578000', '877777777', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Aanmelding_1326202736_478000', NULL, 'Aanmelding_1326202736_478000', NULL, NULL, NULL, NULL, NULL, '23/12/2011', NULL, 'Cursus_1326195479_354000', '822222222', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusinschrijving_1326202898_799000', NULL, NULL, 'Cursusinschrijving_1326202898_799000', NULL, NULL, NULL, NULL, '10/01/2012', NULL, NULL, NULL, 'Cursus_1326194929_578000', '877777777', 'Aanmelding_1326202714_150000', 'LIS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusinschrijving_1326203050_207000', NULL, NULL, 'Cursusinschrijving_1326203050_207000', NULL, NULL, NULL, NULL, '10/01/2012', NULL, NULL, NULL, 'Cursus_1326195479_354000', '822222222', 'Aanmelding_1326202736_478000', 'SAS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Transitie_1326202829_167000', NULL, NULL, NULL, NULL, 'Transitie_1326202829_167000', NULL, NULL, '07/01/2012', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '877777777', 'Instromer', 'Aanmelding_1326202668_191000', NULL, NULL, NULL, NULL, NULL)
                      , ('Transitie_1326202898_799000', NULL, NULL, NULL, NULL, 'Transitie_1326202898_799000', NULL, NULL, '08/01/2012', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '877777777', 'Doorstromer', 'Aanmelding_1326202714_150000', 'Transitie_1326202829_167000', NULL, NULL, NULL, NULL)
                      , ('Transitie_1326203050_207000', NULL, NULL, NULL, NULL, 'Transitie_1326203050_207000', NULL, NULL, '23/12/2011', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '822222222', 'Instromer', 'Aanmelding_1326202736_478000', NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326194435_466000', 'Cursusuitvoering_1326194435_466000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326194435_466000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326194609_634000', 'Cursusuitvoering_1326194609_634000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326194609_634000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326194795_458000', 'Cursusuitvoering_1326194795_458000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326194795_458000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326194929_578000', 'Cursusuitvoering_1326194929_578000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326194929_578000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326195078_546000', 'Cursusuitvoering_1326195078_546000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326195078_546000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326195194_674000', 'Cursusuitvoering_1326195194_674000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326195194_674000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326195301_682000', 'Cursusuitvoering_1326195301_682000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326195301_682000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326195479_354000', 'Cursusuitvoering_1326195479_354000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326195479_354000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                      , ('Cursusuitvoering_1326195540_410000', 'Cursusuitvoering_1326195540_410000', NULL, NULL, NULL, NULL, NULL, NULL, '10/01/2012', 'Cursus_1326195540_410000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Product                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * Onderwijsproduct~  [INJ,SUR,UNI]     *
    * Cursus~  [INJ,SUR,UNI]               *
    * Opleiding~  [INJ,SUR,UNI]            *
    * productnaam  [UNI,TOT]               *
    * modules  [UNI]                       *
    * ondergebracht  [UNI,TOT]             *
    * cursuscode  [UNI,TOT]                *
    * heeftinhoud  [UNI,TOT]               *
    \**************************************/
    mysql_query("CREATE TABLE `Product`
                     ( `Product` VARCHAR(255) DEFAULT NULL
                     , `Onderwijsproduct` VARCHAR(255) DEFAULT NULL
                     , `Cursus` VARCHAR(255) DEFAULT NULL
                     , `Opleiding` VARCHAR(255) DEFAULT NULL
                     , `productnaam` VARCHAR(255) DEFAULT NULL
                     , `modules` VARCHAR(255) DEFAULT NULL
                     , `ondergebracht` VARCHAR(255) DEFAULT NULL
                     , `cursuscode` VARCHAR(255) DEFAULT NULL
                     , `heeftinhoud` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Product` (`Product` ,`Onderwijsproduct` ,`Cursus` ,`Opleiding` ,`productnaam` ,`modules` ,`ondergebracht` ,`cursuscode` ,`heeftinhoud` )
                VALUES ('Cursus_1326194211_034000', 'Cursus_1326194211_034000', 'Cursus_1326194211_034000', NULL, 'Bedrijfsprocessen', '2', 'MW', 'B44322', 'Cursusinhoud_1326194211_034000')
                      , ('Cursus_1326194435_466000', 'Cursus_1326194435_466000', 'Cursus_1326194435_466000', NULL, 'Documentverwerking', '1', 'INF', 'T49221', 'Cursusinhoud_1326194435_466000')
                      , ('Opleiding_1326194234_346000', 'Opleiding_1326194234_346000', NULL, 'Opleiding_1326194234_346000', 'Master BPMIT (zelfstudie)', NULL, NULL, NULL, NULL)
                      , ('Cursus_1326194609_634000', 'Cursus_1326194609_634000', 'Cursus_1326194609_634000', NULL, 'Informatie-en procesarchitectuur', '1', 'INF', 'T48221', 'Cursusinhoud_1326194609_634000')
                      , ('Cursus_1326194795_458000', 'Cursus_1326194795_458000', 'Cursus_1326194795_458000', NULL, 'Ontwerpen met bedrijfsregels', '1', 'INF', 'T18321', 'Cursusinhoud_1326194795_458000')
                      , ('Cursus_1326194929_578000', 'Cursus_1326194929_578000', 'Cursus_1326194929_578000', NULL, 'Practicum ict-management audit', '2', 'MW', 'B70322', 'Cursusinhoud_1326194929_578000')
                      , ('Cursus_1326195078_546000', 'Cursus_1326195078_546000', 'Cursus_1326195078_546000', NULL, 'Projectmanagement: implementeren van ERP-systemen', '1', 'MW', 'B47311', 'Cursusinhoud_1326195078_546000')
                      , ('Cursus_1326195194_674000', 'Cursus_1326195194_674000', 'Cursus_1326195194_674000', NULL, 'Software management', '1', 'INF', 'T24331', 'Cursusinhoud_1326195194_674000')
                      , ('Cursus_1326195301_682000', 'Cursus_1326195301_682000', 'Cursus_1326195301_682000', NULL, 'Webservices en applicatie-integratie', '1', 'INF', 'T17311', 'Cursusinhoud_1326195301_682000')
                      , ('Cursus_1326195479_354000', 'Cursus_1326195479_354000', 'Cursus_1326195479_354000', NULL, 'Afstudeertraject Business Process Management and IT (INF)', '4', 'INF', 'T89317', 'Cursusinhoud_1326195479_354000')
                      , ('Cursus_1326195540_410000', 'Cursus_1326195540_410000', 'Cursus_1326195540_410000', NULL, 'Afstudeertraject Business Process Management and IT (MW)', '4', 'MW', 'B89317', 'Cursusinhoud_1326195479_354000')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Cel                             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * functie  [UNI,TOT]                   *
    * toegepast  [UNI,TOT]                 *
    * resulteert  [UNI,TOT]                *
    * eenheid  [UNI,TOT]                   *
    \**************************************/
    mysql_query("CREATE TABLE `Cel`
                     ( `Cel` VARCHAR(255) DEFAULT NULL
                     , `functie` VARCHAR(255) DEFAULT NULL
                     , `toegepast` VARCHAR(255) DEFAULT NULL
                     , `resulteert` VARCHAR(255) DEFAULT NULL
                     , `eenheid` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Cel` (`Cel` ,`functie` ,`toegepast` ,`resulteert` ,`eenheid` )
                VALUES ('cel1', 'AANTAL(transitienaar;(`Instromer` of `Herinstromer` of `Doorstromer`);transitienaar~ & bestaatuit;x[Log];bestaatuit~ & I[Transitie])', 'Laatste transitie van studenten op 31-01-2012', '17507', 'Aantal')
                      , ('cel2', 'AANTAL((transitienaar;(`Instromer`);transitienaar~ & bestaatuit;x[Log];bestaatuit~ & I[Transitie]);transitiebetreft;student~;(bestaatuit;x[Log];bestaatuit~ & I[Cursusinschrijving]))', 'Cursusinschrijvingen januari 2012 en laatste transitie van studenten op 31-01-2012', '13400', 'Aantal')
                      , ('cel3', 'AVG(x[Log];bestaatuit~;I[Aanmelding];PERIODE(moment , goedgekeurd~;moment))', 'cursusaanmeldingen 2011', '10', 'Aantal dagen')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Log                             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * Peilperiode~  [INJ,SUR,UNI]          *
    * begindatum  [UNI,TOT]                *
    * einddatum  [UNI,TOT]                 *
    * peildatum  [SYM,ASY,UNI,INJ]         *
    \**************************************/
    mysql_query("CREATE TABLE `Log`
                     ( `Log` VARCHAR(255) DEFAULT NULL
                     , `Peilperiode` VARCHAR(255) DEFAULT NULL
                     , `begindatum` VARCHAR(255) DEFAULT NULL
                     , `einddatum` VARCHAR(255) DEFAULT NULL
                     , `peildatum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Log` (`Log` ,`Peilperiode` ,`begindatum` ,`einddatum` ,`peildatum` )
                VALUES ('Laatste transitie van studenten op 31-01-2012', NULL, NULL, NULL, NULL)
                      , ('Cursusinschrijvingen januari 2012 en laatste transitie van studenten op 31-01-2012', NULL, NULL, NULL, NULL)
                      , ('cursusaanmeldingen 2011', NULL, NULL, NULL, NULL)
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Studiepad                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * gevolgddoor  [UNI,TOT]               *
    * omtevolgen  [UNI,TOT]                *
    \**************************************/
    mysql_query("CREATE TABLE `Studiepad`
                     ( `Studiepad` VARCHAR(255) DEFAULT NULL
                     , `gevolgddoor` VARCHAR(255) DEFAULT NULL
                     , `omtevolgen` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Functie                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * PrestatieIndicator~  [INJ,SUR,UNI]   *
    * naam  [UNI,TOT]                      *
    \**************************************/
    mysql_query("CREATE TABLE `Functie`
                     ( `Functie` VARCHAR(255) DEFAULT NULL
                     , `PrestatieIndicator` VARCHAR(255) DEFAULT NULL
                     , `naam` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Functie` (`Functie` ,`PrestatieIndicator` ,`naam` )
                VALUES ('AANTAL(transitienaar;(`Instromer` of `Herinstromer` of `Doorstromer`);transitienaar~ & bestaatuit;x[Log];bestaatuit~ & I[Transitie])', 'AANTAL(transitienaar;(`Instromer` of `Herinstromer` of `Doorstromer`);transitienaar~ & bestaatuit;x[Log];bestaatuit~ & I[Transitie])', 'Ingeschrevenen met rechten')
                      , ('AANTAL((transitienaar;(`Instromer`);transitienaar~ & bestaatuit;x[Log];bestaatuit~ & I[Transitie]);transitiebetreft;student~;(bestaatuit;x[Log];bestaatuit~ & I[Cursusinschrijving]))', 'AANTAL((transitienaar;(`Instromer`);transitienaar~ & bestaatuit;x[Log];bestaatuit~ & I[Transitie]);transitiebetreft;student~;(bestaatuit;x[Log];bestaatuit~ & I[Cursusinschrijving]))', 'Modulenafzet instromers')
                      , ('AVG(x[Log];bestaatuit~;I[Aanmelding];PERIODE(moment , goedgekeurd~;moment))', 'AVG(x[Log];bestaatuit~;I[Aanmelding];PERIODE(moment , goedgekeurd~;moment))', 'Gem. doorlooptijd afhandeling VTI')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Naam                            *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Naam`
                     ( `Naam` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Naam` (`Naam` )
                VALUES ('Ingeschrevenen met rechten')
                      , ('Modulenafzet instromers')
                      , ('Gem. doorlooptijd afhandeling VTI')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Eenheid                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Eenheid`
                     ( `Eenheid` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Eenheid` (`Eenheid` )
                VALUES ('Aantal')
                      , ('Aantal dagen')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Waarde                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Waarde`
                     ( `Waarde` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Waarde` (`Waarde` )
                VALUES ('17507')
                      , ('13400')
                      , ('10')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Resultaat                       *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Resultaat`
                     ( `Resultaat` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug TransitieStudentsoort           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `TransitieStudentsoort`
                     ( `TransitieStudentsoort` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `TransitieStudentsoort` (`TransitieStudentsoort` )
                VALUES ('Instromer')
                      , ('Doorstromer')
                      , ('Uitstromer')
                      , ('Herinstromer')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Inschrijvingsvorm               *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Inschrijvingsvorm`
                     ( `Inschrijvingsvorm` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Inschrijvingsvorm` (`Inschrijvingsvorm` )
                VALUES ('LIS')
                      , ('LIC')
                      , ('SAS')
                      , ('INH')
                      , ('KMT')
                      , ('JIN')
                      , ('SIN')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Student                         *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Student`
                     ( `Student` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Student` (`Student` )
                VALUES ('877777777')
                      , ('822222222')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Leermiddel                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Leermiddel`
                     ( `Leermiddel` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Leermiddel` (`Leermiddel` )
                VALUES ('werkboek')
                      , ('Enterprise Modelling and Enterprise Information Systems van R. Kusters en H. Wortmann')
                      , ('reader')
                      , ('tekstboek')
                      , ('cursusboek')
                      , ('A.Coenen, L.Hermans, M.van Roosmalen en S.Spreeuwenberg: Uw bedrijf geregeld met BUSINESS RULES MANAGEMENT')
                      , ('S. Joosten, L. Wedemeijer, G. Michels: Rule based design')
                      , ('Applegate, Lynda M., c.s. Corporate Information Strategy and Management. Seventh Edition, McGraw-Hill International Edition, 2007')
                      , ('elektronisch werkboek')
                      , ('Enterprise Resource Planning van Mary Sumner')
                      , ('Software Management, seventh edition van Donald Reifer (IEEE Computer Society Press, 2002)')
                      , ('onbekend')
                      , ('Afstudeertraject Business Process Management and IT')
                      , ('Saunders, M., e.a. Methoden en technieken van onderzoek, vierde editie (Nederlandse bewerking door J.P. Verckens, Pearson Education Benelux, Amsterdam 2008)')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Arbeidskracht                   *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Arbeidskracht`
                     ( `Arbeidskracht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Arbeidskracht` (`Arbeidskracht` )
                VALUES ('Dhr. dr. ir. H. Martin')
                      , ('dhr. dr. L. Wedemeijer')
                      , ('Dhr. dr. ir. F. Mofers')
                      , ('dhr. dr. J. van der Woude')
                      , ('Dhr. ir. H. Hofstee')
                      , ('Dhr. ir. G. Janssens')
                      , ('Dhr. ir. P. Oord')
                      , ('afstudeerbegeleider')
                      , ('Dhr. drs. P. Mijnheer')
                      , ('dhr. dr. L.W. Rutledge')
                      , ('mw. dr. A. Counotte')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Cursusinhoud                    *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Cursusinhoud`
                     ( `Cursusinhoud` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Cursusinhoud` (`Cursusinhoud` )
                VALUES ('Cursusinhoud_1326194211_034000')
                      , ('Cursusinhoud_1326195479_354000')
                      , ('Cursusinhoud_1326194435_466000')
                      , ('Cursusinhoud_1326194609_634000')
                      , ('Cursusinhoud_1326194795_458000')
                      , ('Cursusinhoud_1326194929_578000')
                      , ('Cursusinhoud_1326195078_546000')
                      , ('Cursusinhoud_1326195194_674000')
                      , ('Cursusinhoud_1326195301_682000')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Cursuscode                      *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Cursuscode`
                     ( `Cursuscode` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Cursuscode` (`Cursuscode` )
                VALUES ('B44322')
                      , ('T49221')
                      , ('T48221')
                      , ('T18321')
                      , ('B70322')
                      , ('B47311')
                      , ('T24331')
                      , ('T17311')
                      , ('T89317')
                      , ('B89317')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Orgaan                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Orgaan`
                     ( `Orgaan` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Orgaan` (`Orgaan` )
                VALUES ('MW')
                      , ('INF')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Aantal                          *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Aantal`
                     ( `Aantal` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Aantal` (`Aantal` )
                VALUES ('2')
                      , ('1')
                      , ('4')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Productnaam                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Productnaam`
                     ( `Productnaam` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Productnaam` (`Productnaam` )
                VALUES ('Bedrijfsprocessen')
                      , ('Documentverwerking')
                      , ('Master BPMIT (zelfstudie)')
                      , ('Informatie-en procesarchitectuur')
                      , ('Ontwerpen met bedrijfsregels')
                      , ('Practicum ict-management audit')
                      , ('Projectmanagement: implementeren van ERP-systemen')
                      , ('Software management')
                      , ('Webservices en applicatie-integratie')
                      , ('Afstudeertraject Business Process Management and IT (INF)')
                      , ('Afstudeertraject Business Process Management and IT (MW)')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug Datum                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    \**************************************/
    mysql_query("CREATE TABLE `Datum`
                     ( `Datum` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `Datum` (`Datum` )
                VALUES ('07/01/2012')
                      , ('10/01/2012')
                      , ('08/01/2012')
                      , ('23/12/2011')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**********************************\
    * Plug bestaatuit                  *
    *                                  *
    * fields:                          *
    * I/\bestaatuit;bestaatuit~  [ASY] *
    * bestaatuit  []                   *
    \**********************************/
    mysql_query("CREATE TABLE `bestaatuit`
                     ( `Log` VARCHAR(255) DEFAULT NULL
                     , `Gebeurtenis` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `bestaatuit` (`Log` ,`Gebeurtenis` )
                VALUES ('Laatste transitie van studenten op 31-01-2012', 'Transitie_1326202898_799000')
                      , ('Laatste transitie van studenten op 31-01-2012', 'Transitie_1326203050_207000')
                      , ('Cursusinschrijvingen januari 2012 en laatste transitie van studenten op 31-01-2012', 'Transitie_1326202898_799000')
                      , ('Cursusinschrijvingen januari 2012 en laatste transitie van studenten op 31-01-2012', 'Transitie_1326203050_207000')
                      , ('Cursusinschrijvingen januari 2012 en laatste transitie van studenten op 31-01-2012', 'Cursusinschrijving_1326202829_167000')
                      , ('Cursusinschrijvingen januari 2012 en laatste transitie van studenten op 31-01-2012', 'Cursusinschrijving_1326202898_799000')
                      , ('Cursusinschrijvingen januari 2012 en laatste transitie van studenten op 31-01-2012', 'Cursusinschrijving_1326203050_207000')
                      , ('cursusaanmeldingen 2011', 'Aanmelding_1326202736_478000')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug tbv                             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * tbv  [TOT]                           *
    \**************************************/
    mysql_query("CREATE TABLE `tbv`
                     ( `Peilperiode` VARCHAR(255) DEFAULT NULL
                     , `Functie` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug omvat                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * omvat  [TOT]                         *
    \**************************************/
    mysql_query("CREATE TABLE `omvat`
                     ( `Opleiding` VARCHAR(255) DEFAULT NULL
                     , `Cursus` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `omvat` (`Opleiding` ,`Cursus` )
                VALUES ('Opleiding_1326194234_346000', 'Cursus_1326194211_034000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326194435_466000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326194609_634000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326194795_458000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326194929_578000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326195078_546000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326195194_674000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326195301_682000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326195479_354000')
                      , ('Opleiding_1326194234_346000', 'Cursus_1326195540_410000')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug examinators                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * examinators  [TOT]                   *
    \**************************************/
    mysql_query("CREATE TABLE `examinators`
                     ( `Cursus` VARCHAR(255) DEFAULT NULL
                     , `Arbeidskracht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `examinators` (`Cursus` ,`Arbeidskracht` )
                VALUES ('Cursus_1326194211_034000', 'Dhr. dr. ir. H. Martin')
                      , ('Cursus_1326194435_466000', 'dhr. dr. L. Wedemeijer')
                      , ('Cursus_1326194609_634000', 'Dhr. dr. ir. F. Mofers')
                      , ('Cursus_1326194609_634000', 'dhr. dr. J. van der Woude')
                      , ('Cursus_1326194795_458000', 'dhr. dr. L. Wedemeijer')
                      , ('Cursus_1326194929_578000', 'Dhr. ir. H. Hofstee')
                      , ('Cursus_1326195078_546000', 'Dhr. ir. G. Janssens')
                      , ('Cursus_1326195194_674000', 'Dhr. ir. P. Oord')
                      , ('Cursus_1326195301_682000', 'dhr. dr. L. Wedemeijer')
                      , ('Cursus_1326195479_354000', 'afstudeerbegeleider')
                      , ('Cursus_1326195540_410000', 'afstudeerbegeleider')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /********************************************\
    * Plug cursusmateriaal                       *
    *                                            *
    * fields:                                    *
    * I/\cursusmateriaal;cursusmateriaal~  [ASY] *
    * cursusmateriaal  []                        *
    \********************************************/
    mysql_query("CREATE TABLE `cursusmateriaal`
                     ( `Cursus` VARCHAR(255) DEFAULT NULL
                     , `Leermiddel` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `cursusmateriaal` (`Cursus` ,`Leermiddel` )
                VALUES ('Cursus_1326194211_034000', 'werkboek')
                      , ('Cursus_1326194211_034000', 'Enterprise Modelling and Enterprise Information Systems van R. Kusters en H. Wortmann')
                      , ('Cursus_1326194211_034000', 'reader')
                      , ('Cursus_1326194435_466000', 'werkboek')
                      , ('Cursus_1326194435_466000', 'tekstboek')
                      , ('Cursus_1326194435_466000', 'reader')
                      , ('Cursus_1326194609_634000', 'cursusboek')
                      , ('Cursus_1326194609_634000', 'tekstboek')
                      , ('Cursus_1326194795_458000', 'werkboek')
                      , ('Cursus_1326194795_458000', 'A.Coenen, L.Hermans, M.van Roosmalen en S.Spreeuwenberg: Uw bedrijf geregeld met BUSINESS RULES MANAGEMENT')
                      , ('Cursus_1326194795_458000', 'S. Joosten, L. Wedemeijer, G. Michels: Rule based design')
                      , ('Cursus_1326194929_578000', 'Applegate, Lynda M., c.s. Corporate Information Strategy and Management. Seventh Edition, McGraw-Hill International Edition, 2007')
                      , ('Cursus_1326194929_578000', 'reader')
                      , ('Cursus_1326194929_578000', 'elektronisch werkboek')
                      , ('Cursus_1326195078_546000', 'reader')
                      , ('Cursus_1326195078_546000', 'Enterprise Resource Planning van Mary Sumner')
                      , ('Cursus_1326195078_546000', 'elektronisch werkboek')
                      , ('Cursus_1326195194_674000', 'Software Management, seventh edition van Donald Reifer (IEEE Computer Society Press, 2002)')
                      , ('Cursus_1326195194_674000', 'werkboek')
                      , ('Cursus_1326195301_682000', 'onbekend')
                      , ('Cursus_1326195479_354000', 'Afstudeertraject Business Process Management and IT')
                      , ('Cursus_1326195479_354000', 'Saunders, M., e.a. Methoden en technieken van onderzoek, vierde editie (Nederlandse bewerking door J.P. Verckens, Pearson Education Benelux, Amsterdam 2008)')
                      , ('Cursus_1326195540_410000', 'Afstudeertraject Business Process Management and IT')
                      , ('Cursus_1326195540_410000', 'Saunders, M., e.a. Methoden en technieken van onderzoek, vierde editie (Nederlandse bewerking door J.P. Verckens, Pearson Education Benelux, Amsterdam 2008)')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug heeftdocent                     *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * heeftdocent  [TOT]                   *
    \**************************************/
    mysql_query("CREATE TABLE `heeftdocent`
                     ( `Cursusuitvoering` VARCHAR(255) DEFAULT NULL
                     , `Arbeidskracht` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `heeftdocent` (`Cursusuitvoering` ,`Arbeidskracht` )
                VALUES ('Cursusuitvoering_1326194211_034000', 'Dhr. dr. ir. H. Martin')
                      , ('Cursusuitvoering_1326194435_466000', 'dhr. dr. L. Wedemeijer')
                      , ('Cursusuitvoering_1326194435_466000', 'Dhr. drs. P. Mijnheer')
                      , ('Cursusuitvoering_1326194609_634000', 'Dhr. dr. ir. F. Mofers')
                      , ('Cursusuitvoering_1326194609_634000', 'dhr. dr. J. van der Woude')
                      , ('Cursusuitvoering_1326194795_458000', 'dhr. dr. L. Wedemeijer')
                      , ('Cursusuitvoering_1326194795_458000', 'dhr. dr. J. van der Woude')
                      , ('Cursusuitvoering_1326194929_578000', 'Dhr. ir. H. Hofstee')
                      , ('Cursusuitvoering_1326195078_546000', 'Dhr. ir. G. Janssens')
                      , ('Cursusuitvoering_1326195194_674000', 'Dhr. ir. P. Oord')
                      , ('Cursusuitvoering_1326195301_682000', 'dhr. dr. L. Wedemeijer')
                      , ('Cursusuitvoering_1326195301_682000', 'dhr. dr. L.W. Rutledge')
                      , ('Cursusuitvoering_1326195479_354000', 'mw. dr. A. Counotte')
                      , ('Cursusuitvoering_1326195479_354000', 'afstudeerbegeleider')
                      , ('Cursusuitvoering_1326195540_410000', 'Dhr. ir. H. Hofstee')
                      , ('Cursusuitvoering_1326195540_410000', 'afstudeerbegeleider')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug inschrijvingsvormen             *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * inschrijvingsvormen  [TOT]           *
    \**************************************/
    mysql_query("CREATE TABLE `inschrijvingsvormen`
                     ( `Cursus` VARCHAR(255) DEFAULT NULL
                     , `Inschrijvingsvorm` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    else
    mysql_query("INSERT IGNORE INTO `inschrijvingsvormen` (`Cursus` ,`Inschrijvingsvorm` )
                VALUES ('Cursus_1326194211_034000', 'LIS')
                      , ('Cursus_1326194435_466000', 'LIS')
                      , ('Cursus_1326194609_634000', 'LIC')
                      , ('Cursus_1326194609_634000', 'LIS')
                      , ('Cursus_1326194795_458000', 'LIS')
                      , ('Cursus_1326194929_578000', 'LIS')
                      , ('Cursus_1326195078_546000', 'LIC')
                      , ('Cursus_1326195078_546000', 'LIS')
                      , ('Cursus_1326195194_674000', 'LIS')
                      , ('Cursus_1326195301_682000', 'LIS')
                      , ('Cursus_1326195479_354000', 'SAS')
                      , ('Cursus_1326195540_410000', 'SAS')
                ");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    /**************************************\
    * Plug bevat                           *
    *                                      *
    * fields:                              *
    * I  [UNI,TOT,INJ,SUR,SYM,ASY,TRN,RFX] *
    * bevat  [TOT]                         *
    \**************************************/
    mysql_query("CREATE TABLE `bevat`
                     ( `Studiepad` VARCHAR(255) DEFAULT NULL
                     , `Cursus` VARCHAR(255) DEFAULT NULL
                      ) ENGINE=InnoDB DEFAULT CHARACTER SET UTF8");
    if($err=mysql_error()) { $error=true; echo $err.'<br />'; }
    mysql_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
    if ($err=='') {
      echo '<div id="ResetSuccess"/>The database has been reset to its initial population.<br/><br/><button onclick="window.location.href = document.referrer;">Ok</button>';
      $content = '
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT OUNL\n");
      fwrite($dumpfile, dumprel("bestaatuit[Log*Gebeurtenis]","SELECT DISTINCT `Log`, `Gebeurtenis` FROM `bestaatuit` WHERE `Log` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("moment[Gebeurtenis*Datum]","SELECT DISTINCT `Gebeurtenis`, `moment` FROM `Gebeurtenis` WHERE `Gebeurtenis` IS NOT NULL AND `moment` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tbv[Peilperiode*Functie]","SELECT DISTINCT `Peilperiode`, `Functie` FROM `tbv` WHERE `Peilperiode` IS NOT NULL AND `Functie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("begindatum[Peilperiode*Datum]","SELECT DISTINCT `Peilperiode`, `begindatum` FROM `Log` WHERE `Peilperiode` IS NOT NULL AND `begindatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("einddatum[Peilperiode*Datum]","SELECT DISTINCT `Peilperiode`, `einddatum` FROM `Log` WHERE `Peilperiode` IS NOT NULL AND `einddatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("peildatum[Peilperiode]","SELECT DISTINCT `Peilperiode`, `peildatum` FROM `Log` WHERE `Peilperiode` IS NOT NULL AND `peildatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Peilperiode[Peilperiode*Log]","SELECT DISTINCT `Peilperiode`, `Log` FROM `Log` WHERE `Peilperiode` IS NOT NULL AND `Log` IS NOT NULL"));
      fwrite($dumpfile, dumprel("productnaam[Product*Productnaam]","SELECT DISTINCT `Product`, `productnaam` FROM `Product` WHERE `Product` IS NOT NULL AND `productnaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omvat[Opleiding*Cursus]","SELECT DISTINCT `Opleiding`, `Cursus` FROM `omvat` WHERE `Opleiding` IS NOT NULL AND `Cursus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("modules[Cursus*Aantal]","SELECT DISTINCT `Cursus`, `modules` FROM `Product` WHERE `Cursus` IS NOT NULL AND `modules` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ondergebracht[Cursus*Orgaan]","SELECT DISTINCT `Cursus`, `ondergebracht` FROM `Product` WHERE `Cursus` IS NOT NULL AND `ondergebracht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Onderwijsproduct[Onderwijsproduct*Product]","SELECT DISTINCT `Onderwijsproduct`, `Product` FROM `Product` WHERE `Onderwijsproduct` IS NOT NULL AND `Product` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Cursus[Cursus*Onderwijsproduct]","SELECT DISTINCT `Cursus`, `Onderwijsproduct` FROM `Product` WHERE `Cursus` IS NOT NULL AND `Onderwijsproduct` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Opleiding[Opleiding*Onderwijsproduct]","SELECT DISTINCT `Opleiding`, `Onderwijsproduct` FROM `Product` WHERE `Opleiding` IS NOT NULL AND `Onderwijsproduct` IS NOT NULL"));
      fwrite($dumpfile, dumprel("cursuscode[Cursus*Cursuscode]","SELECT DISTINCT `Cursus`, `cursuscode` FROM `Product` WHERE `Cursus` IS NOT NULL AND `cursuscode` IS NOT NULL"));
      fwrite($dumpfile, dumprel("heeftinhoud[Cursus*Cursusinhoud]","SELECT DISTINCT `Cursus`, `heeftinhoud` FROM `Product` WHERE `Cursus` IS NOT NULL AND `heeftinhoud` IS NOT NULL"));
      fwrite($dumpfile, dumprel("examinators[Cursus*Arbeidskracht]","SELECT DISTINCT `Cursus`, `Arbeidskracht` FROM `examinators` WHERE `Cursus` IS NOT NULL AND `Arbeidskracht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("cursusmateriaal[Cursus*Leermiddel]","SELECT DISTINCT `Cursus`, `Leermiddel` FROM `cursusmateriaal` WHERE `Cursus` IS NOT NULL AND `Leermiddel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("voertuit[Cursusuitvoering*Cursus]","SELECT DISTINCT `Cursusuitvoering`, `voertuit` FROM `Gebeurtenis` WHERE `Cursusuitvoering` IS NOT NULL AND `voertuit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("heeftdocent[Cursusuitvoering*Arbeidskracht]","SELECT DISTINCT `Cursusuitvoering`, `Arbeidskracht` FROM `heeftdocent` WHERE `Cursusuitvoering` IS NOT NULL AND `Arbeidskracht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Cursusuitvoering[Cursusuitvoering*Gebeurtenis]","SELECT DISTINCT `Cursusuitvoering`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Cursusuitvoering` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("cursusaanmelding[Aanmelding*Cursus]","SELECT DISTINCT `Aanmelding`, `cursusaanmelding` FROM `Gebeurtenis` WHERE `Aanmelding` IS NOT NULL AND `cursusaanmelding` IS NOT NULL"));
      fwrite($dumpfile, dumprel("studentaanmelding[Aanmelding*Student]","SELECT DISTINCT `Aanmelding`, `studentaanmelding` FROM `Gebeurtenis` WHERE `Aanmelding` IS NOT NULL AND `studentaanmelding` IS NOT NULL"));
      fwrite($dumpfile, dumprel("cursus[Cursusinschrijving*Cursus]","SELECT DISTINCT `Cursusinschrijving`, `cursus` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `cursus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("student[Cursusinschrijving*Student]","SELECT DISTINCT `Cursusinschrijving`, `student` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `student` IS NOT NULL"));
      fwrite($dumpfile, dumprel("goedgekeurd[Cursusinschrijving*Aanmelding]","SELECT DISTINCT `Cursusinschrijving`, `goedgekeurd` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `goedgekeurd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsvormen[Cursus*Inschrijvingsvorm]","SELECT DISTINCT `Cursus`, `Inschrijvingsvorm` FROM `inschrijvingsvormen` WHERE `Cursus` IS NOT NULL AND `Inschrijvingsvorm` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsvorm[Cursusinschrijving*Inschrijvingsvorm]","SELECT DISTINCT `Cursusinschrijving`, `inschrijvingsvorm` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `inschrijvingsvorm` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verloopt[VerlopenRechten*Cursusinschrijving]","SELECT DISTINCT `verloopt`, `Cursusinschrijving` FROM `Gebeurtenis` WHERE `verloopt` IS NOT NULL AND `Cursusinschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Aanmelding[Aanmelding*Gebeurtenis]","SELECT DISTINCT `Aanmelding`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Aanmelding` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Cursusinschrijving[Cursusinschrijving*Gebeurtenis]","SELECT DISTINCT `Cursusinschrijving`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("VerlopenRechten[VerlopenRechten*Gebeurtenis]","SELECT DISTINCT `VerlopenRechten`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `VerlopenRechten` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("transitiebetreft[Transitie*Student]","SELECT DISTINCT `Transitie`, `transitiebetreft` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `transitiebetreft` IS NOT NULL"));
      fwrite($dumpfile, dumprel("transitienaar[Transitie*TransitieStudentsoort]","SELECT DISTINCT `Transitie`, `transitienaar` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `transitienaar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("veroorzaaktdoor[Transitie*Gebeurtenis]","SELECT DISTINCT `Transitie`, `veroorzaaktdoor` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `veroorzaaktdoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vorigetransitie[Transitie]","SELECT DISTINCT `Transitie`, `vorigetransitie` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `vorigetransitie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Transitie[Transitie*Gebeurtenis]","SELECT DISTINCT `Transitie`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemaaktdoor[Tentamen*Student]","SELECT DISTINCT `Tentamen`, `gemaaktdoor` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `gemaaktdoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tentamenvoor[Tentamen*Cursus]","SELECT DISTINCT `Tentamen`, `tentamenvoor` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `tentamenvoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beoordeling[Tentamen*Resultaat]","SELECT DISTINCT `Tentamen`, `beoordeling` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `beoordeling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beoordeeltdoor[Tentamen*Arbeidskracht]","SELECT DISTINCT `Tentamen`, `beoordeeltdoor` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `beoordeeltdoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Tentamen[Tentamen*Gebeurtenis]","SELECT DISTINCT `Tentamen`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gevolgddoor[Studiepad*Student]","SELECT DISTINCT `Studiepad`, `gevolgddoor` FROM `Studiepad` WHERE `Studiepad` IS NOT NULL AND `gevolgddoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omtevolgen[Studiepad*Opleiding]","SELECT DISTINCT `Studiepad`, `omtevolgen` FROM `Studiepad` WHERE `Studiepad` IS NOT NULL AND `omtevolgen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bevat[Studiepad*Cursus]","SELECT DISTINCT `Studiepad`, `Cursus` FROM `bevat` WHERE `Studiepad` IS NOT NULL AND `Cursus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("functie[Cel*Functie]","SELECT DISTINCT `Cel`, `functie` FROM `Cel` WHERE `Cel` IS NOT NULL AND `functie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("toegepast[Cel*Log]","SELECT DISTINCT `Cel`, `toegepast` FROM `Cel` WHERE `Cel` IS NOT NULL AND `toegepast` IS NOT NULL"));
      fwrite($dumpfile, dumprel("resulteert[Cel*Waarde]","SELECT DISTINCT `Cel`, `resulteert` FROM `Cel` WHERE `Cel` IS NOT NULL AND `resulteert` IS NOT NULL"));
      fwrite($dumpfile, dumprel("eenheid[Cel*Eenheid]","SELECT DISTINCT `Cel`, `eenheid` FROM `Cel` WHERE `Cel` IS NOT NULL AND `eenheid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("naam[PrestatieIndicator*Naam]","SELECT DISTINCT `PrestatieIndicator`, `naam` FROM `Functie` WHERE `PrestatieIndicator` IS NOT NULL AND `naam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("PrestatieIndicator[PrestatieIndicator*Functie]","SELECT DISTINCT `PrestatieIndicator`, `Functie` FROM `Functie` WHERE `PrestatieIndicator` IS NOT NULL AND `Functie` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("ounl", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\\\\"",$str); }
      ?>';
      file_put_contents("dbdump.php.",$content);
    }
  }
  
?></body></html>
