
      <?php
      require "php/DatabaseUtils.php";
      $dumpfile = fopen("dbdump.adl","w");
      fwrite($dumpfile, "CONTEXT OUNL\n");
      fwrite($dumpfile, dumprel("bestaatuit[Log*Gebeurtenis]","SELECT DISTINCT `Log`, `Gebeurtenis` FROM `bestaatuit` WHERE `Log` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("moment[Gebeurtenis*Datum]","SELECT DISTINCT `Gebeurtenis`, `moment` FROM `Gebeurtenis` WHERE `Gebeurtenis` IS NOT NULL AND `moment` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tbv[Peilperiode*Functie]","SELECT DISTINCT `Peilperiode`, `Functie` FROM `tbv` WHERE `Peilperiode` IS NOT NULL AND `Functie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("begindatum[Peilperiode*Datum]","SELECT DISTINCT `Peilperiode`, `begindatum` FROM `Log` WHERE `Peilperiode` IS NOT NULL AND `begindatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("einddatum[Peilperiode*Datum]","SELECT DISTINCT `Peilperiode`, `einddatum` FROM `Log` WHERE `Peilperiode` IS NOT NULL AND `einddatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("peildatum[Peilperiode]","SELECT DISTINCT `Peilperiode`, `peildatum` FROM `Log` WHERE `Peilperiode` IS NOT NULL AND `peildatum` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Peilperiode[Peilperiode*Log]","SELECT DISTINCT `Peilperiode`, `Log` FROM `Log` WHERE `Peilperiode` IS NOT NULL AND `Log` IS NOT NULL"));
      fwrite($dumpfile, dumprel("productnaam[Product*Productnaam]","SELECT DISTINCT `Product`, `productnaam` FROM `Product` WHERE `Product` IS NOT NULL AND `productnaam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omvat[Opleiding*Cursus]","SELECT DISTINCT `Opleiding`, `Cursus` FROM `omvat` WHERE `Opleiding` IS NOT NULL AND `Cursus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("modules[Cursus*Aantal]","SELECT DISTINCT `Cursus`, `modules` FROM `Product` WHERE `Cursus` IS NOT NULL AND `modules` IS NOT NULL"));
      fwrite($dumpfile, dumprel("ondergebracht[Cursus*Orgaan]","SELECT DISTINCT `Cursus`, `ondergebracht` FROM `Product` WHERE `Cursus` IS NOT NULL AND `ondergebracht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Onderwijsproduct[Onderwijsproduct*Product]","SELECT DISTINCT `Onderwijsproduct`, `Product` FROM `Product` WHERE `Onderwijsproduct` IS NOT NULL AND `Product` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Cursus[Cursus*Onderwijsproduct]","SELECT DISTINCT `Cursus`, `Onderwijsproduct` FROM `Product` WHERE `Cursus` IS NOT NULL AND `Onderwijsproduct` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Opleiding[Opleiding*Onderwijsproduct]","SELECT DISTINCT `Opleiding`, `Onderwijsproduct` FROM `Product` WHERE `Opleiding` IS NOT NULL AND `Onderwijsproduct` IS NOT NULL"));
      fwrite($dumpfile, dumprel("cursuscode[Cursus*Cursuscode]","SELECT DISTINCT `Cursus`, `cursuscode` FROM `Product` WHERE `Cursus` IS NOT NULL AND `cursuscode` IS NOT NULL"));
      fwrite($dumpfile, dumprel("heeftinhoud[Cursus*Cursusinhoud]","SELECT DISTINCT `Cursus`, `heeftinhoud` FROM `Product` WHERE `Cursus` IS NOT NULL AND `heeftinhoud` IS NOT NULL"));
      fwrite($dumpfile, dumprel("examinators[Cursus*Arbeidskracht]","SELECT DISTINCT `Cursus`, `Arbeidskracht` FROM `examinators` WHERE `Cursus` IS NOT NULL AND `Arbeidskracht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("cursusmateriaal[Cursus*Leermiddel]","SELECT DISTINCT `Cursus`, `Leermiddel` FROM `cursusmateriaal` WHERE `Cursus` IS NOT NULL AND `Leermiddel` IS NOT NULL"));
      fwrite($dumpfile, dumprel("voertuit[Cursusuitvoering*Cursus]","SELECT DISTINCT `Cursusuitvoering`, `voertuit` FROM `Gebeurtenis` WHERE `Cursusuitvoering` IS NOT NULL AND `voertuit` IS NOT NULL"));
      fwrite($dumpfile, dumprel("heeftdocent[Cursusuitvoering*Arbeidskracht]","SELECT DISTINCT `Cursusuitvoering`, `Arbeidskracht` FROM `heeftdocent` WHERE `Cursusuitvoering` IS NOT NULL AND `Arbeidskracht` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Cursusuitvoering[Cursusuitvoering*Gebeurtenis]","SELECT DISTINCT `Cursusuitvoering`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Cursusuitvoering` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("cursusaanmelding[Aanmelding*Cursus]","SELECT DISTINCT `Aanmelding`, `cursusaanmelding` FROM `Gebeurtenis` WHERE `Aanmelding` IS NOT NULL AND `cursusaanmelding` IS NOT NULL"));
      fwrite($dumpfile, dumprel("studentaanmelding[Aanmelding*Student]","SELECT DISTINCT `Aanmelding`, `studentaanmelding` FROM `Gebeurtenis` WHERE `Aanmelding` IS NOT NULL AND `studentaanmelding` IS NOT NULL"));
      fwrite($dumpfile, dumprel("cursus[Cursusinschrijving*Cursus]","SELECT DISTINCT `Cursusinschrijving`, `cursus` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `cursus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("student[Cursusinschrijving*Student]","SELECT DISTINCT `Cursusinschrijving`, `student` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `student` IS NOT NULL"));
      fwrite($dumpfile, dumprel("goedgekeurd[Cursusinschrijving*Aanmelding]","SELECT DISTINCT `Cursusinschrijving`, `goedgekeurd` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `goedgekeurd` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsvormen[Cursus*Inschrijvingsvorm]","SELECT DISTINCT `Cursus`, `Inschrijvingsvorm` FROM `inschrijvingsvormen` WHERE `Cursus` IS NOT NULL AND `Inschrijvingsvorm` IS NOT NULL"));
      fwrite($dumpfile, dumprel("inschrijvingsvorm[Cursusinschrijving*Inschrijvingsvorm]","SELECT DISTINCT `Cursusinschrijving`, `inschrijvingsvorm` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `inschrijvingsvorm` IS NOT NULL"));
      fwrite($dumpfile, dumprel("verloopt[VerlopenRechten*Cursusinschrijving]","SELECT DISTINCT `verloopt`, `Cursusinschrijving` FROM `Gebeurtenis` WHERE `verloopt` IS NOT NULL AND `Cursusinschrijving` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Aanmelding[Aanmelding*Gebeurtenis]","SELECT DISTINCT `Aanmelding`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Aanmelding` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Cursusinschrijving[Cursusinschrijving*Gebeurtenis]","SELECT DISTINCT `Cursusinschrijving`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Cursusinschrijving` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("VerlopenRechten[VerlopenRechten*Gebeurtenis]","SELECT DISTINCT `VerlopenRechten`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `VerlopenRechten` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("transitiebetreft[Transitie*Student]","SELECT DISTINCT `Transitie`, `transitiebetreft` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `transitiebetreft` IS NOT NULL"));
      fwrite($dumpfile, dumprel("transitienaar[Transitie*TransitieStudentsoort]","SELECT DISTINCT `Transitie`, `transitienaar` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `transitienaar` IS NOT NULL"));
      fwrite($dumpfile, dumprel("veroorzaaktdoor[Transitie*Gebeurtenis]","SELECT DISTINCT `Transitie`, `veroorzaaktdoor` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `veroorzaaktdoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("vorigetransitie[Transitie]","SELECT DISTINCT `Transitie`, `vorigetransitie` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `vorigetransitie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Transitie[Transitie*Gebeurtenis]","SELECT DISTINCT `Transitie`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Transitie` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gemaaktdoor[Tentamen*Student]","SELECT DISTINCT `Tentamen`, `gemaaktdoor` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `gemaaktdoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("tentamenvoor[Tentamen*Cursus]","SELECT DISTINCT `Tentamen`, `tentamenvoor` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `tentamenvoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beoordeling[Tentamen*Resultaat]","SELECT DISTINCT `Tentamen`, `beoordeling` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `beoordeling` IS NOT NULL"));
      fwrite($dumpfile, dumprel("beoordeeltdoor[Tentamen*Arbeidskracht]","SELECT DISTINCT `Tentamen`, `beoordeeltdoor` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `beoordeeltdoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("Tentamen[Tentamen*Gebeurtenis]","SELECT DISTINCT `Tentamen`, `Gebeurtenis` FROM `Gebeurtenis` WHERE `Tentamen` IS NOT NULL AND `Gebeurtenis` IS NOT NULL"));
      fwrite($dumpfile, dumprel("gevolgddoor[Studiepad*Student]","SELECT DISTINCT `Studiepad`, `gevolgddoor` FROM `Studiepad` WHERE `Studiepad` IS NOT NULL AND `gevolgddoor` IS NOT NULL"));
      fwrite($dumpfile, dumprel("omtevolgen[Studiepad*Opleiding]","SELECT DISTINCT `Studiepad`, `omtevolgen` FROM `Studiepad` WHERE `Studiepad` IS NOT NULL AND `omtevolgen` IS NOT NULL"));
      fwrite($dumpfile, dumprel("bevat[Studiepad*Cursus]","SELECT DISTINCT `Studiepad`, `Cursus` FROM `bevat` WHERE `Studiepad` IS NOT NULL AND `Cursus` IS NOT NULL"));
      fwrite($dumpfile, dumprel("functie[Cel*Functie]","SELECT DISTINCT `Cel`, `functie` FROM `Cel` WHERE `Cel` IS NOT NULL AND `functie` IS NOT NULL"));
      fwrite($dumpfile, dumprel("toegepast[Cel*Log]","SELECT DISTINCT `Cel`, `toegepast` FROM `Cel` WHERE `Cel` IS NOT NULL AND `toegepast` IS NOT NULL"));
      fwrite($dumpfile, dumprel("resulteert[Cel*Waarde]","SELECT DISTINCT `Cel`, `resulteert` FROM `Cel` WHERE `Cel` IS NOT NULL AND `resulteert` IS NOT NULL"));
      fwrite($dumpfile, dumprel("eenheid[Cel*Eenheid]","SELECT DISTINCT `Cel`, `eenheid` FROM `Cel` WHERE `Cel` IS NOT NULL AND `eenheid` IS NOT NULL"));
      fwrite($dumpfile, dumprel("naam[PrestatieIndicator*Naam]","SELECT DISTINCT `PrestatieIndicator`, `naam` FROM `Functie` WHERE `PrestatieIndicator` IS NOT NULL AND `naam` IS NOT NULL"));
      fwrite($dumpfile, dumprel("PrestatieIndicator[PrestatieIndicator*Functie]","SELECT DISTINCT `PrestatieIndicator`, `Functie` FROM `Functie` WHERE `PrestatieIndicator` IS NOT NULL AND `Functie` IS NOT NULL"));
      fwrite($dumpfile, "ENDCONTEXT");
      fclose($dumpfile);
      
      function dumprel ($rel,$quer)
      {
        $rows = DB_doquer("ounl", $quer);
        $pop = "";
        foreach ($rows as $row)
          $pop = $pop.";(\"".escapedoublequotes($row[0])."\",\"".escapedoublequotes($row[1])."\")\n  ";
        return "POPULATION ".$rel." CONTAINS\n  [".substr($pop,1)."]\n";
      }
      function escapedoublequotes($str) { return str_replace("\"","\\\"",$str); }
      ?>